#!/bin/bash

echo "LoadModule proxy_module modules/mod_proxy.so" >> /etc/httpd/conf/httpd.conf 
echo "LoadModule proxy_http_module modules/mod_proxy_http.so" >> /etc/httpd/conf/httpd.conf
echo "LoadModule rewrite_module modules/mod_rewrite.so" >> /etc/httpd/conf/httpd.conf

