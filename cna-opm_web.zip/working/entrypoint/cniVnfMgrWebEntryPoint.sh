#!/bin/bash

# entrypoint for cni-vnfmgr resource manager containter.
# stopping sshd-keygen as it is blocking sshd from starting. sshd is used for development
#/usr/sbin/sshd-keygen stop
# generate keys
#ssh-keygen -A
#/usr/sbin/sshd

#replace DocumentRoot path
sed -i 's|/etc/httpd/htdocs|/var/www/html|g' /etc/httpd/conf/httpd.conf

if ! test -f "/first.time"; then
   echo "The File does not Exists"
   echo "LoadModule proxy_module /usr/lib/httpd/modules/mod_proxy.so" >> /etc/httpd/conf/httpd.conf
   echo "LoadModule proxy_http_module /usr/lib/httpd/modules/mod_proxy_http.so" >> /etc/httpd/conf/httpd.conf
   echo "LoadModule rewrite_module /usr/lib/httpd/modules/mod_rewrite.so" >> /etc/httpd/conf/httpd.conf


   # Disabling TRACE http method
   echo "" >> /etc/httpd/conf/httpd.conf
   echo "# see: https://httpd.apache.org/docs/2.4/mod/core.html#traceenable" >> /etc/httpd/conf/httpd.conf
   echo "TraceEnable Off" >> /etc/httpd/conf/httpd.conf

   if [ "$OPM_MODE" = "multiNode" ] && [ "$EXTERNAL_AUTH" = "true" ]; then
      echo "" >> /etc/httpd/conf/httpd.conf
      echo "# If multinode and externalAuth enabled skip login page - redirect /index.html to /html/opm.html" >> /etc/httpd/conf/httpd.conf
      echo "RewriteEngine on" >> /etc/httpd/conf/httpd.conf
      echo "RewriteRule "/index.html" "/html/opm-auth.html" [CO=appId:$APP_ID:$OPM_EXTERNAL_IPS]" >> /etc/httpd/conf/httpd.conf
   fi

   if [ "$OPM_AO5GC" = "true" ]; then
      echo "" >> /etc/httpd/conf/httpd.conf
      echo "# If ao5gc and externalAuth enabled skip login page - redirect /index.html to /html/opm.html" >> /etc/httpd/conf/httpd.conf
      echo "RewriteEngine on" >> /etc/httpd/conf/httpd.conf
      echo "RewriteRule "/index.html" "/index-ao5gc.html"" >> /etc/httpd/conf/httpd.conf
      echo "RewriteRule "/html/opm.html" "/html/opm-ao5gc.html"" >> /etc/httpd/conf/httpd.conf
   fi


   echo "ran" > /first.time
else
    echo "Already ran once"
fi

# Make sure we're not confused by old, incompletely-shutdown httpd
# context after restarting the container.  httpd won't start correctly
# if it thinks it is already running.

rm -rf /run/httpd/* /tmp/httpd*
exec /usr/sbin/httpd -DFOREGROUND

/bin/bash