var timer = require("grunt-timer");

module.exports = function(grunt) {

    timer.init(grunt, { deferLogs: true, friendlyTime: true, color: "blue", totalOnly: true });

    grunt.initConfig({
        dirs: {
            lib: './lib',
            node_modules: './node_modules',
            tmp: './tmp',
            tmp_common: '<%= dirs.tmp %>/common',
            tmp_opm: '<%= dirs.tmp %>/opm',
            tmp_pre: '<%= dirs.tmp %>/pre',
            output: './output',
            src: './src',
            gcm: './gui_common_modules',
            src_common: '<%= dirs.src %>/common',
            src_opm: '<%= dirs.src %>/opm',
            config: './config'
        },

        pkg: grunt.file.readJSON('package.json'),

        clean: {
            all: ['<%= dirs.tmp %>/', '<%= dirs.output %>/*'],
            common: ['<%= dirs.tmp_common %>'],
            opm: ['<%= dirs.tmp_opm %>'],
            tmp: ['<%= dirs.tmp %>/']
        },

        handlebars: {
            common:
                {   src: '<%= dirs.gcm %>/**/*.handlebars',
                    dest: '<%= dirs.tmp_common %>/templates.js',
                    options: {
                        namespace: 'Handlebars.templates',
                        processName: function(filePath) {
                            // replace slashes in the path with underscores
                            filePath = filePath.replace(/\//g, '_');

                            // strip off the gcm_templates_ head of the path
                            // this will keep the registered template names of the src/common/template files the same as
                            // they were before we started using directory based naming
                            filePath = filePath.replace(/^._gcm_templates_/, ''); // for backwards comp

                            // replace  the gcm_scripts with common_
                            filePath = filePath.replace(/^._gui_common_modules_modules_/, 'gcm_');
                            return filePath.replace('.handlebars', '');
                        }
                    }
                },
            opm:
                {   src: '<%= dirs.src_opm %>/**/*.handlebars',
                    dest: '<%= dirs.tmp_opm %>/templates.js',
                    options: {
                        namespace: 'Handlebars.templates',
                        processName: function(filePath) {
                            // replace slashes in the path with underscores
                            filePath = filePath.replace(/\//g, '_');

                            // strip off the src_builder_templates_ head of the path
                            // this will keep the registered template names of the src/builder/template files the same as
                            // they were before we started using directory based naming
                            filePath = filePath.replace(/^._src_opm_templates_/, ''); // for backwards comp

                            // strip off the src_builder_scripts
                            filePath = filePath.replace(/^._src_opm_modules_/, '');
                            return filePath.replace('.handlebars', '');
                        }
                    }
                }
        },

        concat: {
            options: {
                sourceMap: true,
                sourceMapStyle: 'embed'
            },
            pre: {
                src: [
                    '<%= dirs.node_modules %>/jquery/dist/jquery.min.js',
                    '<%= dirs.node_modules %>/jquery-ui-dist/jquery-ui.js',
                    '<%= dirs.node_modules %>/js-cookie/src/js.cookie.js',
                    '<%= dirs.node_modules %>/handlebars/dist/handlebars.runtime.min.js',
                    '<%= dirs.gcm %>/lib/jquery.layout.js'
                ],
                dest: '<%= dirs.tmp_pre %>/scripts/pre.min.js'
            }
        },

        uglify: {
            options: {
                compress: true,
                mangle: false,
                sourceMap: true,
                sourceMapIncludeSources: true
            },

            opm: {
                src: [
                    '<%= dirs.node_modules %>/eventemitter3/umd/eventemitter3.min.js',
                    '<%= dirs.gcm %>/modules/namespace.js',
                    '<%= dirs.gcm %>/lib/!(namespace|login).js',
                    '<%= dirs.gcm %>/modules/**/!(namespace|login|^form$).js',
                    '<%= dirs.tmp_opm %>/templates.js',
                    '<%= dirs.tmp_common %>/templates.js',
                    '<%= dirs.src_opm %>/modules/main/namespace.js',
                    '<%= dirs.src_opm %>/modules/main/id.js',
                    '<%= dirs.src_opm %>/modules/**/!(namespace|^formbuilder$|id|app|*_deprecated).js',
                    '<%= dirs.src_opm %>/modules/main/app.js',
                    '<%= dirs.node_modules %>/snapsvg/dist/snap.svg-min.js',
                    '<%= dirs.node_modules %>/snap.svg.zpd/snap.svg.zpd.js',
                    '<%= dirs.lib %>/snap.svg/snap.svg.graffle.js',
                    //'<%= dirs.lib %>/spectrum/spectrum.js',
                    //'<%= dirs.lib %>/css-element-queries/ResizeSensor.js',
                    //'<%= dirs.lib %>/css-element-queries/ElementQueries.js',
                    '<%= dirs.lib %>/jquery.serializeJSON/jquery.serializejson.min.js',
                    '<%= dirs.lib %>/jquery-hoverIntent/jquery.hoverIntent.js',
                    '<%= dirs.node_modules %>/lodash/lodash.js',
                    '<%= dirs.node_modules %>/vue/dist/vue.min.js',
                    '<%= dirs.node_modules %>/yamljs/dist/yaml.js',
                    '<%= dirs.node_modules %>/dialog-polyfill/dialog-polyfill.js',
                    //'<%= dirs.node_modules %>/showdown/dist/showdown.js',
                    '<%= dirs.node_modules %>/markdown-it/dist/markdown-it.js',
                    '<%= dirs.node_modules %>/codemirror/lib/codemirror.js',
                    '<%= dirs.node_modules %>/codemirror/addon/runmode/colorize.js',
                    '<%= dirs.node_modules %>/codemirror/mode/javascript/javascript.js',
                    '<%= dirs.node_modules %>/codemirror/mode/yaml/yaml.js',
                    '<%= dirs.node_modules %>/codemirror/addon/lint/lint.js',
                    '<%= dirs.node_modules %>/codemirror/addon/lint/yaml-lint.js',
                    '<%= dirs.node_modules %>/codemirror/addon/selection/active-line.js',
                    '<%= dirs.node_modules %>/codemirror/addon/hint/show-hint.js',
                    '<%= dirs.node_modules %>/js-yaml/dist/js-yaml.min.js',
                    '<%= dirs.src_common %>/modules/jquery.ui.touch-punch.min.js',
                    '<%= dirs.src_common %>/scripts/panzoom.js',
                    '<%= dirs.node_modules %>/d3/dist/d3.min.js',
                    '<%= dirs.node_modules %>/d3-geo-projection/dist/d3-geo-projection.min.js'
                ],
                dest: '<%= dirs.output %>/scripts/production.min.js'
            },
            opmLogin: {
                src: [
                    '<%= dirs.gcm %>/modules/namespace.js',
                    '<%= dirs.gcm %>/modules/messaging/messaging.js',
                    '<%= dirs.gcm %>/modules/accessibility/dialogAccessibility.js',
                    '<%= dirs.gcm %>/modules/accessibility/keyCodes.js',
                    '<%= dirs.tmp_common %>/templates.js',
                    '<%= dirs.src_common %>/scripts/login/login.js',
                    '<%= dirs.gcm %>/modules/commonFunctions/commonFunctions.js',
                ],
                dest: '<%= dirs.output %>/shared/login.js'
            }
        },

        less: {
            common: {
                files: [
                    {src: ["<%= dirs.gcm %>/modules/login/an-login.less", "<%= dirs.gcm %>/fonts/an-icons.less", "<%= dirs.gcm %>/fonts/Segoe.css", "<%= dirs.gcm %>/fonts/SegMDL2.css"],
                        dest: '<%= dirs.tmp_common %>/css/an-login.css'},
                    {src: '<%= dirs.gcm %>/modules/uiGuidelines/an-uiGuidelines.less',
                        dest: '<%= dirs.tmp_common %>/css/an-uiGuidelines.css'}
                ]
            },
            opm: {
                files: [
                    {src: '<%= dirs.src_opm %>/css/an-opm.less',
                        dest: '<%= dirs.tmp_opm %>/css/an-opm.css'},
                    {src: '<%= dirs.src_opm %>/css/an-opm-dark.less',
                        dest: '<%= dirs.tmp_opm %>/css/an-opm-dark.css'},
                    {src: '<%= dirs.src_opm %>/css/an-opm-highcontrast.less',
                        dest: '<%= dirs.tmp_opm %>/css/an-opm-highcontrast.css'},
                    {src: '<%= dirs.src_opm %>/css/an-opm-wireframe.less',
                        dest: '<%= dirs.tmp_opm %>/css/an-opm-wireframe.css'},
                    // Update: Move ao5gc specific icon css to below files    
                    // {src: '<%= dirs.src_opm %>/css/affirmed.less',
                    //     dest: '<%= dirs.output %>/css/affirmed.css'},
                    // {src: '<%= dirs.src_opm %>/css/ao5gc.less',
                    //     dest: '<%= dirs.output %>/css/ao5gc.css'}
                ]
            }
        },

        cssmin: {
            options: {
                shorthandCompacting: false,
                roundingPrecision: -1,
                sourceMap: true,
                sourceMapInlineSources: true
            },
            opm: {
                files: [
                    {src: ['<%= dirs.tmp_opm %>/css/an-opm.css', '<%= dirs.node_modules %>/codemirror/addon/hint/show-hint.css'],
                        dest: '<%= dirs.output %>/css/opm.min.css'},
                    {src: ['<%= dirs.tmp_opm %>/css/an-opm-dark.css', '<%= dirs.node_modules %>/codemirror/addon/hint/show-hint.css'],
                        dest: '<%= dirs.output %>/css/opm-dark.min.css'},
                    {src: ['<%= dirs.tmp_opm %>/css/an-opm-highcontrast.css', '<%= dirs.node_modules %>/codemirror/addon/hint/show-hint.css'],
                        dest: '<%= dirs.output %>/css/opm-highcontrast.min.css'},
                    {src: ['<%= dirs.tmp_opm %>/css/an-opm-wireframe.css'],
                        dest: '<%= dirs.output %>/css/opm-wireframe.min.css'},
                    {src: '<%= dirs.tmp_common %>/css/an-login.css',
                        dest: '<%= dirs.output %>/css/opm.login.min.css'},
                    {src: '<%= dirs.tmp_common %>/css/an-uiGuidelines.css',
                        dest: '<%= dirs.output %>/css/opm.uiGuidelines.min.css'}
                ]
            }
        },

        copy: {
            opm: {
                files: [
                    /*{src: '<%= dirs.gcm %>/fonts/an-glyphs/*',
                        dest: '<%= dirs.output %>/fonts/', expand: true, flatten: true},*/
                    {src: ['<%= dirs.gcm %>/fonts/*.css','<%= dirs.gcm %>/fonts/*.less', '<%= dirs.gcm %>/fonts/*.eot',
                    '<%= dirs.gcm %>/fonts/*.svg','<%= dirs.gcm %>/fonts/*.ttf','<%= dirs.gcm %>/fonts/*.woff', '<%= dirs.gcm %>/fonts/*.min','<%= dirs.gcm %>/fonts/*.map'],
                        dest: '<%= dirs.output %>/css/', expand: true, flatten: true},
                    {src: '<%= dirs.gcm %>/svg/**',
                        dest: '<%= dirs.output %>/svg/', expand: true, flatten: true},
                    // {src: '<%= dirs.gcm %>/css/images/*',
                    //     dest: '<%= dirs.output %>/css/images/', expand: true, flatten: true, filter: 'isFile'},
                    {src: ['<%= dirs.gcm %>/images/apple-touch-icon-167.png', '<%= dirs.gcm %>/images/Default-Landscape.png',
                    '<%= dirs.gcm %>/images/favicon.ico', '<%= dirs.gcm %>/images/favicon.svg', '<%= dirs.gcm %>/images/graphpaper-dark.png', '<%= dirs.gcm %>/images/graphpaper.png',
                    '<%= dirs.gcm %>/images/scrim.png', '<%= dirs.gcm %>/images/warning.png'],
                        dest: '<%= dirs.output %>/images/', expand: true, flatten: true, filter: 'isFile'},
                    {src: '<%= dirs.src_opm %>/images/*',
                        dest: '<%= dirs.output %>/images/', expand: true, flatten: true, filter: 'isFile'},
                    {src: '<%= dirs.src_opm %>/html/opm.htm',
                        dest: '<%= dirs.output %>/html/opm.html'},
                    {src: '<%= dirs.src_opm %>/html/opm-ao5gc.html',
                        dest: '<%= dirs.output %>/html/opm-ao5gc.html'},
                    {src: '<%= dirs.src_opm %>/html/opm-auth.html',
                        dest: '<%= dirs.output %>/html/opm-auth.html'},
                    {src: '<%= dirs.src_common %>/scripts/login/manifest.json',
                        dest: '<%= dirs.output %>/manifest.json'},

                    {src: '<%= dirs.tmp_pre %>/scripts/pre.min.js',
                        dest: '<%= dirs.output %>/shared/pre.min.js'},
                    {src: '<%= dirs.gcm %>/modules/uiGuidelines/uiGuidelines.handlebars',
                        dest: '<%= dirs.output %>/html/uiGuidelines.html'},
                    {src: '<%= dirs.tmp_pre %>/scripts/pre.min.js.map',
                        dest: '<%= dirs.output %>/shared/pre.min.js.map'},
                     {src: '<%= dirs.src_opm %>/modules/json/worldMapwCountries.geojson',
                         dest: '<%= dirs.output %>/json/', expand: true, flatten: true},
                    {src: '<%= dirs.gcm %>/modules/commonFunctions/mapDeviceIcons.json',
                        dest: '<%= dirs.output %>/json/', expand: true, flatten: true},
                    {src: '<%= dirs.src_common %>/scripts/help/helpFile.handlebars',
                        dest: '<%= dirs.output %>/html/helpFile.html'
                    }
                ]
            },
            opmLogin: {
                files: [
                    {src: '<%= dirs.src_common %>/scripts/login/Azure-Operator-5G-Core.svg',
                        dest: '<%= dirs.output %>/images/Azure-Operator-5G-Core.svg'
                    }
                ]
            },
            php: {
                files: [
                    {src: './scripts/*.php',
                        dest: '<%= dirs.output %>/php/'}
                ]
            }
        },

        'compile-handlebars': {
            opmLogin: {
                files: [{
                    src: '<%= dirs.src_common %>/scripts/login/login.handlebars',
                    dest: '<%= dirs.output %>/index.html'
                },
                {
                    src: '<%= dirs.src_common %>/scripts/login/login-ao5gc.handlebars',
                    dest: '<%= dirs.output %>/index-ao5gc.html'
                },
                {
                    src: '<%= dirs.src_common %>/scripts/help/helpFile.handlebars',
                    dest: '<%= dirs.output %>/helpFile.html'
                }
            ],
                templateData: {
                    applicationName: 'Azure Operator 5G Core',
                    shortName: 'AO5GC',
                    htmlTitle: 'Azure Operator 5G Core',
                    applicationSubName: 'Operations & Policy Management',
                    buildCopyRightYear: new Date().getFullYear()
                }
            }
        },

        'concurrent' : {
            work: ['opm_work']
        }

    });

    // load all grunt tasks matching the ['grunt-*', '@*/grunt-*'] patterns
    require('load-grunt-tasks')(grunt);

    //grunt.registerTask('pre_work', ['clean:all']);
    //grunt.registerTask('post_work', ['copy:all']);
    grunt.registerTask('pre_work',          ['clean:all', 'concat:pre']);
    grunt.registerTask('common_work',       ['less:common',  'handlebars:common']);

    grunt.registerTask('opm_work',     ['handlebars:opm', 'less:opm', 'cssmin:opm', 'uglify:opm', 'uglify:opmLogin', 'copy:opm', 'copy:php', 'compile-handlebars:opmLogin', 'clean:tmp']);
    grunt.registerTask('opm_dev',      ['clean:common','clean:opm', 'common_work', 'cni_work']);

    grunt.registerTask('default', ['pre_work', 'common_work', 'concurrent:work']);
};