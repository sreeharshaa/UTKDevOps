OPM$.certManagement = OPM$.certManagement || {};

OPM$.certManagement.certController = (function() {

    function launchCertManagerDialog() {
        if($('#certManager').length === 0) {
            var html = Handlebars.templates['certManagement_certManagementDialog']();
            $('body').append(html);

            GCM$.common_functions.inputFile();
            VALIDATION$.validateOnInputChange($('#certManager form'), $('#buttonsDiv button'), undefined, undefined, undefined, true);

            $("#certManager").hide().fadeIn().draggable({
                handle: "header"
            }).position({
                my: "center",
                at: "center",
                of: "body"
            });

            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#certManager'));
            $('#certManager :tabbable')[0].focus();
        }
    }

    function importCert() {
        var formData = VALIDATION$.getData($('#certManager form'));
        formData.certInfo = JSON.stringify($('#showCert').text());
        $('#certManager').activity();

        formData.certFile = formData.certFile.split( '\\' ).pop();
        OPM$.certManagement.certService.importCert(formData)
            .done(function (data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                $('#certManager').activity(false);
                GCM$.common_functions.closeDialog('certManager');
            }).always(function () {
                $('#certManager').activity(false);
        });
    }

    function deleteCert() {
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete it?',
            position: {my: 'left top', at: 'right bottom', of: $(event.target)},
            yes: function () {
                doDeleteCert();
            }
        });
    }

    function doDeleteCert() {
        var formData = VALIDATION$.getData($('#certManager form'));
        $('#certManager').activity();
        formData.certFile = formData.certFile.split( '\\' ).pop();
        OPM$.certManagement.certService.deleteCert(formData)
            .done(function (data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                $('#showCert').empty();
            }).always(function () {
                $('#certManager').activity(false);
        });
    }

    function handleFileSelect(evt) {
        var files = evt.target.files;	// FileList object
        var textType = "application/x-x509-ca-cert";
        var fileDisplayArea = $('#showCert');

        // files is a FileList of File objects.  List some properties
        var output = [];
        for (var i = 0, f; f = files[i]; i++) {
            output.push("File: " + escape(f.name), ' (', f.type || 'n/a', ') - ',
                f.size, ' bytes, last modified: ', f.lastModifiedDate ? f.lastModifiedDate.toLocaleDateString() : 'n/a');
            importFname = escape(f.name);
        }
        fileDisplayArea.append('<ul>' + output.join(' ') + '</ul>');

        // only process .crt files.
        for (var i = 0, f; f = files[i]; i++) {
            // loop through the FileList and render files
            //if (f.type.match(textType)) {
            if (importFname.endsWith(".pem") || importFname.endsWith(".crt") || importFname.endsWith(".cer") ) {
                var reader = new FileReader();

                // closure to capture file informaiton
                reader.onload = function(e) {
                    fileDisplayArea.text(reader.result);
                };

                // Read in the file as a Text File
                reader.readAsText(f);
            } else {
                fileDisplayArea.text("File type not supported!");
            }
        }
    }

    function checkCertificateExpiry() {
        OPM$.certManagement.certService.checkCertificateExpiry()
            .done(function (data) {
            try {
                if (data && data.expiredCertificates) {
                var jsonBody = JSON.parse(data.expiredCertificates);
                if (jsonBody.certExpiryNotify) {
                    var certMsgView = $("#banner-message");    
                    certMsgView.css('display', 'block');
                    certMsgView.html('<span style="position: absolute; display: flex; justify-content: center; align-items: center; width: 100%; height: 100%;"><i title="' + jsonBody.certExpiryMsg + '" class="an-icon WARNING an-icon-warning" style="float: none; position:unset;">' + jsonBody.certExpiryMsg + '</i></span>');
                }
                } else {
                    console.error("No expiredCertificates found in response.");
                }
            } catch (error) {
                console.error("Error parsing expiredCertificates: ", error);
            }
            })
    }

    /*function onSelectRegistry(e) {
        var selectedVal = $(e.target).val();
        if(selectedVal === "openstack"){
            $('#openstackProtocolType').show();
        } else {
            $('#openstackProtocolType').hide();
        }
    }*/

    return {
        launchCertManagerDialog: launchCertManagerDialog,
        deleteCert: deleteCert,
        importCert: importCert,
        //onSelectRegistry: onSelectRegistry,
        handleFileSelect: handleFileSelect,
        checkCertificateExpiry: checkCertificateExpiry
  };

})();
