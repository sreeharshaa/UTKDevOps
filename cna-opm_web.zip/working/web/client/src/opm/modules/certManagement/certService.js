OPM$.certManagement = OPM$.certManagement || {};

OPM$.certManagement.certService = (function() {

    function importCert(jsonData) {
        return POST_JSON$({
            url: '/opm/cert/import',
            data:  JSON.stringify(jsonData)
        });
    }

    function deleteCert(jsonData) {
        return  $.ajax(
            {
                type: "DELETE", dataType: 'json',
                contentType: 'application/json',
                url: '/opm/cert/delete',
                data: JSON.stringify(jsonData)
            });
    }

    function checkCertificateExpiry() {
        return GET_JSON$('/opm/cert/certificateExpiry');
    }

    return {
        deleteCert: deleteCert,
        importCert: importCert,
        checkCertificateExpiry: checkCertificateExpiry
    };

})();
