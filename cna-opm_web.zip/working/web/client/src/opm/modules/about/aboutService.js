OPM$.about = OPM$.about || {};

OPM$.about.aboutService = (function() {

    function putNewVersion(jsonData, $depId, $contId) {
        return POST_JSON$({
            url: "/opm/ms/putVersion/"+$depId+"/"+$contId,
            data: JSON.stringify(jsonData)
        });
    }

    function getCurrentVersionRest($depId, $contId) {
        return GET_JSON$("/opm/ms/getVersion/"+$depId+"/"+$contId);
    }

    function getVersionData() {
        return GET_JSON$("/opm/ms/getOpmVersion");
    }

    function getSelfOpm(){
        return GET_JSON$("/opm/cloudmap/getSelfOPM");
    }

    function getLogLevel(serviceName){
        return GET_JSON$("/opm/ms/getLogLevel/"+ serviceName);
    }

    function updateLogLevel(serviceName, jsonData){
        return POST_JSON$({
            url: "/opm/ms/updateLogLevel/"+serviceName,
            data: JSON.stringify(jsonData)
        });
    }

    return {
        putNewVersion: putNewVersion,
        getCurrentVersionRest: getCurrentVersionRest,
        getVersionData: getVersionData,
        getSelfOpm:getSelfOpm,
        getLogLevel: getLogLevel,
        updateLogLevel: updateLogLevel
    }
})();