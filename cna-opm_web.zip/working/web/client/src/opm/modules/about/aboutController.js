OPM$.about = OPM$.about || {};

OPM$.about.aboutController = (function () {

    var myStackId = "";
    var myClusterToken = "";
    var myVnfMgrOsRmId = "vnfmgr-osrm-";
    var myVnfMgrK8RmId = "vnfmgr-k8rm-";
    var webTries = 0;
    var apigwTries = 0;
    var chartEditorTries = 0;
    var masterTries = 0;
    var masterDbTries = 0;
    var osRmTries = 0;
    var k8sRmTries = 0;
    var mongoTries = 0;
    var dregTries = 0, dialogIsActive = false;
    var resinvTries = 0, azrmTries = 0;
    var selfOpmData = {};
    var opmMode = '';
    var azure = false;
    var opmDreg = "true";

    function launchAboutDialog() {

        if ($('#aboutDialog').length < 1) {
            var data = {};
            OPM$.about.aboutService.getSelfOpm().done(function (selfOpmRes) {
                data.enableClusterView = true;
                selfOpmData = selfOpmRes;
            }).fail(function (error) {
                data.enableClusterView = false;
            }).always(function () {
                OPM$.DzAndCluster.dz.dzService.isInternalUse().done(function (res) {
                    data.res = res;
                    OPM$.sysConfig.sysConfigService.getSysConfig().done(function (sysConfig) {
                        data.sysConfig = sysConfig;
                        opmMode = sysConfig.mode;
                        azure = sysConfig.azure;
                        opmDreg = sysConfig.opmDreg;
                        var html = Handlebars.templates['about_aboutDialog'](data);
                        $('body').append(html);
                        dialogIsActive = true;

                        $('#aboutDialog').hide().fadeIn().draggable({
                            handle: "header"
                        }).position({
                            at: "center",
                            my: "center",
                            of: "body"
                        });
                        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#aboutDialog'));
                        $('#aboutDialog').on('keyup', function (e) {
                            if (e.keyCode === GCM_KEY$.ESCAPE) {
                                e.stopPropagation();
                                GCM$.common_functions.closeDialog('aboutDialog');
                            }
                        })
                        $('#aboutDialog :tabbable')[0].focus();
                        if (data.enableClusterView) {
                            $('#clusterViewBtn').removeAttr('disabled');
                        }
                        // Get all current versions button
                        $("#currentVersionsButton").button().on('click', function () {
                            getCurrentVersionRest("vnfmgr-web", "vnfmgr-web", $("#webServerVerId"), $("#webServerResults"), webTries);
                            getCurrentVersionRest("vnfmgr-apigw", "vnfmgr-apigw", $("#apigwId"), $("#apigwResults"), apigwTries);
                            getCurrentVersionRest("vnfmgr-chart-editor", "vnfmgr-chart-editor", $("#chartEditorId"), $("#chartEditorResults"), chartEditorTries)
                            getCurrentVersionRest("vnfmgr-master-rm", "vnfmgr-master-rm", $("#masterResMgrId"), $("#masterResMgrResults"), masterTries)
                            getCurrentVersionRest(myVnfMgrOsRmId, myVnfMgrOsRmId, $("#osResMgrId"), $("#osResMgrResults"), osRmTries);
                            getCurrentVersionRest(myVnfMgrK8RmId, myVnfMgrK8RmId, $("#k8sResMgrId"), $("#k8sResMgrResults"), k8sRmTries);
                            if(!(opmMode == "multiNode" && azure == true)){
                                getCurrentVersionRest("vnfmgr-db", "vnfmgr-db", $("#mongoDbMgrId"), $("#mongoDbMgrResults"), mongoTries);
                                if ( opmDreg != "false") {
                                    getCurrentVersionRest("vnfmgr-dreg", "vnfmgr-dreg", $("#dockerRegMgrId"), $("#dockerRegMgrResults"), dregTries);
                                }
                            }
                            else{
                                $("#mongoDbMgrId").val("not applicable for azure multinode");
                                $("#dockerRegMgrId").val("not applicable for azure multinode");
                            }
                            getCurrentVersionRest("vnfmgr-resinv", "vnfmgr-resinv", $("#resInvId"), $("#resInvResults"), resinvTries);
                            getCurrentVersionRest("vnfmgr-azrm", "vnfmgr-azrm", $("#azRegMgrId"), $("#azRegMgrResults"), azrmTries);
                        }) //end button click


                        // Upgrade buttons
                        $("#webSrvUpgrade").button().on('click', function () {

                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Web Server Service?",
                                yes: function () {
                                    putNewVersion("vnfmgr-web", "vnfmgr-web", $('#webServerVerId'), $("#webServerResults"), webTries);
                                    MSG$.showInfoMsg({ content: 'Close your browser after web server upgrade!' });
                                }
                            });
                        }) //end button click
                        $("#apigwUpgrade").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Web API GW Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-apigw", "vnfmgr-apigw", $('#apigwId'), $("#apigwResults"));
                                }
                            });
                        })
                        $("#chartEditorUpgrade").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Chart Editor Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-chart-editor", "vnfmgr-chart-editor", $('#chartEditorId'), $("#chartEditorResults"));
                                }
                            });
                        })
                        $("#masterRmButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Master Resource Manager Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-master-rm", "vnfmgr-master-rm", $('#masterResMgrId'), $("#masterResMgrResults"));
                                }
                            });
                        })
                        $("#masterRmDbButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Master RM Database Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-master-rm", "vnfmgr-db-init", $('#masterRmDbId'), $("#masterRmDbResults"), masterDbTries);
                                }
                            });
                        })
                        $("#osRmButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Openstack RM Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion(myVnfMgrOsRmId, myVnfMgrOsRmId, $('#osResMgrId'), $("#osResMgrResults"), osRmTries);
                                }
                            });
                        })
                        $("#k8RmButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Kubernetes RM Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion(myVnfMgrK8RmId, myVnfMgrK8RmId, $('#k8sResMgrId'), $("#k8sResMgrResults"), k8sRmTries);
                                }
                            });
                        })
                        $("#mongoDbMgrButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Mongo DB Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-db", "vnfmgr-db", $('#mongoDbMgrId'), $("#mongoDbMgrResults"), mongoTries);
                                }
                            });
                        })
                        $("#dockerRegMgrButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Docker Registry Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-dreg", "vnfmgr-dreg", $('#dockerRegMgrId'), $("#dockerRegMgrResults"), dregTries);
                                }
                            });
                        })
                        $("#azRegMgrButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your Azure Registry Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-azrm", "vnfmgr-azrm", $("#azRegMgrId"), $("#azRegMgrResults"), azrmTries);
                                }
                            });
                        })
                        $("#resInvButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your Resource Inventory Service?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion("vnfmgr-resinv", "vnfmgr-resinv", $("#resInvId"), $("#resInvResults"), resinvTries);
                                }
                            });
                        })
                        $("#upgradeAllButton").button().on('click', function () {
                            MSG$.confirm({
                                statement: 'Confirmation',
                                question: "Are you sure you want to upgrade your OPM Micro-services?",
                                position: { my: 'left top', at: 'right bottom', of: $(this), collision: 'flipfit' },
                                yes: function () {
                                    putNewVersion(myVnfMgrOsRmId, myVnfMgrOsRmId, $('#osResMgrId'), $("#osResMgrResults"));
                                    putNewVersion(myVnfMgrK8RmId, myVnfMgrK8RmId, $('#k8sResMgrId'), $("#k8sResMgrResults"));
                                    putNewVersion("vnfmgr-master-rm", "vnfmgr-db-init", $('#masterRmDbId'), $("#masterRmDbResults"));
                                    putNewVersion("vnfmgr-master-rm", "vnfmgr-master-rm", $('#masterResMgrId'), $("#masterResMgrResults"));
                                    putNewVersion("vnfmgr-apigw", "vnfmgr-apigw", $('#apigwId'), $("#wapigwResults"));
                                    putNewVersion("vnfmgr-chart-editor", "vnfmgr-chart-editor", $('#chartEditorVerId'), $("#chartEditorResults"));
                                    putNewVersion("vnfmgr-web", "vnfmgr-web", $('#webServerVerId'), $("#webServerResults"));
                                    putNewVersion("vnfmgr-db", "vnfmgr-db", $('#mongoDbMgrId'), $("#mongoDbMgrResults"));
                                    if ( opmDreg != "false") {
                                        putNewVersion("vnfmgr-dreg", "vnfmgr-dreg", $('#dockerRegMgrId'), $("#dockerRegMgrResults"));
                                    }
                                    putNewVersion("vnfmgr-azrm", "vnfmgr-azrm", $('#azRegMgrId'), $("#azRegMgrResults"));
                                    putNewVersion("vnfmgr-resinv", "vnfmgr-resinv", $("#resInvId"), $("#resInvResults"));
                                }
                            });
                        })

                        getVersionData();

                        // Get the current versions
                        getCurrentVersionRest("vnfmgr-web", "vnfmgr-web", $("#webServerVerId"), $("#webServerResults"), webTries);
                        getCurrentVersionRest("vnfmgr-apigw", "vnfmgr-apigw", $("#apigwId"), $("#apigwResults"), apigwTries);
                        getCurrentVersionRest("vnfmgr-chart-editor", "vnfmgr-chart-editor", $("#chartEditorId"), $("#chartEditorResults"), webTries);
                        getCurrentVersionRest("vnfmgr-master-rm", "vnfmgr-master-rm", $("#masterResMgrId"), $("#masterResMgrResults"), masterTries)
                        getCurrentVersionRest("vnfmgr-master-rm", "vnfmgr-db-init", $("#masterRmDbId"), $("#masterRmDbResults"), masterDbTries);
                        getCurrentVersionRest(myVnfMgrOsRmId, myVnfMgrOsRmId, $("#osResMgrId"), $("#osResMgrResults"), osRmTries);
                        getCurrentVersionRest(myVnfMgrK8RmId, myVnfMgrK8RmId, $("#k8sResMgrId"), $("#k8sResMgrResults"), k8sRmTries);
                        if(!(opmMode == "multiNode" && azure == true)){
                            getCurrentVersionRest("vnfmgr-db", "vnfmgr-db", $("#mongoDbMgrId"), $("#mongoDbMgrResults"), mongoTries);
                            if ( opmDreg != "false") {
                                getCurrentVersionRest("vnfmgr-dreg", "vnfmgr-dreg", $("#dockerRegMgrId"), $("#dockerRegMgrResults"), dregTries);
                            } else {
                                $("#dockerRegMgrId").val("Not applicable when opmDreg is disabled").prop("readonly", true);
                            }
                        }
                        else{
                            $("#mongoDbMgrId").val("not applicable for azure multinode");
                            $("#dockerRegMgrId").val("not applicable for azure multinode");
                        }
                        getCurrentVersionRest("vnfmgr-resinv", "vnfmgr-resinv", $("#resInvId"), $("#resInvResults"), resinvTries);
                        getCurrentVersionRest("vnfmgr-azrm", "vnfmgr-azrm", $("#azRegMgrId"), $("#azRegMgrResults"), azrmTries);

                        getLogLevel('vnfmgr-apigw', 'apigwLoglevel');
                        getLogLevel('vnfmgr-resinv', 'resInvLoglevel');
                        getLogLevel('vnfmgr-master-rm', 'masterRmLoglevel');
                        //getLogLevel('vnfmgr-osrm', 'osRmLoglevel');
                        getLogLevel('vnfmgr-k8rm', 'k8RmLoglevel');
                       // getLogLevel('vnfmgr-azrm', 'azRmLoglevel');
                        setTimeout(UpdateStats, 90000);

                        //getUserLogin();
                    });
                });
            });
        }
    }

    /*function getUserLogin() {
        $.post("./scripts/getUserLogin.php", {},
            function(data) {
                console.log(data);
                //var obj = JSON.parse(data);

                $("#userLogin").html('<img alt="user" src="./images/user-icon.png" style="border: none">' + data);
            }
        ) //end post
    }*/

    function putNewVersion($depId, $contId, $output, $status, $tries) {
        var _newVersion = $output.val();
        var encoded = {
            image: _newVersion
        };
        $status.activity({ width: 2 }).find('i').hide();
        OPM$.about.aboutService.putNewVersion(encoded, $depId, $contId)
            .done(function (data) {
                if (data.successMessage === "OK") {
                    $status.activity(false).find('i').show();
                    MSG$.showInfoMsg({ status: "Success", content: "Micro-service upgraded successfully" })
                } else {
                    $status.activity({ width: 2 }).find('i').hide();
                    getCurrentVersionRest($depId, $contId, $output, $status, $tries);
                }
            }
            ).fail(function (data) {
                $status.activity(false);
            });
    }

    function getVersionData() {
        OPM$.about.aboutService.getVersionData()
            .done(function (data) {
                var html = Handlebars.templates['about_opmVersionData'](data.opmVersion);
                $('#opmVersionData').append(html);
            }
            )
    }

    function getCurrentVersionRest($depId, $contId, $output, $status, $tries) {
        OPM$.about.aboutService.getCurrentVersionRest($depId, $contId)
            .done(function (data) {
                //console.log("getCurrentVersionRest=" + data);

                var data1 = data.replace(/\"/g, "");
                words = data1.split(",")
                if (words[1].indexOf("Not Created") == 0) {
                    $status.empty().append("<i class='an-icon an-icon-checkmark' title='Not Created'></>");
                } else if (words[1].indexOf("Running") == 0) {
                    $status.empty().append("<i class='an-icon an-icon-checkmark' title='Running'></>");
                } else {
                    $tries = $tries + 1
                    if ($tries > 5) {
                        $status.empty().append("<i class='an-icon an-icon-checkmark' title=' + words[1] + '> </>");
                    } else {
                        if (dialogIsActive) {
                            setTimeout(getCurrentVersionRest, 10000, $depId, $contId, $output, $status, $tries);
                        }
                    }
                }

                $output.val(words[0]);
            }
            )
    }

    function UpdateStats() {

        var _webTries = 0;
        var _apigwTries = 0;
        var _chartEditorTries = 0;
        var _masterTries = 0;
        var _masterDbTries = 0;
        var _osRmTries = 0;
        var _k8sRmTries = 0;
        var _mongoTries = 0;
        var _dregTries = 0, _resinvTries = 0, _azrmTries = 0;


        if (dialogIsActive) {
            // Get the current versions
            getCurrentVersionRest("vnfmgr-web", "vnfmgr-web", $("#webServerVerId"), $("#webServerResults"), _webTries);
            getCurrentVersionRest("vnfmgr-apigw", "vnfmgr-apigw", $("#apigwId"), $("#apigwResults"), _apigwTries);
            getCurrentVersionRest("vnfmgr-chart-editor", "vnfmgr-chart-editor", $("#chartEditorId"), $("#chartEditorResults"), _chartEditorTries)
            getCurrentVersionRest("vnfmgr-master-rm", "vnfmgr-db-init", $("#masterRmDbId"), $("#masterRmDbResults"), _masterDbTries);
            getCurrentVersionRest(myVnfMgrOsRmId, myVnfMgrOsRmId, $("#osResMgrId"), $("#osResMgrResults"), _osRmTries);
            getCurrentVersionRest(myVnfMgrK8RmId, myVnfMgrK8RmId, $("#k8sResMgrId"), $("#k8sResMgrResults"), _k8sRmTries);
            if(!(opmMode == "multiNode" && azure == true)){
                getCurrentVersionRest("vnfmgr-db", "vnfmgr-db", $("#mongoDbMgrId"), $("#mongoDbMgrResults"), _mongoTries);
                if ( opmDreg != "false") {
                    getCurrentVersionRest("vnfmgr-dreg", "vnfmgr-dreg", $("#dockerRegMgrId"), $("#dockerRegMgrResults"), _dregTries);
                }
            }
            else{
                $("#mongoDbMgrId").val("not applicable for azure multinode");
                $("#dockerRegMgrId").val("not applicable for azure multinode");
            }
            getCurrentVersionRest("vnfmgr-resinv", "vnfmgr-resinv", $("#resInvId"), $("#resInvResults"), _resinvTries);
            getCurrentVersionRest("vnfmgr-azrm", "vnfmgr-azrm", $("#azRegMgrId"), $("#azRegMgrResults"), _azrmTries);

            setTimeout(UpdateStats, 90000);
        }
    }

    function closeDlg() {
        dialogIsActive = false;
        GCM$.common_functions.closeDialog('aboutDialog');
    }

    function launchClusterView() {
        var clusterData = {
            'deploymentZones': [{ 'id': selfOpmData.id, 'type': selfOpmData.type }],
            'forceRefresh': false
        }
        OPM$.cloudMap.cloudMapController.renderCloudMap(clusterData)
        closeDlg();
    }

    function refreshDzDiscoverCache() {
        $('#dzDiscoveryRefreshBtn').activity()
        OPM$.sysConfig.sysConfigService.refreshDzDiscoverCache().done(function (data) {
            MSG$.showInfoMsg({ status: 'Success', content: 'Cache refreshed successfully' });
        }).always(function () {
            $('#dzDiscoveryRefreshBtn').activity(false);
        });
    }

    function getLogLevel(serviceName, selectId){
        OPM$.about.aboutService.getLogLevel(serviceName).done(function (data){
            $("#"+selectId).val(data[serviceName]);
        });
    }

    function updateLogLevel(serviceName, selectId){
        var loglevel = $('#'+selectId).val();
        var jsonData = {
            'loglevel': loglevel
        }
        OPM$.about.aboutService.updateLogLevel(serviceName, jsonData).done(function (data){
            MSG$.showInfoMsg({ status: 'Success', content: 'Log level updated successfully for '+ serviceName });
        });
    }

    return {
        launchAboutDialog: launchAboutDialog,
        closeDlg: closeDlg,
        getVersionData: getVersionData,
        launchClusterView: launchClusterView,
        refreshDzDiscoverCache: refreshDzDiscoverCache,
        updateLogLevel: updateLogLevel
    }

})();
