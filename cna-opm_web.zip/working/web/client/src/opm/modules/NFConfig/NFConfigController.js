OPM$.NFConfig = OPM$.NFConfig || {};

OPM$.NFConfig.NFConfigController = (function(){
    var vueInstance;
    var selectedGroup = {};
    function launchNFConfigDialog(type) {

        if ($('#NFConfigDialog').length > 0){
            $('#NFConfigDialog').detach();
        }

        var html = Handlebars.templates['NFConfig_NFConfigDialog']({type: type});
        $('main > .an-layout-center-center').append(html);
        $("#NFConfigDialog").hide().fadeIn().resizable().draggable({
             handle: "header"
        }).position({
             my: "center",
             at: "center",
             of: ".an-layout-center-center"
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#NFConfigDialog'), false);
        addNfConfigTableData()

    }

    function addNfConfigTableData() {
        $('#nfConfigPane').activity();
        var type = $("#NFConfigDialog").hasClass("cn-simplified") ? 'simplified': 'snapshot';
        OPM$.NFConfig.NFConfigService.getConfigSets(type).done(function (formData) {
            _.forEach(formData.NFConfigSets, function (nfConfigSet){
                var timestamp = new Date(parseInt(nfConfigSet.createdTimestamp));
                var dateArray = timestamp.toDateString().split(' ');
                var timeArray = timestamp.toTimeString().split(' ')[0].split(':');
                var minimizedTimestamp = dateArray[0] + ' '+ dateArray[1] + ' '+ dateArray[2]+ ' ' + timeArray[0] + ':' + timeArray[1];
                nfConfigSet.minimizedTimestamp = minimizedTimestamp;
                nfConfigSet.timestamp = timestamp.toString();
                if(nfConfigSet.updatedTimestamp !== "") {
                    var timestampUpdate = new Date(parseInt(nfConfigSet.updatedTimestamp));
                    var dateArrayUpdate = timestampUpdate.toDateString().split(' ');
                    var timeArrayUpdate = timestampUpdate.toTimeString().split(' ')[0].split(':');
                    var minimizedTimestampUpdate = dateArrayUpdate[0] + ' ' + dateArrayUpdate[1] + ' ' + dateArrayUpdate[2]
                        + ' ' + timeArrayUpdate[0] + ':' + timeArrayUpdate[1];
                    nfConfigSet.minUpdatedTimestamp = minimizedTimestampUpdate;
                    nfConfigSet.updatedTimestamp = timestampUpdate.toString();
                }
                nfConfigSet.tooltip = {
                    'id' : nfConfigSet.clusterId,
                    'name' : nfConfigSet.name,
                    'cluster name' : nfConfigSet.clusterName,
                    'createdTimestamp' : nfConfigSet.minimizedTimestamp,
                    'updatedTimestamp' : nfConfigSet.minUpdatedTimestamp,
                    'description' : nfConfigSet.description
                }
            });
            setTimeout(function (){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                var sortedData = _.sortBy(formData.NFConfigSets, function (o) {
                    return o.name
                })
                var data = {
                    NFConfigSets: sortedData,
                    type: type
                }
                var html = Handlebars.templates['NFConfig_configPane'](data);
                $('#nfConfigPane').empty().append(html);
                setTimeout(function (){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                GCM$.accessibility.tableAccessibility.makeTableKeyNav($("#configSetList"), "[id^='row']");
                },100);
                dataBindForm(data)
            }, 100);
            toggleConfigSelections(true);
        }).always(function () {
            $('#nfConfigPane').activity(false);
        })
    }

    function launchSnapshotDialog(){
        if ($('#snapshotDialog').length < 1){
        var snap = Handlebars.templates['NFConfig_snapshotDialog']();
        $('body').append(snap);
        $("#snapshotDialog").hide().fadeIn().resizable().draggable({
            handle: "header"
        }).position({
            my: "center",
            at: "center",
            of: "body"
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#snapshotDialog'));
    }
    }

    function fileSelected(formSelected){
        var res = false, form;
        form = $(formSelected)[0];

        if(form){
            res= form.checkValidity();
        }
        return res;
    }

    function launchImportConfigDialog(){
        if ($('#importConfigDialog').length < 1){
        var snap = Handlebars.templates['NFConfig_importDialog']();
        $('#NFConfigDialog').append(snap);

        $("#importConfigDialog").hide().fadeIn().draggable({
            handle: "header"
        }).position({
            my: "center",
            at: "center",
            of: "body"
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#importConfigDialog'));
        $("#importConfigDialog").css({'left': '265px' , 'top' : '70px'})
        if($(window).width() < 1100)
            $("#importConfigDialog").css({'left': '0px'});
        $("#importConfigSetForm").find("input[name=file]").on('change', function(){
            if(fileSelected("#importConfigSetForm"))
                $('#importCluster').prop('disabled', false);
            else
                $('#importCluster').prop('disabled', true);
        });
       GCM$.common_functions.inputFile();

        $("#importCluster").off().on('click', function (event) {
            event.preventDefault();
            var fileData = new FormData($('#importConfigSetForm')[0]),
                type = $('#NFConfigDialog').hasClass('cn-simplified') ? 'simplified' : 'snapshot';
            importConfigSet(fileData, type);
        });
        }
    }


    function toggleRowContents(id) {
        var subRowTd$ = $($("#subRow-"+id).children('td')[0])
        var scrollTriangle$ =  $('#scroll-triangle-'+id)
        if($('#subRow-'+id).is(':hidden')) {
            $('#subRow-'+id).show();
            scrollTriangle$.children('i').first().toggleClass('an-scroll-triangle-expanded an-scroll-triangle-collapsed')
            scrollTriangle$.attr('aria-expanded', 'true');
            scrollTriangle$.attr('title',"Collapse configuration set "+ vueInstance.$data.NFConfigSets[id].name)
            GCM$.accessibility.tableAccessibility.makeTableKeyNav($("#NfAndPaasContainer-"+id), "[id^='subTableRow']");
            //Adjust scroll after expand to show the expanded table's parent row
            var scrollEle = document.getElementById('scroll-triangle-'+id)
            scrollEle.scrollIntoViewIfNeeded();
            var checkboxList$ = $('#NfAndPaasContainer-'+id).find('div[role="checkbox"]')
            //Blocking the auto scroll on space key press
            _.forEach(checkboxList$, function(chkbx){
                $(chkbx).off().on('keydown', function(e){
                    if(e.keyCode == GCM_KEY$.SPACE){
                        e.preventDefault();                      
                    }
                });
            })
            
        }
        else{
            $('#subRow-'+id).hide();
            scrollTriangle$.children('i').first().toggleClass('an-scroll-triangle-expanded an-scroll-triangle-collapsed')
            scrollTriangle$.attr('aria-expanded', 'false');
            scrollTriangle$.attr('title',"Expand configuration set "+ vueInstance.$data.NFConfigSets[id].name)
            $("#NfAndPaasContainer-"+id).off();
            $($("#row-"+id).children('td')[0]).focus();
        }
    }

    function launchExportDialog() {
        if ($('#exportConfigDialog').length < 1){
        var data = VUE$.getDataFromApp(vueInstance)
        var selectedList = []
        _.forEach(data.NFConfigSets, function(cluster,i){
            if(cluster.selected) {
                selectedList.push(cluster);
            }
        });
        if(selectedList.length === 1) {
            var cluster = selectedList[0];
            var formData = {
                name : cluster.name
            }
            var snap = Handlebars.templates['NFConfig_export'](formData);
            $('#NFConfigDialog').append(snap);

            $("#exportConfigDialog").hide().fadeIn().draggable({
                handle: "header"
            }).position({
                my: "center",
                at: "center",
                of: "#NFConfigDialog"
            });
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#exportConfigDialog'));
            $("#exportConfigDialog").css({'left': '28vw' , 'top' : '70px'})
            if($(window).width() < 1100)
                $("#exportConfigDialog").css({'left': '0px'});
            $('#exportConfigSetButton').off().on('click', function(){
                exportConfigSet(formData.name);
            });
        }else{
            MSG$.showErrorMsg({status: "Alert", content: "Cannot export more than one configuration set. Please choose a single configuration set and retry"});
        }
        }
    }

    function dataBindForm(data) {
        var vueConfig = {
            el: '#nfConfigPane',
            data: data,
            methods: [
                {
                    name: 'displayConfigTooltip',
                    method: function (e) {
                        e.stopPropagation();
                        $('[id^=configSetTooltip]').hide();
                        var id=$(e.target).closest('[id^="row"]').attr('id').split('-')[1];
                        $('#configSetTooltip-'+id).fadeIn().position({
                            my: "left top",
                            at: "right top",
                            of: $(e.target),
                            collision: "flipfit"
                        })
                    }
                },
                {
                    name: 'hideConfigTooltip',
                    method: function (e) {
                        var id=$(e.target).closest('[id^="row"]').attr('id').split('-')[1];
                        $('#configSetTooltip-'+id).hide();
                    }
                }
            ],
            watchers: [{
                key: "$data",
                handler: function () {
                    getAllSelectedItems(VUE$.getDataFromApp(vueInstance))
                }
            }]
        }

         // Add Handlebars helpers as vue methods
         _.forEach(Handlebars.helpers, function (fn, name) {
            vueConfig.methods.push({
                name: name,
                method: fn
            });
        });

        // Add components support for form template.
        addComponentsToVue(vueConfig);

        vueInstance = VUE$.createInstance(vueConfig);
    }

    function addComponentsToVue(config){
        // Vue Components HTML
        var tooltipBubble = Handlebars.templates["cloudMap_tooltipBubble"]({});
        Vue.component("tooltipbubbletemplate", {
            template: tooltipBubble,
            props: ["tooltip", "val" , "idx"],
            methods: VUE$.formatMethods(config)
        });
    }

    function toggleConfigSelections(bool) {
        var enableButton = ['cloneIcon','instantiateIcon', 'exportIcon'];
        _.forEach(enableButton, function (btnId) {
            $('#'+btnId).prop('disabled', bool)
        })
    }

    function getAllSelectedItems(data){
        var selectedList = {
            clusterSelectedArr : []
        }
        var that = this
        _.forEach(data.NFConfigSets, function(cluster,i){
            if(cluster.selected) {
                selectedList.clusterSelectedArr.push(cluster);
            }
        })
        if(selectedList.clusterSelectedArr.length === 0 ){
            toggleConfigSelections(true)
        }
        else{
            toggleConfigSelections(false)
        }
        selectedGroup = selectedList.clusterSelectedArr[0];
    }

    function deleteConfig(index,name) {
        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to delete the configuration sets?',
            yes: function () {
                OPM$.NFConfig.NFConfigService.deleteConfigSets(name,false).done(function () {
                    addNfConfigTableData();
                    GCM$.accessibility.accessibilityCommon.setFocus($('#nfConfigPane'));
                }).fail(function (error) {
                    if(error.responseJSON.result === "confirm"){
                        MSG$.confirm({
                            statement: error.responseJSON.errorCode,
                            question: error.responseJSON.errorMessage,
                            yes: function() {
                                OPM$.NFConfig.NFConfigService.deleteConfigSets(name,true).done(function () {
                                    addNfConfigTableData();
                                    GCM$.accessibility.accessibilityCommon.setFocus($('#nfConfigPane'));
                                })
                            },
                            close: function() {
                                GCM$.accessibility.accessibilityCommon.setFocus($('#nfConfigPane'));
                            }
                        });
                    }})
            },
            close: function() {
                GCM$.accessibility.accessibilityCommon.setFocus($('#nfConfigPane'));
            }
        });

    }

    function onToggleCnf(e, index){
        if(vueInstance.$data.NFConfigSets[index].cnfs !== 'undefined'){
            if(vueInstance.$data.NFConfigSets[index].selected) {
                _.forEach(vueInstance.$data.NFConfigSets[index].cnfs, function (cnf) {
                    vueInstance.$set(cnf, 'selected', true)
                })
            }
            else{
                _.forEach(vueInstance.$data.NFConfigSets[index].cnfs, function (cnf) {
                    vueInstance.$set(cnf, 'selected', false)
                })
            }
        }
        if(vueInstance.$data.NFConfigSets[index].paasComponents !== 'undefined') {
            if (vueInstance.$data.NFConfigSets[index].selected) {
                _.forEach(vueInstance.$data.NFConfigSets[index].paasComponents, function (paas) {
                    vueInstance.$set(paas, 'selected', true)
                })
            } else {
                _.forEach(vueInstance.$data.NFConfigSets[index].paasComponents, function (paas) {
                    vueInstance.$set(paas, 'selected', false)
                })
            }
        }
    }

    function onToggleNfAndPaas(e, index){
             setTimeout(function(){
                $('#subRow-'+index).css('display', 'table-row');
            },1)
    }

    function getSelectedGroup() {
        return selectedGroup;
    }

    function setSelectedGroup(groupData) {
        selectedGroup.name = groupData.nfConfigSetName;
        _.assign(selectedGroup, groupData);
    }

    function exportConfigSet(name){
        var fileName = $("#exportConfigFileName").val();
        //Replacing $.filedownload plugin with the below block in order to support custom header 'authorization' for JWT
        var xhr = new XMLHttpRequest();
        xhr.open("GET", '/opm/nfconfig/exportNetworkFunctionsConfig/'+name + '?filename='+fileName+'.zip', true);
        xhr.responseType = "arraybuffer";
        xhr.setRequestHeader("Content-type","application/zip");
        xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
        xhr.setRequestHeader('authorization', 'Bearer '+Cookies.get('authorization'));
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var file = new Blob([xhr.response], {type: "octet/stream"});

                //Download the file by attaching it to a anchor tag and triggering click()
                $("a#exportConfigFileLink").attr({
                            "href": URL.createObjectURL(file),
                            "download": fileName+'.zip'
                }).get(0).click();
                GCM$.common_functions.closeDialog('exportConfigDialog');
                MSG$.showInfoMsg({status: 'Success', content: 'Configuration Sets exported successfully'});
            }
            else if(xhr.readyState == 4 && xhr.status != 200){
                MSG$.showErrorMsg({status: 'Error', content: xhr.response})
            }
        }
        xhr.send();
    }

    function importConfigSet(fileData, type) {
        $('#importConfigDialog').activity();
        $.ajax({
            url: '/opm/nfconfig/importNetworkFunctionsConfig?override=false&type='+type,
            data: fileData,
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data) {
                $('#importConfigDialog').activity(false);
                MSG$.showInfoMsg({status: 'Success', content: 'Configuration Sets imported successfully'});
                GCM$.common_functions.closeDialog('importConfigDialog');
                addNfConfigTableData()
            },
            error: function (res) {
                if(res.responseJSON.result === "confirm"){
                    MSG$.confirm({
                        statement: res.responseJSON.errorCode,
                        question: res.responseJSON.errorMessage,
                        yes: function () {
                            $.ajax({
                                url: '/opm/nfconfig/importNetworkFunctionsConfig?override=true&type='+type,
                                data: fileData,
                                cache: false,
                                contentType: false,
                                processData: false,
                                type: 'POST',
                                success: function (data) {
                                    $('#importConfigDialog').activity(false);
                                    MSG$.showInfoMsg({status: 'Success', content: 'Configuration Sets imported successfully'});
                                    GCM$.common_functions.closeDialog('importConfigDialog');
                                    addNfConfigTableData()
                                },
                                error: function (res) {
                                    MSG$.showErrorMsg({status: 'Error', content: res.responseJSON.errorMessage});
                                    $('#importConfigDialog').activity(false);
                                }
                            });
                        },
                        no: function() {
                            $('#importConfigDialog').activity(false);
                        }
                    });
                }
                else {
                    MSG$.showErrorMsg({status: 'Error', content: res.responseJSON.errorMessage});
                    $('#importConfigDialog').activity(false);
                }
            }
        });
    }

    function toggleExportButton(){
        if($("#exportConfigFileName").val().length > 0){
            $("#exportConfigSetButton").prop("disabled", false)
        }else {
            $("#exportConfigSetButton").prop("disabled", true)
        }
    }

    function toggleCloneButton(){
        if($("#cloneConfigFileName").val().length > 0){
            $("#cloneConfigSetButton").prop("disabled", false)
        }else {
            $("#cloneConfigSetButton").prop("disabled", true)
        }
    }

    function launchCloneDialog(){
        if ($('#cloneConfigDialog').length < 1){
        var data = VUE$.getDataFromApp(vueInstance)
        var selectedList = [], selectedListId= [];
        _.forEach(data.NFConfigSets, function(cluster,i){
            if(cluster.selected) {
                selectedList.push(cluster);
                selectedListId.push(i)
            }
        });
        if(selectedList.length === 1) {
            var cluster = selectedList[0];
            var clusterId = selectedListId[0];
            var formData = {
                name : cluster.name
            }
            var snap = Handlebars.templates['NFConfig_cloneDialog']();
            $('#NFConfigDialog').append(snap);

            $("#cloneConfigDialog").hide().fadeIn().draggable({
                handle: "header"
            }).position({
                my: "center",
                at: "center",
                of: "body"
            });
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#cloneConfigDialog'));
            $("#cloneConfigDialog").css({'left': '20vw' , 'top' : '70px'})
            if($(window).width() < 1100)
                $("#cloneConfigDialog").css({'left': '0px'});
            $("#cloneConfigSetButton").prop("disabled", true)
            $('#cloneConfigSetButton').off().on('click', function(){
                var vueData = VUE$.getDataFromApp(vueInstance);
                var selectedCluster = vueData.NFConfigSets[clusterId];
                var newCloneName = $("#cloneConfigFileName").val();
                var skipFedListPaas = _.filter(selectedCluster.paasComponents, function(paas){
                    if(!paas.selected)
                        return paas
                }).map(function(paas){return paas.id})
    
                var skipFedListCnf = _.filter(selectedCluster.cnfs, function(cnf){
                    if(!cnf.selected)
                        return cnf
                }).map(function(cnf){return cnf.id})
                var skipFedList = skipFedListCnf.concat(skipFedListPaas);
                OPM$.NFConfig.NFConfigService.cloneConfigSet(formData.name, newCloneName, false, skipFedList).done(function () {
                    addNfConfigTableData();
                    GCM$.common_functions.closeDialog('cloneConfigDialog');
                    MSG$.showInfoMsg({status: 'Success', content: 'Configuration Set cloned successfully'});
                }).fail(function (error) {
                    if (error.responseJSON.result === "confirm") {
                        MSG$.confirm({
                            statement: error.responseJSON.errorCode,
                            question: error.responseJSON.errorMessage,
                            yes: function () {
                                OPM$.NFConfig.NFConfigService.cloneConfigSet(formData.name, newCloneName, true, skipFedList).done(function () {
                                    addNfConfigTableData();
                                    GCM$.common_functions.closeDialog('cloneConfigDialog');
                                    MSG$.showInfoMsg({
                                        status: 'Success',
                                        content: 'Configuration Set cloned successfully'
                                    });
                                })
                            }
                        });
                    }
                });
            });
        }else{
            MSG$.showErrorMsg({status: "Alert", content: "Cannot clone more than one configuration set. Please choose a single configuration set and retry"});
        }
        }
    }



    return {
        launchNFConfigDialog: launchNFConfigDialog,
        addNfConfigTableData: addNfConfigTableData,
        launchSnapshotDialog: launchSnapshotDialog,
        launchImportConfigDialog: launchImportConfigDialog,
        toggleRowContents: toggleRowContents,
        launchExportDialog: launchExportDialog,
        deleteConfig: deleteConfig,
        onToggleCnf: onToggleCnf,
        getSelectedGroup: getSelectedGroup,
        setSelectedGroup: setSelectedGroup,
        exportConfigSet: exportConfigSet,
        toggleExportButton: toggleExportButton,
        launchCloneDialog: launchCloneDialog,
        toggleCloneButton: toggleCloneButton,
        onToggleNfAndPaas: onToggleNfAndPaas
    };
})();