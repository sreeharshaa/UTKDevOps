OPM$.NFConfig = OPM$.NFConfig || {};

OPM$.NFConfig.NFConfigService = (function() {

    function getConfigSets(type) {
        return GET_JSON$('/opm/nfconfig/getNfConfigSets?type='+type);
    }

    function getNFConfigSet(groupName) {
        return GET_JSON$('/opm/nfconfig/getNfConfigSet/'+groupName);
    }

    function getSnapshotConfigs(selectedCluster){
        return GET_JSON$('/opm/snapshot/discoverCluster/'+selectedCluster.dzId+'/'+selectedCluster.id);
    }
    function snapshotCnfPaasInstances(selectedCluster, jsonData, bool) {
        return POST_JSON$({
            url: '/opm/snapshot/snapshotNfPaasInstances/'+selectedCluster.dzId+'/'+selectedCluster.id+'?override='+bool,
            data:  JSON.stringify(jsonData)
        });
    }

    function deleteConfigSets(name, bool) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/nfconfig/deleteNfConfigSet/'+name+'?override='+bool});
    }

    function cloneConfigSet(groupName , newGroupName , bool, jsonData){
        return POST_JSON$({
            url: '/opm/nfconfig/cloneNfConfigSet/'+groupName+'/'+newGroupName+'?override='+bool,
            data:  JSON.stringify(jsonData)
        });
    }

    return {
        getConfigSets: getConfigSets,
        getNFConfigSet: getNFConfigSet,
        getSnapshotConfigs: getSnapshotConfigs,
        snapshotCnfPaasInstances: snapshotCnfPaasInstances,
        deleteConfigSets: deleteConfigSets,
        cloneConfigSet: cloneConfigSet
    };
})();