OPM$.NFConfig = OPM$.NFConfig || {};

OPM$.NFConfig.snapshotController = (function(){
    var vueNewInstance;
    var selectedCluster = {
        dzId: '',
        id: '',
        type: ''
    }

    function discoverConfig(e) {
        e.preventDefault();
        $("#snapshotPane").activity();
        OPM$.NFConfig.NFConfigService.getSnapshotConfigs(selectedCluster).done(function (formData) {
            var html = Handlebars.templates['NFConfig_snapshotPane'](formData);
            $('#snapshotPane').empty().append(html);
            dataBindForm(formData);
            $("#clusterNameLabel").css({'opacity': '1', 'pointer-events': 'unset'});
            $("#clusterNameLabel input").removeAttr('disabled');
            $("#clusterDescLabel").css({'opacity': '1', 'pointer-events': 'unset'});
            $("#clusterDescLabel textarea").removeAttr('disabled');
            $('#clusterNameLabel').focus();
            $('#snapshotPane').on('keydown', function(e){
                //Prevent space key press from scrolling
                if(e.keyCode === GCM_KEY$.SPACE){
                    e.preventDefault();
                }
            })
            VALIDATION$.validateOnInputChange($("#snapshotForm"), $("#snapshotBtn"), undefined , undefined, undefined, undefined, true);
        }).always(function (){
            $("#snapshotPane").activity(false);
        });

    }

    function dataBindForm(data) {
        var vueNewConfig = {
            el: '#snapshotDialog',
            data: data,
            methods: [],
            watchers: [{
                key: "$data",
                handler: function () {
                    var res = getAllSelectedNF(VUE$.getDataFromApp(vueNewInstance))
                }
            }]
        }

        vueNewInstance = VUE$.createInstance(vueNewConfig);
    }
    function clusterSelected(data) {
        selectedCluster = data;
        $("#discoverBtn").prop('disabled', false);
    }

    function getAllSelectedNF(data) {
        var res = {
            cnfSelectedArr : [],
            paasSelectedArr : []
        }
        res.cnfSelectedArr = _.filter(data.cluster.cnfs, 'selected');
        res.paasSelectedArr = _.filter(data.cluster.paasComponents, 'selected');
        return res
    }

    function saveSnapshot(){
        var data = VUE$.getDataFromApp(vueNewInstance)
        var res = getAllSelectedNF(data);
        data.cluster.cnfs = res.cnfSelectedArr;
        data.cluster.paasComponents = res.paasSelectedArr;
        data.groupName = $("#clusterNameLabel input").val();
        data.description = $("#clusterDescLabel textarea").val();
        $("#snapshotBtn").activity()
        OPM$.NFConfig.NFConfigService.snapshotCnfPaasInstances(selectedCluster,data,false).done(function (formData) {
           GCM$.common_functions.closeDialog('snapshotDialog');
           GCM$.accessibility.accessibilityCommon.setFocus($('#snapshotIcon'));
           MSG$.showInfoMsg({status: 'Success', content: 'Snapshot saved successfully'});
           OPM$.NFConfig.NFConfigController.addNfConfigTableData();
       }).fail(function (error) {
            if(error.responseJSON.result === "confirm"){
                MSG$.confirm({
                    statement: error.responseJSON.errorCode,
                    question: error.responseJSON.errorMessage,
                    yes: function () {
                        $("#snapshotBtn").activity()
                        OPM$.NFConfig.NFConfigService.snapshotCnfPaasInstances(selectedCluster,data,true).done(function (formData) {
                            GCM$.common_functions.closeDialog('snapshotDialog');
                            MSG$.showInfoMsg({status: 'Success', content: 'Snapshot saved successfully'});
                            OPM$.NFConfig.NFConfigController.addNfConfigTableData();
                        }).always(function () {
                            $("#snapshotBtn").activity(false)
                        })
                    }});
            }
        }).always(function () {
            $("#snapshotBtn").activity(false)
        })
    }

    function toggleChkbxOnKn(type, index){
        var div = $('#snap-'+type+'-chkbox-'+index).siblings('div.an-toggle')[0];
        if($('#snap-'+type+'-chkbox-'+index).prop('checked')) {
            $(div).attr('aria-checked' ,'true');
        }
        else{
            $(div).attr('aria-checked' ,'false');
        }
    }

    return {
        clusterSelected: clusterSelected,
        discoverConfig: discoverConfig,
        saveSnapshot: saveSnapshot,
        toggleChkbxOnKn: toggleChkbxOnKn
    }
})();