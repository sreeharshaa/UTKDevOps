OPM$.cloudMap = OPM$.cloudMap || {};

OPM$.cloudMap.cloudMapService = (function() {
    'use strict';

    function getCloudMap(json) {
        return POST_JSON$({
            url: '/opm/cloudmap/getCloudMap',
            data: JSON.stringify(json)
        });
    }

    function renderDzLocations() {
        //return GET_JSON$('../json/getDzLocations.json');
        return GET_JSON$('/opm/cloudmap/getAllDeploymentZonesAndLocations');
    }

    function deleteCNF(dzId, clusterId, chartName, releaseName) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/cnf/deleteCnf/'+dzId+'/'+clusterId+'/'+releaseName+'/'+chartName});
    }

    function addDzLocation(json) {
        return POST_JSON$({
            url: '/opm/location/createLocation',
            data: JSON.stringify(json)
        });
    }
    
    function updateDzLocations(json) {
        return PUT_JSON$({
            url: '/opm/location/saveLocations',
            data: JSON.stringify(json)
        });
    }

    function deleteDzLocation(name) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/location/deleteLocation/'+name});
    }

    function getDeployedValues(dzId, clusterId, namespace, releaseName) {
        return GET_JSON$('/opm/cnf/getDeployedValues/'+dzId+'/'+clusterId+'/'+releaseName+'/'+namespace+'?retrieveAllValues=true&format=yaml');
    }

    function getClusterStatus(dzId, clusterId) {
        return GET_JSON$('/opm/cluster/getClusterOsNodesK8NodesStatus/'+dzId+'/'+clusterId);
    }

    function deleteAllCnf(dzId, clusterId, repoName, skipRookCephDeletion) {
        return POST_JSON$({
            url: '/opm/cnf/deleteAllCnf/' + dzId + '/' + clusterId + '/' + repoName + '?skipRookCephDeletion=' + skipRookCephDeletion
        });
    }

    function saveUserPreferences(json) {
        return POST_JSON$({
            url: '/opm/userPreferences/',
            data: JSON.stringify(json)
        });
    }

    function getUserPreferences() {
        return GET_JSON$('/opm/userPreferences/' + Cookies.get("username"));
    }

    return {
        getCloudMap: getCloudMap,
        renderDzLocations: renderDzLocations,
        deleteCNF: deleteCNF,
        addDzLocation: addDzLocation,
        deleteDzLocation: deleteDzLocation,
        updateDzLocations: updateDzLocations,
        getDeployedValues: getDeployedValues,
        getClusterStatus: getClusterStatus,
        deleteAllCnf: deleteAllCnf,
        getUserPreferences: getUserPreferences,
        saveUserPreferences: saveUserPreferences
    };

})();