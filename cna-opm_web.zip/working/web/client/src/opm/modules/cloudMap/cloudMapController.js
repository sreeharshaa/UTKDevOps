OPM$.cloudMap = OPM$.cloudMap || {};

OPM$.cloudMap.cloudMapController = (function () {

    var cloudMapData = {}, doPoll, clusterVueInstance = {},
        categorized = false,
        panZoomMap, interval, startTime, locationsData = [], locations_reset = [], allDzsList = [],
        customClusterFormVueInstance = {}, customClusterTableVueInstance = {},
        svg, projection;   
    
    function renderCloudMap(json) {
        OPM$.cloudMap.cloudMapService.getCloudMap(json)
            .done(function (data) {
                data.dzSet = json;
                // Adding 'showCertWarning' flag to show warning message at the top of cluster view, if any of the clusters has 'certExpiryNotif: true'
                // Below code block assumes that there will always be only one dz for a cluster view while parsing for 'certExpiryNotif: true'
                data.deploymentZones[0].showCertWarning = false; 
                _.forEach(data.deploymentZones[0].clusters, function (cluster) {
                    if(cluster.certExpiryNotif)
                       if(!data.deploymentZones[0].showCertWarning){   
                           data.deploymentZones[0].showCertWarning = true;
                        }
                });
                cloudMapData = data;
                if($("#cloudMapView").is(":visible")) {
                    // Updating Vue data as cluster view is visible and already binded with Vue. No need to re-render cluster view.
                    clusterVueInstance.$data.deploymentZones = [];
                    _.forEach(data.deploymentZones, function (dz) {
                        clusterVueInstance.$data.deploymentZones.push(dz);
                    })
                } else {
                    renderClusterView(data);
                }
        });
    }

    function renderClusterView(data) {
        var html = Handlebars.templates['cloudMap_cloudMap'](data);
        $("#logoContainer, #mapContainer").hide();
        $("#cloudMapView").empty().append(html).show();
        GCM$.accessibility.accessibilityCommon.setFocus($("#cloudMapView"));
        GCM$.common_functions.enableFieldHoverTips(undefined, "h1");
        dataBind(data);

        clusterViewKeyNav();

        if(typeof data.deploymentZones === "undefined"){
            OPM$.cloudMap.cloudMapController.displayMap();
        }

        if(Cookies.get('an-togglePaaS-cookie') === "true") {
            $(".cn-paas-container").hide();
        }
    }

    function dataBind(data) {
        // Two-way data binding
        var vueConfig = {
            el: "#cloudMapView",
            data: data,
            methods: [
                {
                    name: 'togglePaas',
                    method: function () {
                    if((Cookies.get('an-togglePaaS-cookie') === "false")
                        || (typeof Cookies.get('an-togglePaaS-cookie') === "undefined")) {
                        Cookies.set('an-togglePaaS-cookie', "true");
                        $(".cn-paas-container").hide();
                    } else {
                        Cookies.set('an-togglePaaS-cookie', "false");
                        $(".cn-paas-container").show();
                    }
                    $("#clusterViewMenuIcon").focus();
                }
            },
                {
                name: 'refreshClusterView',
                method: function (forceRefresh) {
                    var $container = $(".an-cluster-container"),
                        json = JSON.parse(($container).attr('data-set'));
                        json.forceRefresh = forceRefresh;

                    renderCloudMap(json);
                }
            },
                {
                    name: 'toggleAllClusters',
                    method: function () {
                    if($(".an-cluster-container").hasClass('an-collapsed')){
                        $(".an-cluster-container").removeClass('an-collapsed').addClass('an-expanded');
                        _.forEach($(".an-cluster"), function (cluster) {
                            $(cluster).removeClass('an-collapsed').addClass('an-expanded');
                            $(cluster).find('button.cn-cluster-toggle-state').removeClass('an-icon-scroll_triangle_right_dark').addClass('an-icon-scroll_triangle_down_dark');
                            Cookies.set($(cluster).attr('id') ,'expanded');
                        })
                    } else {
                        $(".an-cluster-container").removeClass('an-expanded').addClass('an-collapsed');
                        _.forEach($(".an-cluster"), function (cluster) {
                            $(cluster).removeClass('an-expanded').addClass('an-collapsed');
                            $(cluster).find('button.cn-cluster-toggle-state').removeClass('an-icon-scroll_triangle_down_dark').addClass('an-icon-scroll_triangle_right_dark');
                            Cookies.set($(cluster).attr('id') ,'collapsed');
                        })
                    }
                }
            },
                {
                    name: 'toggleCNFMenu',
                    method: function (event) {
                        event.stopPropagation();
                        GCM$.common_functions.slideUpAllMenus();
                        var menuIcon$ = $(event.target),
                            el$ = $(menuIcon$).closest('.an-cnf').length > 0 ? $(event.target).closest('.an-cnf') :  $(event.target).closest('.an-paas-component'),
                            observability = JSON.parse($(el$).attr('data-observability'));

                        if ($(el$).find('#cnClusterMenu').length > 0 && $(el$).find('#cnClusterMenu').css('display') === "block") {
                            $(menuIcon$).parent().find("#cnClusterMenu").slideUp("normal", function () {
                                $("#cnClusterMenu").detach();
                            });
                            $(menuIcon$).attr('aria-expanded', 'false');
                        } else {
                            $("#cnClusterMenu").detach();
                            var state =$(el$).closest('.an-cluster').attr('data-state');
                            var html = Handlebars.templates['cloudMap_cnClusterMenu']({observability: observability.observability, state: state});
                            $(html).appendTo($(menuIcon$).parent()).slideDown().position({
                                my: "right top",
                                at: "right bottom",
                                of: menuIcon$,
                                collision: "flipfit"
                            });
                            $(menuIcon$).attr('aria-expanded', 'true');
                            GCM$.common_functions.initialize();
                            GCM$.accessibility.menuAccessibility.makeMenuKeyNav($('#cnClusterMenu'), $(el$).find('i.an-menu-icon'));
                        }
                    }
                },
                {
                    name: 'toggleClusterMenu',
                    method: function (e) {
                        var el$ = $(e.target);
                        e.stopPropagation();
                        GCM$.common_functions.slideUpAllMenus();
                        $('#clusterTooltip').hide();
                        if(el$.closest('.an-cluster').find('.cluster-menu').css('display') === "none") {
                            el$.attr('aria-expanded', 'true');
                            el$.closest('.an-cluster').find('.cluster-menu').show().slideDown().position({
                                my: "right top",
                                at: "right bottom",
                                of: el$,
                                collision: "flipfit"
                            });
                        } else {
                            el$.attr('aria-expanded', 'false');
                            el$.closest('.an-cluster').find('.cluster-menu').slideUp("normal", function () {
                                el$.closest('.an-cluster').find('.cluster-menu').hide();
                            });
                        }

                    }
                },
                {
                    name: 'displayClusterTooltip',
                    method: function (e) {
                        e.stopPropagation();
                        $('.cnfTooltip').hide();
                        $(e.target).closest('.an-cluster').find('#clusterTooltip').fadeIn().position({
                            my: "left top",
                            at: "right top",
                            of: $(e.target),
                            collision: "flipfit"
                        })
                    }
                },
                {
                    name: 'hideClusterTooltip',
                    method: function (e) {
                        $(e.target).closest('.an-cluster').find('#clusterTooltip').hide();
                    }
                },
                {
                    name: 'displayCnfTooltip',
                    method: function (e) {
                        e.stopPropagation();
                        $('.cnfTooltip').hide();
                        var cnfOrPaas = $('.an-cnf, .an-paas-component');
                        $(e.target).closest(cnfOrPaas).find('.cnfTooltip').fadeIn().position({
                            my: "left top",
                            at: "right top",
                            of: $(e.target),
                            collision: "flipfit"
                        });
                    }
                },
                {
                    name: 'hideCnfTooltip',
                    method: function (e) {
                        var cnfOrPaas = $('.an-cnf, .an-paas-component');
                        $(e.target).closest(cnfOrPaas).find('.cnfTooltip').hide();
                    }
                }]
        }

        // Add Handlebars helpers as vue methods
        _.forEach(Handlebars.helpers, function (fn, name) {
            vueConfig.methods.push({
                name: name,
                method: fn
            });
        });

        // Add components support for form template.
        addComponentsToVue(vueConfig);

        clusterVueInstance = VUE$.createInstance(vueConfig);
    }

    function addComponentsToVue(config) {
        // Vue Components HTML
        var federation = Handlebars.templates["cloudMap_federation"]({}),
            clusterViewMenu = Handlebars.templates["cloudMap_clusterViewMenu"]({}),
            clusterLevelMenu = Handlebars.templates["cloudMap_clusterLevelMenu"]({}),
            tooltipBubble = Handlebars.templates["cloudMap_tooltipBubble"]({});
        // Register Components to Vue globally
        Vue.component("federationtemplate", {
            template: federation,
            props: ["clusterid", "cnf"],
            methods: VUE$.formatMethods(config)
        });
        Vue.component("tooltipbubbletemplate", {
            template: tooltipBubble,
            props: ["tooltip", "val"],
            methods: VUE$.formatMethods(config)
        });
        Vue.component("clusterviewmenutemplate", {
            template: clusterViewMenu,
            props: [],
            methods: VUE$.formatMethods(config)
        });
        Vue.component("clusterlevelmenutemplate", {
            template: clusterLevelMenu,
            props: ["cluster", "dzname"],
            methods: VUE$.formatMethods(config)
        });
    }

    function deleteCNF(e) {
        doPoll = true;
        var el$ = $(e.target).closest('.an-cnf').length > 0 ? $(e.target).closest('.an-cnf') : $(e.target).closest('.an-paas-component'),
            chartName = el$.attr('data-namespace'),
            releaseName = el$.attr('data-releaseName'),
            clusterId = el$.closest('.an-cluster').attr('id'),
            dzId = el$.closest('.an-cluster').attr('data-dzId'),
            type = el$.closest('.an-cluster').attr('data-dzType');

        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to delete the Federation?',
            yes: function () {
                el$.activity();

                OPM$.cloudMap.cloudMapService.deleteCNF(dzId, clusterId, chartName,  releaseName)
                    .done(function (data) {
                        MSG$.showInfoMsg({status: 'Success', content: 'Federation deleted successfully'});
                        //OPM$.cloudMap.cloudMapController.renderCloudMap(false, dzId, type);
                    }).always(function () {
                        el$.activity(false);
                }).fail(function (data) {
                    doPoll = false;
                });

               /* setTimeout(function () {
                    launchHelmStatusAfterDelete(dzId, clusterId, chartName, releaseName, type);
                }, 10000);*/
            },
            close: function () {
                $(el$).find(".an-focusable").first().focus();
            }
        });
    }

    function showStatus(e) {
        var el$ = $(e.target).closest('.an-cnf').length > 0 ? $(e.target).closest('.an-cnf') : $(e.target).closest('.an-paas-component'),
            chartName = el$.attr('data-namespace'),
            releaseName = el$.attr('data-releaseName'),
            clusterId = el$.closest('.an-cluster').attr('id'),
            dzAndclusterNameStr = el$.closest('.an-cluster').find('span.cn-cluster-title-text').text(),
            dzName = dzAndclusterNameStr.split(' - ')[0].trim(),
            clusterName = dzAndclusterNameStr.split(' - ')[1].trim(),
            dzId = el$.closest('.an-cluster').attr('data-dzId');

        if(typeof clusterName === "undefined"){
            clusterName = $('#selectClusterBtn span').text();
        }

        OPM$.lcm.federations.federationsService.getHelmStatus(dzId, clusterId, chartName, releaseName, "showStatus")
            .done(function (data) {
                var config = {
                    clusterName: clusterName,
                    dzName: dzName,
                    releaseName: typeof releaseName !== "undefined" ? releaseName : undefined,
                    fedDeploymentStatus: data.data.fedDeploymentStatus,
                    task: "show status",
                    data: data.successMessage,
                    consoleTables: data.data
                };
                var userSelected = true;
                OPM$.lcm.consoleTabs.tabsController.openConsoleTab(config, userSelected);

            });
    }

    function showClusterStatus(e, depZoneId, clusId, dzName, clusName) {
        var el$, dzId, clusterId, clusterName;
        if(typeof e !== "undefined") {
            el$ = $(e.target),
            dzId = $(el$).closest('.an-cluster').attr('data-dzId'),
            clusterId = $(el$).closest('.an-cluster').attr('id'),
            dzAndclusterNameStr = el$.closest('.an-cluster').find('span.cn-cluster-title-text').text(),
            dzName = dzAndclusterNameStr.split(' - ')[0].trim(),
            clusterName = dzAndclusterNameStr.split(' - ')[1].trim();
        } else {
            //This is when the "show status" is invoked from cluster management dialog
            dzId = depZoneId;
            clusterId = clusId;
            dzName = dzName;
            clusterName = clusName;
        }

        OPM$.cloudMap.cloudMapService.getClusterStatus(dzId, clusterId)
            .done(function (data) {
                var config = {
                    dzName: dzName,
                    clusterName: clusterName,
                    task: "show status",
                    data: data.successMessage,
                    consoleTables: data.data
                };
                var userSelected = true;
                OPM$.lcm.consoleTabs.tabsController.openConsoleTab(config, userSelected);

            });

    }

    function getOffset(el) {
        var _x = 0,
            _y = 0;
        while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
            _x += el.offsetLeft - el.scrollLeft;
            _y += el.offsetTop - el.scrollTop;
            el = el.offsetParent;
        }
        return { top: _y, left: _x };
    }

    function renderAssociations() {

        if(cloudMapData.deploymentZones[0] !== null && typeof cloudMapData.deploymentZones[0].paasAssociations !== "undefined") {
            var points = cloudMapData.deploymentZones[0].paasAssociations;

            _.forEach(points, function (value, key) {
                var adj_x = -62,
                    adj_y = 40;

                $('[id="' + value[0] + '_' + value[1] + '"]')
                    .attr("x1", getOffset(document.getElementById(value[0])).left - adj_x)
                    .attr("y1", getOffset(document.getElementById(value[0])).top - adj_y)
                    .attr("x2", getOffset(document.getElementById(value[1])).left - adj_x)
                    .attr("y2", getOffset(document.getElementById(value[1])).top - adj_y);
            });
        }

    }

    function highlightAssociations(id) {
        var assoc = cloudMapData.deploymentZones[0].paasAssociations;

        renderAssociations();

        _.forEach(assoc, function(value, key) {
            if(($('[id="'+value[0]+'"]').length > 0) && ($('[id="'+value[1]+'"]').length > 0)) {

                if (value[0] === id || value[1] === id) {
                    $('[id="'+value[0] + '_' + value[1]+'"]').attr("class", "an-cn-highlight-assoc");
                    $('[id="'+value[0]+'"]').addClass("an-cn-highlight");
                    $('[id="'+value[1]+'"]').addClass("an-cn-highlight");
                    $("#cloudMapView").addClass("cn-dim-feds");
                }
            }
        });
    }

    function associationVisibility() {
        $('#cloudMapView').toggleClass("cn-dim-associations");
        renderAssociations();
    }

    function cloudMapViewMenu() {
        $("#cnCloudMapViewMenu").slideToggle().position({
            my: "right top",
            at: "right bottom",
            of: "#cnCloudMapViewIcon",
            collision: "flipfit"
        });
    }

    function showFilterDialog() {
        //var el = e.target;

        // if($(el).hasClass("an-filter-in-place") || $(el).closest("button").hasClass("an-filter-in-place")) {
        //     filterByTag();
        // } else {
        if (document.getElementById('filterCloudMapDialog') === null) {

            var dialog = document.querySelector('dialog');
            dialogPolyfill.registerDialog(dialog);

            document.getElementById('filterCloudMapDialog').show();
            $("#selectHelmChart").blur();

        } else if (!document.getElementById('filterCloudMapDialog').open) {
            var dialog = document.querySelector('dialog');
            dialogPolyfill.registerDialog(dialog);

            document.getElementById('filterCloudMapDialog').show();
        }
        //}
    }

    function filterByTag(tag) {

        if (tag === "" || tag == null) {
            $(".an-cluster").show();
            $("#filterByTagIcon").removeClass("an-filter-in-place");
        } else {
            $(".an-cluster").hide();
            $("." + tag).show();
            $("#filterByTagIcon").addClass("an-filter-in-place");
        }

        document.querySelector('#filterCloudMapDialog').close();
    }

    function displayMap() {
        $('#geoMapItem').activity();
        OPM$.cloudMap.cloudMapService.renderDzLocations()
            .done(function (data) {
                //Putting all DZs together in an array 'allDzsList'
                allDzsList = [];
                _.forEach(data.userDefinedPoints, function(userDefPoint){
                    _.forEach(userDefPoint.deploymentZones, function(dz){
                        allDzsList.push(dz);
                    })
                })

                _.forEach(data.userDefinedPoints, function (location) {
                    if (location.tag === "null" || location.tag === null) {
                        location.tag = "userDefined";
                    }
                });

                locationsData = data.userDefinedPoints;
                locations_reset = _.cloneDeep(data.userDefinedPoints);
                data.tabSelected = Cookies.get("mapView");

                var dz = Handlebars.templates['cloudMap_deploymentZones'](data);

                $("#logoContainer, #cloudMapView").hide();

                renderCustomViewsTable();

                $("#mapContainer").fadeIn("normal", function () {
                    $(".cn-dz-bubble, #addLocationBtn, #editLocationsBtn").detach();
                    renderLocationPoints(data);
                    $("#geographicView").append($(dz));
                    positionDZMarkers();

                    $(".cn-dz-bubble li").on("click", function (e) {
                        e.stopPropagation();
                        $(this).closest('.cn-dz-bubble').activity();
                        var id = $(this).find('input').attr('data-id'),
                            type = $(this).find('input').attr('data-type'),
                            json = {"deploymentZones": [{"id": id, "type": type}], "forceRefresh": false};

                        OPM$.cloudMap.cloudMapController.renderCloudMap(json);
                    });

                    if(Cookies.get("mapView") === "grid"){
                        $("#geographicView").hide();
                        $("#gridView").show();
                    }

                    $('#mapContainer :tabbable')[0].focus();

                    initZoomPanControls();
                    $("#worldMap").attr("tabindex", "-1");
                });

                var area = document.getElementById('matrix-group'),
                    instance = panzoom(area, {
                        autocenter: true,
                        maxZoom: 10,
                        minZoom: 0.9,
                        bounds: true
                    });

                var transform = instance.getTransform();
                //instance.zoomTo(transform.x+500, transform.y+200, 1.3);

                instance.on('transform', function (e) {
                    positionDZMarkers();
                });

                var $tabs = $("#worldMapTabs");
                $tabs.on("click", function (e) {
                    var $selectedTab = $($(e.target).closest('li')),
                        tabName =  $selectedTab.attr("data-name");

                    $tabs.find("li").removeClass("an-selected");
                    $tabs.find("li").attr({"tabindex": -1, "aria-selected": "false"});
                    $selectedTab.addClass("an-selected");
                    $selectedTab.attr({"tabindex": "0", "aria-selected": "true"});

                    if(tabName === 'grid'){
                        $("#geographicView").hide();
                        $("#gridView").show();
                        Cookies.set("mapView", "grid");
                    } else if (tabName === 'geographic') {
                        $("#gridView").hide();
                        $("#geographicView").show();
                        Cookies.set("mapView", "geographic");
                    }
                })

                GCM$.accessibility.tabAccessibility.tabKeyNav($tabs);
                GCM$.accessibility.tableAccessibility.makeTableKeyNav($("#gridView tbody"));
            }).always(function () {
            $('#geoMapItem').activity(false);
        });

    }

    function renderGeoMap() {
        var html = Handlebars.templates['cloudMap_geoMap']();
        $("#mapContainer").empty().append(html);

        var w = 1400, h = 1100;
        svg = d3.select("div#geographicView").append("svg").attr("preserveAspectRatio", "xMinYMin meet")
            .attr("viewBox", "0 0 " + w + " " + h).attr("id", "worldMap")
            .classed("svg-content", true).append("g").attr("id", "matrix-group");

        projection = d3.geoMiller().scale(w / 1.75 / Math.PI)
            .translate([w/2, h/2]);

        var path = d3.geoPath().projection(projection);
        var worldmap = d3.json("../json/worldMapwCountries.geojson");
        Promise.all([worldmap]).then(function (values) {
            // draw map
            svg.selectAll("path")
                .data(values[0].features)
                .enter()
                .append("path")
                .attr("class", "cn-map-path")
                .attr("name", function (d) { return d.properties.name; })
                .attr("d", path);
        });

        if ($("#worldMap").is(":visible")) {
            displayMap();
        }

    }

    function renderLocationPoints(data) {
        $(".cn-location-circle, .labels").detach();

        svg.selectAll("circle")
            .data(data.userDefinedPoints)
            .enter()
            .append("circle")
            .attr("class", "cn-location-circle")
            .attr('name', function (d) { return d.name; })
            .attr("cx", function (d) { return projection([d.longitude, d.latitude])[0]; })
            .attr("cy", function (d) { return projection([d.longitude, d.latitude])[1]; })
            .attr("r", "1px")
            .attr("latitude", function (d) { return d.latitude; })
            .attr("longitude", function (d) { return d.longitude; })

        // add labels
        svg.selectAll(".city-labels")
            .data(data.userDefinedPoints)
            .enter()
            .append("text")
            .text(function (d) {
                return d.name;
            })
            .attr("x", function (d) { return projection([d.longitude, d.latitude])[0] + 5; })
            .attr("y", function (d) { return projection([d.longitude, d.latitude])[1] + 10; })
            .attr("class", "labels");

        $(".cn-location-circle").on('click', renderEditLocationsDlg);
        $(".cn-location-circle").on('keyup', function (e) {
            if (e.keyCode === GCM_KEY$.ENTER)
                renderEditLocationsDlg(e);
        });

    }

    function renderCustomViewsTable() {
        var gridViewJson = JSON.parse(OPM$.app.userPrefs.userPreferences);
        if(typeof gridViewJson === "undefined" || _.isEmpty(gridViewJson)) {
            gridViewJson = {
                clusterViews: []
            }
        }
        var html = Handlebars.templates['cloudMap_gridView'](gridViewJson);
        $('#gridView').empty().append(html);

        var vueConfig = {
            el: "#gridView",
            data: gridViewJson,
            methods: [
                {
                name: 'toggleMenu',
                method: function(e) {
                    var custMenu$ = $(e.target).closest('tr').find(".an-custom-cluster-table-menu");
                    e.stopPropagation();
                    if (custMenu$.css("display") == "none") {
                        $(e.target).attr('aria-expanded', 'true');
                        custMenu$.slideDown().position({
                            my: "right top",
                            at: "right bottom",
                            of: $(e.target),
                            collision: "flipfit"
                        });
                        GCM$.accessibility.menuAccessibility.makeMenuKeyNav(custMenu$, $(e.target));
                    } else {
                        $(e.target).attr('aria-expanded', 'false');
                        custMenu$.slideUp();
                    }
                }
            },
                {
                name: 'editCustomClusterView',
                method: function(clusterView, index) {
                    OPM$.cloudMap.cloudMapController.customClusterView(clusterView, index);
                }
            },
                {
                name: 'launchCustomClusterView',
                method: function(e) {
                    var dzData = JSON.parse($(e.target).attr("data-set")),
                        dzJson = {"deploymentZones": dzData};

                    OPM$.cloudMap.cloudMapController.renderCloudMap(dzJson);
                }
            },
                {
                name: 'deleteCustomClusterView',
                method: function(e, clusterViews, name, index) {
                    e.stopPropagation();
                    MSG$.confirm({
                        statement: 'Delete Confirmation',
                        question: 'Are you sure you want to delete ' + name + '?',
                        yes: function () {
                            clusterViews.splice(index, 1);
                            userPrefJSON = {'userPreferences' : JSON.stringify({'clusterViews':clusterViews})};
                            $("#gridView table").activity();
                            OPM$.cloudMap.cloudMapService.saveUserPreferences(userPrefJSON)
                                .done(function () {
                                    OPM$.app.userPrefs = userPrefJSON;
                                    MSG$.showInfoMsg({status: 'Success', content: name+' deleted successfully!',
                                        close: function () {
                                            $("#gridView tbody tr:first :focusable").first().focus();
                                        }});
                                    $($("#gridView tbody :focusable")[0]).attr('tabindex', "0");
                                }).always(function(){
                                    $("#gridView table").activity(false);
                            })
                        },
                        close: function(){
                            $(e.target).closest('td').find('.an-custom-view-details').focus();
                        }
                    })
                }
            }]
        }

        // Add Handlebars helpers as vue methods
        _.forEach(Handlebars.helpers, function (fn, name) {
            vueConfig.methods.push({
                name: name,
                method: fn
            });
        });

        customClusterTableVueInstance = VUE$.createInstance(vueConfig);
        GCM$.accessibility.tableAccessibility.makeTableKeyNav($("#gridView table"));
    }


    function DZDetailsMenuOpen(dzBubble, dzMenu) {
        dzMenu.slideDown('slow', function () {
            dzMenu.css({display: "table"});
        }).position({
            my: "left top",
            at: "left bottom",
            of: dzBubble
        });
        dzBubble.attr('aria-expanded', 'true');
    }

    function DZDetailsMenuClose(dzBubble, dzMenu) {
        dzMenu.slideUp();
        dzBubble.attr('aria-expanded', 'false');
    }

    function escapeSpclChars( myid ) {
        return "#" + myid.replace( /(:|\.|\[|\]|,|=|@)/g, "\\$1" );
    }

    function positionDZMarkers() {
        _.forEach(locationsData, function (location) {

            var concatLocation = location.name.replaceAll(/\s/g, ""),
                deploymentZone = $(escapeSpclChars("DZ-"+concatLocation)),
                detailsMenu = deploymentZone.find('.cn-dz-details');

            deploymentZone.position({
                my: "center+2.5 bottom+2",
                at: "center center",
                of: $('circle[name="'+location.name+'"]')
            });

            deploymentZone.hover(
                function() { DZDetailsMenuOpen(deploymentZone, detailsMenu); },
                function() { DZDetailsMenuClose(deploymentZone, detailsMenu); }
            );

            // This onmouseout call is causing issues CN-24229
            // detailsMenu.on('mouseout', function() { DZDetailsMenuClose(deploymentZone, detailsMenu); });
            detailsMenu.on('keydown', function(e) {
                if (e.keyCode === GCM_KEY$.TAB) {
                    DZDetailsMenuClose(deploymentZone, detailsMenu);
                }
            });

            GCM$.accessibility.menuAccessibility.makeMenuKeyNav(detailsMenu, deploymentZone,
                function() { DZDetailsMenuOpen(deploymentZone, detailsMenu); },
                function() { DZDetailsMenuClose(deploymentZone, detailsMenu); }
            );
        });
    }

    function changeMapScale(val) {

        var value = Number(val),
            valueAdj;

        switch(value) {
            case 1:
                valueAdj = 0.3;
                break;
            case 2:
                valueAdj = 0.7;
                break;
            case 3:
                valueAdj = 1;
                break;
            case 4:
                valueAdj = 1.5;
                break;
            case 5:
                valueAdj = 2;
                break;
            default:
                valueAdj = 1;
        }

        $('#worldMap').css({'transform': 'scale(' + valueAdj + ')'});
        positionDZMarkers();
    }

    function returnPanZoomMap() {
        return panZoomMap;
    }

    function launchScalingDialog() {
        var jsonData = {};
        $.getJSON('../json/scaling.json', function (data) {
            jsonData = data;
            var html = Handlebars.templates['cloudMap_scaling'](jsonData);
            $('body').append(html).position({
                my: "center",
                at: "center",
                of: "body"
            });

            $("#scalingDlg").draggable({
                handle: "header"
            });
        });
    }

    function updateSliders(e) {
        var $range = $(e.target).parent().find('input[type="range"]'),
            $number = $(e.target).parent().find('input[type="number"]');
        $range.on('change input', function (e) {
            var val = $range.val();
            $number.val(val);
        });
        $number.on('change input', function (e) {
            var val = $number.val();
            $range.val(val);
        });
    }

    function deleteCluster(e) {
        var el$ = $(e.target),
            dzId = $(el$).closest('.an-cluster').attr('data-dzId'),
            clusterId = $(el$).closest('.an-cluster').attr('id'),
            state = $(el$).closest('.an-cluster').attr('data-state');
        if(state !== 'active') {
            MSG$.confirm({
                statement: 'Delete Confirmation',
                question: 'This cluster is in standby mode and only the reference is removed. Do you want to proceed?',
                    position: {my: 'left top', at: 'right bottom', of: 'body'},
                    yes: function () {
                        OPM$.DzAndCluster.K8s.K8sController.onDeleteCluster(el$,dzId, clusterId, $(el$).closest('.an-cluster'));
                    }
                });
            }
            else {
                OPM$.DzAndCluster.K8s.K8sController.onDeleteCluster(el$,dzId, clusterId, $(el$).closest('.an-cluster'));
            }
    }

    function toggleFullScreen(e) {
        var el$ = $(e.target).closest('.cluster-menu').closest('.an-cluster');
        el$.toggleClass('cn-cluster-fullscreen');
        el$.find('i.an-menu-icon').first().focus();
    }

    function renderEditLocationsDlg() {
        var retPt = document.activeElement;
        if($("#editLocationsDlg").length < 1) {
            var html = Handlebars.templates['cloudMap_editLocations'](locationsData);
            $('body').append(html);

            $('#editLocationsDlg').draggable({
                handle: "header"
            }).position({
                my: "center",
                at: "center",
                of: "body"
            });

            var vueConfig = {
                el: "#editLocationsDlg section",
                data: {locations: locationsData},
                methods: [{
                    name: 'cloneRow',
                    method: function (locations) {
                        var newLocation = {
                            name: '',
                            latitude: '',
                            longitude: '',
                            tag: 'userDefined',
                            editable: true,
                            staged: true
                        };
                        locations.push(newLocation);
                        setTimeout(function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                            $("#editLocationsDlg section").scrollTop($("#editLocationsDlg section").height());
                        }, 100);
                        $('#editBtn').prop("disabled", true);
                    }
                }, {
                    name: 'deleteLocation',
                    method: function (e, locations, index) {
                        var locName = locations[index].name;
                        if (locations[index].staged) {
                            locations.splice(index, 1);
                        } else {
                            MSG$.confirm({
                                statement: 'Delete Confirmation',
                                question: 'Are you sure you want to delete location ' + locName + '?',
                                position: {my: 'left top', at: 'right bottom', of: $(e.target)},
                                yes: function () {
                                    $("#editLocationsDlg").activity();
                                    OPM$.cloudMap.cloudMapService.deleteDzLocation(locName)
                                        .done(function () {
                                            MSG$.showInfoMsg({
                                                status: 'success',
                                                content: 'Location deleted successfully'
                                            });
                                            locations.splice(index, 1);
                                            displayMap();
                                        }).always(function () {
                                        $("#editLocationsDlg").activity(false);
                                    }).fail(function (data) {
                                        MSG$.showErrorMsg({status: 'Error', content: data.responseJSON.errorMessage})
                                    });
                                },
                                close: function () {
                                    $("#editLocationsDlg :tabbable")[0].focus();
                                }
                            });
                        }
                    }
                }]
            }
            locationsVueInstance = VUE$.createInstance(vueConfig);

            VALIDATION$.validateOnInputChange($('#editLocationsDlg'), $('#editBtn'), undefined, undefined, undefined, true);
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#editLocationsDlg'));
            GCM$.accessibility.tableAccessibility.makeTableKeyNav($('#editLocationsDlg tbody'));
            $('#editLocationsDlg :tabbable')[0].focus();

            $('#editLocationsDlg').on('dialogClose', function (e) {
                retPt.focus()
                $(".cn-modal-container").detach();
            });
        }
    }

    function onUpdateDzLocations() {
        var jsonData = VUE$.getDataFromApp(locationsVueInstance);

        _.forEach(jsonData.locations, function (location) {
            delete location.posx;
            delete location.posy;
        });

        //Validation for duplicate location names
        var locNames = [], duplicateNames = false, splChars=/[\\!@#$%|^?/&<>{}[\]*:;()+.,~\'\"]/, hasSpecialChars = false;
        _.forEach($(".location-name"), function (location) {
            if(splChars.test($(location).val()))
                hasSpecialChars = true;
            locNames.push($(location).val());
        })
        var namesSet = new Set(locNames);

        if(namesSet.size !== locNames.length){
           duplicateNames = true;
        }
        if(!duplicateNames && !hasSpecialChars) {
            $('#editLocationsDlg').activity();
            OPM$.cloudMap.cloudMapService.updateDzLocations(jsonData)
                .done(function (data) {
                    MSG$.showInfoMsg({status: 'success', content: 'Locations saved successfully!'});
                    GCM$.common_functions.closeDialog('editLocationsDlg');
                    displayMap();
                }).always(function () {
                    $('#editLocationsDlg').activity(false);
            });
        } else if(duplicateNames){
            MSG$.showErrorMsg({ status: 'Error', content: 'Duplicate names found! Please use unique location names before saving.'})
        }
        else if(hasSpecialChars){
            MSG$.showErrorMsg({ status: 'Error', content: 'Special characters found in location name! Please remove special characters from location names before saving.'})
        }
    }


    function updateCloudMap(data) {
        if($('.an-cluster-container').length > 0){
           var vueData = VUE$.getDataFromApp(clusterVueInstance);
           _.forEach(vueData.deploymentZones, function (dz, index) {
               if(dz.id === data.content.deploymentZones[0].id) {
                    clusterVueInstance.$data.deploymentZones.splice(index, 1, data.content.deploymentZones[0]);
               }
           })
        }
    }

    function showDeployedValues(e) {
        var el$ = $(e.target).closest('.an-cnf').length > 0 ? $(e.target).closest('.an-cnf') : $(e.target).closest('.an-paas-component'),
            namespace = el$.attr('data-namespace'),
            releaseName = el$.attr('data-releaseName'),
            clusterId = el$.closest('.an-cluster').attr('id'),
            dzId = el$.closest('.an-cluster').attr('data-dzId');

        $(el$).activity();
        OPM$.cloudMap.cloudMapService.getDeployedValues(dzId, clusterId, namespace, releaseName)
            .done(function (data) {
                if ($("#dryRunDialog").length > 0) {
                    $("#dryRunDialog").detach();
                }

                data.title = "Deployed Values";
                var html = Handlebars.templates['lcm_federations_dryRun'](data);
                $('body').append(html);

                $("#dryRunDialog").hide().fadeIn().draggable({
                    handle: "header"
                }).position({
                    my: "center",
                    at: "center",
                    of: "body"
                });

                GCM$.accessibility.dialogAccessibility.addDialogKeyNav($("#dryRunDialog"));
                setTimeout(function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                    $("#dryRunDialog :tabbable")[0].focus();
                })
            }).always(function (data) {
                $(el$).activity(false);
            });
    }

    function hideShowSubMenus(e) {
        //e.stopPropagation();
        e.preventDefault();
        var target = $(e.target).closest('li');
        if ($(target).hasClass('an-sub-menu-parent')) {
            var $subMenu = $(target).find("> .an-sub-menu");
            $('.an-sub-menu').slideUp();

            if ($subMenu.css('display') === 'none') {
                $subMenu.slideDown().show().position({
                    my: 'left top',
                    at: 'right top',
                    of: target
                })
            }
        }
    }

    function toggleSmallPaaS() {
        if ((Cookies.get('an-paas-style') === "true") || (typeof Cookies.get('an-paas-style') === "undefined")) {
            Cookies.set("an-paas-style", false);
            $('#cloudMapView').removeClass('cn-small-paas');
        } else {
            Cookies.set("an-paas-style", true);
            $('#cloudMapView').addClass('cn-small-paas');
        }
    }

    function toggleClusterViewMenu() {
        event.stopPropagation();
        GCM$.common_functions.slideUpAllMenus();
        if ($('.cluster-view-menu').css('display') === "none") {
            $('.cluster-view-menu').show().slideDown().position({
                my: "right top",
                at: "right bottom",
                of: $('#clusterViewMenuIcon')
            });
            $('#clusterViewMenuIcon').attr('aria-expanded', 'true');
        } else {
            $('.cluster-view-menu').slideUp("normal", function () {
                $('.cluster-view-menu').hide();
            });
            $('#clusterViewMenuIcon').attr('aria-expanded', 'false');
        }
    }

    function clusterViewKeyNav() {
        var selector$ = $(".an-cluster-container");
        selector$.off().on('keydown', function (e) {
            var k = e.keyCode;
            var curr = selector$.find(':focus');
            if (curr.attr('role') !== "menuitem") {
                switch (k) {
                    case GCM_KEY$.ENTER:
                    case GCM_KEY$.SPACE:
                        if (!curr.is("button")) {
                            $(curr).click();
                        }
                        break;
                    case GCM_KEY$.ESCAPE:
                        e.stopPropagation();
                        break;
                    case GCM_KEY$.LEFT_ARROW:
                        e.preventDefault();
                        var $prev = getPrevFocusableEl(curr.closest('.an-cluster'), curr);
                        $prev.focus();
                        break;
                    case GCM_KEY$.RIGHT_ARROW:
                        e.preventDefault();
                        var $next = getNextFocusableEl(curr.closest('.an-cluster'), curr);
                        $next.focus();
                        break;
                }
            }
        });

        GCM$.accessibility.menuAccessibility.makeMenuKeyNav($('.cluster-view-menu'), $('#clusterViewMenuIcon'));
        _.forEach($(".an-cluster"), function (cluster$) {
            GCM$.accessibility.menuAccessibility.makeMenuKeyNav($(cluster$).find('.cluster-menu'), $(cluster$).find('i.an-menu-icon').first());
        });

        $('#cloudMapView').on('keyup', function (e) {
            if (e.keyCode === GCM_KEY$.ESCAPE) {
                $('#cloudMapView').fadeOut();
                $('#toolsIcon').focus();
            }
        });

    }

    function getPrevFocusableEl(container, currFocus) {
        var items = $(container).find('.an-focusable'),
            i =  items.length-1;
        while(i > 0) {
            if(currFocus.is(items[i])){
                return items[i-1];
            }
            i--;
        }
        return items.first();
    }

    function getNextFocusableEl(container, currFocus) {
        var items = $(container).find('.an-focusable'),
            i = 0;
        while(i < items.length-1) {
            if(currFocus.is(items[i])){
                return items[i+1];
            }
            i++;
        }
        return items.last();
    }

    function initZoomPanControls() {
        var paper = new Snap("#worldMap");
        var intervalF,
            clearIntervalF = function () {
                clearInterval(intervalF);
            },
            defaultZoom = 1,
            zoom = defaultZoom;

        $("#zoomPanButtons").show();
        paper.zpd();  // zoomThreshold: [0.3, 2]
        paper.zoomTo(defaultZoom, 200, 0, undefined, positionDZMarkers);

        document.getElementById('reset').onmousedown = function () { reset(); }
        document.getElementById('reset').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) reset(); }

        document.getElementById('left').onmousedown = function () { panLeft(); }
        document.getElementById('left').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) panLeft(); }
        document.getElementById('left').onmouseup = clearIntervalF;
        document.getElementById('left').onmouseleave = clearIntervalF;
        document.getElementById('left').onkeyup = clearIntervalF;
        //document.getElementById('left').onblur = clearIntervalF;

        document.getElementById('right').onmousedown = function () { panRight(); };
        document.getElementById('right').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) panRight(); };
        document.getElementById('right').onmouseup = clearIntervalF;
        document.getElementById('right').onmouseleave = clearIntervalF;
        document.getElementById('right').onkeyup = clearIntervalF;


        document.getElementById('up').onmousedown = function () { panUp(); }
        document.getElementById('up').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) panUp(); }
        document.getElementById('up').onmouseup = clearIntervalF;
        document.getElementById('up').onmouseleave = clearIntervalF;
        document.getElementById('up').onkeyup = clearIntervalF;

        document.getElementById('down').onmousedown = function () { panDown() }
        document.getElementById('down').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) panDown() }
        document.getElementById('down').onmouseup = clearIntervalF;
        document.getElementById('down').onmouseleave = clearIntervalF;
        document.getElementById('down').onkeyup = clearIntervalF;


        document.getElementById('zoom2x').onmousedown = function () { zoomOut() };
        document.getElementById('zoom2x').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) zoomOut() };
        document.getElementById('zoom2x').onkeyup = clearIntervalF;

        document.getElementById('zoom05x').onmousedown = function () { zoomIn()  };
        document.getElementById('zoom05x').onkeydown = function (e) { if(e.keyCode === GCM_KEY$.ENTER) zoomIn()  };
        document.getElementById('zoom05x').onkeyup = clearIntervalF;

        function reset() {
            paper.panTo(0, 0, 0, undefined, positionDZMarkers);
            paper.zoomTo(defaultZoom, 100, 0, undefined, positionDZMarkers);
            zoom = defaultZoom;
        }

        function panLeft() {
            paper.panTo('-10', '0', 0, undefined, positionDZMarkers);
            intervalF = setInterval(function () {
                paper.panTo('-10', '0', 0, undefined, positionDZMarkers);
                positionDZMarkers();
            }, 100);
        }

        function panRight() {
            paper.panTo('+10', '0', 0, undefined, positionDZMarkers);
            intervalF = setInterval(function () {
                paper.panTo('+10', '0', 0, undefined, positionDZMarkers);
                positionDZMarkers();
            }, 100);
        }

        function panUp() {
            paper.panTo('+0', '-10', 0, undefined, positionDZMarkers);
            intervalF = setInterval(function () {
                paper.panTo('+0', '-10', 0, undefined, positionDZMarkers);
            }, 100);
        }

        function panDown() {
            paper.panTo('+0', '+10', 0, undefined, positionDZMarkers);
            intervalF = setInterval(function () {
                paper.panTo('+0', '+10', 0, undefined, positionDZMarkers);
            }, 100);
        }

        function zoomOut() {

            if (zoom < 2) {
                zoom += 0.1
            }

            paper.zoomTo(zoom, 100, 0, undefined, positionDZMarkers);
            setTimeout(function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                positionDZMarkers();
            }, 100);
        }

        function zoomIn() {

            if (zoom > 0.3) {
                zoom -= 0.1
            }

            paper.zoomTo(zoom, 100, 0, undefined, positionDZMarkers);
            setTimeout(function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                positionDZMarkers();
            }, 100);        }

        // Attach the keyboard event to the container wrapping the map
        document.getElementById('geographicView').onkeydown = function (e) {
            switch (e.keyCode) {
                case 37: // left
                    paper.panTo('-10', '0', 0, undefined, positionDZMarkers);
                    break;
                case 38: // up
                    paper.panTo('+0', '-10', 0, undefined, positionDZMarkers);
                    break;
                case 39: // right
                    paper.panTo('+10', 0, undefined, positionDZMarkers);
                    break;
                case 40: // down
                    paper.panTo('+0', '+10', 0, undefined, positionDZMarkers);
                    break;
            }
        };

    }

    function appendTooltipInfo(data) {
        _.forEach(data.deploymentZones, function (dz) {
            _.forEach(dz.clusters, function (cluster) {
                var temp = {
                    "Network Functions": typeof cluster.cnfs !== "undefined" ? cluster.cnfs.length : 0
                };
                _.assign(cluster.tooltip, temp);

                _.forEach(cluster.cnfs, function (cnf) {
                    var temp1 = {
                        "Microservices": typeof cnf.msClasses !== "undefined" ? cnf.msClasses.length : 0
                    };
                    _.assign(cnf.tooltip, temp1);
                });
            });
        });
        return data;
    }

    function deleteAllFederations(e) {
        var el$ = $(e.target),
            dzId = $(el$).closest('.an-cluster').attr('data-dzId'),
            clusterId = $(el$).closest('.an-cluster').attr('id');

        OPM$.repoManagement.repoService.getAllChartRepos().done(
            function (repoData) {
                repoData.dzId = dzId;
                repoData.clusterId = clusterId;

                var selectRepoDlg = Handlebars.templates['cloudMap_selectRepo'](repoData);
                $(selectRepoDlg).appendTo("body").position({
                    my: 'right top',
                    at: 'right bottom',
                    of: el$
                });

                // VALIDATION$.validateOnInputChange($('#selectRepoDlgForm'), $("#deleteAllFederationsBtn"));

            });
    }

    function onDeleteAllFederations(e) {

        var skipRookCephDeletion = ($('#skipRookCephDeletion').is(':checked') ? true : false),
            repoName = $('#standAloneSelectRepoName').val(),
            dzId = $('#selectRepoDlg').attr('data-dzid'),
            clusterId = $('#selectRepoDlg').attr('data-clusterid');

        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete federations?',
            position: { my: 'left top', at: 'right bottom', of: $(e.target) },
            yes: function () {

                OPM$.cloudMap.cloudMapService.deleteAllCnf(dzId, clusterId, repoName, skipRookCephDeletion)
                    .done(function (data) {
                        MSG$.showInfoMsg({ status: 'Information', content: data.successMessage });
                    }).always(function () {
                        // norhing to do.

                    }).fail(function (data) {
                        MSG$.showErrorMsg({ status: 'Error', content: data.responseJSON.errorMessage })
                    });
            },
            close: function () {

            }
        });
    }

    function customClusterView(clusterView, index) {

        if ($("#createCustomViewDlg").length < 1) {

            var customClusterFormData = {};

            if (typeof clusterView === "undefined") { //for create operation
                customClusterFormData = {
                    'index': undefined,
                    'name': '',
                    'description': '',
                    'deploymentZones': []
                }
            } else {  //for update operation
                customClusterFormData = _.cloneDeep(clusterView);
            }

            _.forEach(allDzsList, function (dz) {
                //initializing all DZs to checked 'false'
                dz.checked = false;
            });

            //Setting checked=true for those DZs in current custom cluster view instance that is selected for edit
            _.forEach(customClusterFormData.deploymentZones, function (eachDz) {
                _.forEach(allDzsList, function (dz, index) {
                    if (dz.id === eachDz.id) {
                        allDzsList[index].checked = true;
                    }
                })
            })
            customClusterFormData.deploymentZones = _.cloneDeep(allDzsList);

            customClusterFormData.index = index;
            var html = Handlebars.templates['cloudMap_createCustomViewDlg'](customClusterFormData);
            $('main section.an-layout-center-center').append(html);
            var vueConfig = {
                el: "#createCustomViewDlg",
                data: customClusterFormData
            }
            customClusterFormVueInstance = VUE$.createInstance(vueConfig);
            $("#createCustomViewDlg").position({
                my: "center",
                at: "center",
                of: 'body'
            }).draggable();

            VALIDATION$.validateOnInputChange($("#createCustomViewDlg form"), $("#saveCustomView"), undefined, undefined, OPM$.cloudMap.cloudMapController.checkIfDzIsSelected);
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($("#createCustomViewDlg"));
            GCM$.accessibility.tableAccessibility.makeTableKeyNav($("#customClusterViewDzTable"));
        }
    }

    function saveCustomView() {
        var json = {}, userPrefJSON;

        if (typeof customClusterTableVueInstance === "undefined" ||
            typeof customClusterTableVueInstance.$data === "undefined") {
            json = {
                clusterViews: []
            };
        } else {
            json = _.cloneDeep(customClusterTableVueInstance.$data);
        }
        var formData = _.cloneDeep(customClusterFormVueInstance.$data),
            checkedDzs = [];
        _.forEach(formData.deploymentZones, function (dz, index) {
            if (dz.checked) {
                checkedDzs.push(formData.deploymentZones[index]);
            }
        });
        formData.deploymentZones = _.cloneDeep(checkedDzs);

        if (typeof formData.index !== "undefined") {  //Update operation
            var index = formData.index;
            delete formData.index;
            json.clusterViews[index] = _.cloneDeep(formData);
            customClusterTableVueInstance.$data.clusterViews.splice(index, 1, formData);
        } else {    //Create operation
            json.clusterViews.push(formData);
            customClusterTableVueInstance.$data.clusterViews.push(formData);
        }
        userPrefJSON = { 'userPreferences': JSON.stringify(json) };
        OPM$.app.userPrefs = userPrefJSON;

        $("#createCustomViewDlg").activity();
        OPM$.cloudMap.cloudMapService.saveUserPreferences(userPrefJSON)
            .done(function () {
                MSG$.showInfoMsg({
                    status: 'Success', content: 'Custom cluster view successfully saved.',
                    close: function () {
                        $("#gridView tbody tr:last :focusable").first().focus();
                    }
                });
                GCM$.common_functions.closeDialog('createCustomViewDlg');
            }).always(function () {
                $("#createCustomViewDlg").activity(false);
            })
    }

    function checkIfDzIsSelected() {
        var valid = false;
        _.forEach(customClusterFormVueInstance.$data.deploymentZones, function (dz) {
            if (dz.checked) {
                valid = true;
                return;
            }
        })
        return valid;
    }

    function toggleClusterState(e) {
        var $cluster = $(e.target).closest('li.an-cluster');
        if ($cluster.hasClass('an-expanded')) {
            $cluster.removeClass('an-expanded').addClass('an-collapsed');
            $cluster.find('button.cn-cluster-toggle-state').attr('aria-expanded', 'false');
            $cluster.find('button.cn-cluster-toggle-state').removeClass('an-icon-scroll_triangle_down_dark').addClass('an-icon-scroll_triangle_right_dark');
            Cookies.set($cluster.attr('id'), 'collapsed');
        } else if ($cluster.hasClass('an-collapsed')) {
            $cluster.removeClass('an-collapsed').addClass('an-expanded');
            $cluster.find('button.cn-cluster-toggle-state').attr('aria-expanded', 'true');
            $cluster.find('button.cn-cluster-toggle-state').removeClass('an-icon-scroll_triangle_right_dark').addClass('an-icon-scroll_triangle_down_dark');
            Cookies.set($cluster.attr('id'), 'expanded');
        }
    }
    function skipToMain() {
        //Bring focus back to first tabbable element of main section
        if ($(".an-section").length > 0) {
            var sectionList = $('main').find('.an-section-top')
            $(sectionList).last().find(":tabbable").first().focus();
        } else {
            $("main :tabbable").first().focus();
        }
    }

    function launchGeoMapHelp() {
        var html = Handlebars.templates['cloudMap_geoMapHelp']();
        $("body").append(html);

        $("#geoMapHelpContent").show().position({
            my: "center",
            at: "center",
            of: "body"
        });

        $("#geoMapHelpContent :tabbable").first().focus();
    }

    function launchImportLocations() {
        if ($('#importLocationsDialog').length < 1) {
            var html = Handlebars.templates['cloudMap_importDialog']();
            $('#geographicView').append(html);

            $("#importLocationsDialog").hide().fadeIn().draggable({
                handle: "header"
            }).position({
                my: "right top",
                at: "right+40 bottom",
                of: $("#importLocationsIcon")
            });
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#importLocationsDialog'));
            $("#importLocationsForm").find("input[name=file]").on('change', function () {
                if (fileSelected("#importLocationsForm"))
                    $('#importLocations').prop('disabled', false);
                else
                    $('#importLocations').prop('disabled', true);
            });
            GCM$.common_functions.inputFile();

            $("#importLocations").off().on('click', function (event) {
                event.preventDefault();
                var fileData = new FormData($('#importLocationsForm')[0]);
                doImportLocations(fileData);
            });
        }
    }

    function fileSelected(formSelected){
        var res = false, form;
        form = $(formSelected)[0];

        if(form){
            res= form.checkValidity();
        }
        return res;
    }

    function doImportLocations(fileData) {
        $('#importLocationsDialog').activity();
        $.ajax({
            url: '/opm/location/importLocations',
            data: fileData,
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data) {
                $('#importLocationsDialog').activity(false);
                MSG$.showInfoMsg({ status: 'Success', content: 'Locations imported successfully' });
                GCM$.common_functions.closeDialog('importLocationsDialog');
                displayMap();
            },
            error: function (res) {
                MSG$.showErrorMsg({ status: 'Error', content: res.responseJSON.errorMessage });
                $('#importLocationsDialog').activity(false);
            }
        });
    }

    function closeDialog() {
        //Re-setting locationsData so it doesn't show up any staged entries when the dialog is re-opened
       locationsData = _.cloneDeep(locations_reset);
    }

    return {
        renderCloudMap: renderCloudMap,
        renderAssociations: renderAssociations,
        associationVisibility: associationVisibility,
        highlightAssociations: highlightAssociations,
        cloudMapViewMenu: cloudMapViewMenu,
        showFilterDialog: showFilterDialog,
        filterByTag: filterByTag,
        displayMap: displayMap,
        changeMapScale: changeMapScale,
        positionDZMarkers: positionDZMarkers,
        returnPanZoomMap: returnPanZoomMap,
        launchScalingDialog: launchScalingDialog,
        updateSliders: updateSliders,
        deleteCNF: deleteCNF,
        showStatus: showStatus,
        showClusterStatus: showClusterStatus,
        deleteCluster: deleteCluster,
        updateCloudMap: updateCloudMap,
        toggleFullScreen: toggleFullScreen,
        //toggleMarkDzLocation: toggleMarkDzLocation,
        showDeployedValues: showDeployedValues,
        hideShowSubMenus: hideShowSubMenus,
        toggleSmallPaaS: toggleSmallPaaS,
        toggleClusterViewMenu: toggleClusterViewMenu,
        deleteAllFederations: deleteAllFederations,
        onDeleteAllFederations: onDeleteAllFederations,
        customClusterView: customClusterView,
        saveCustomView: saveCustomView,
        toggleClusterState: toggleClusterState,
        checkIfDzIsSelected: checkIfDzIsSelected,
        renderEditLocationsDlg: renderEditLocationsDlg,
        onUpdateDzLocations: onUpdateDzLocations,
        renderGeoMap: renderGeoMap,
        renderLocationPoints: renderLocationPoints,
        skipToMain: skipToMain,
        launchGeoMapHelp: launchGeoMapHelp,
        launchImportLocations: launchImportLocations,
        closeDialog: closeDialog
    };

})();