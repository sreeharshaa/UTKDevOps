OPM$.sysConfig = OPM$.sysConfig || {};

OPM$.sysConfig.sysConfigController = (function(){

    var formData = {
        mode: "",
        systemConfig: {
            featureFlag : "",
            runtimeTimeoutParameters: [{
                decription: "",
                min: "",
                max: "",
                name: "",
                value: ""
            }]
        }
    }, selectedTab="", featureFlagInstance = [], runtimeTimeoutInstance=[];

    function launchSysConfigDlg() {
        if($('#sysConfigDlg').length === 0) {
            OPM$.sysConfig.sysConfigService.getSysConfig()
            .done(function (data) {
                _.assign(formData, data);
                var html = Handlebars.templates['sysConfig_sysConfigDialog']();
                $('body').append(html);
                renderFeatureFlag()
                GCM$.common_functions.inputFile();
                //VALIDATION$.validateOnInputChange($('#sysConfigDlg form'), $('#buttonsDiv button'), undefined, undefined, undefined, true);
    
                $("#sysConfigDlg").hide().fadeIn().draggable({
                    handle: "header"
                }).position({
                    my: "center",
                    at: "center",
                    of: "body"
                });
                selectedTab = $('#featureFlagTab');
                GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#sysConfigDlg'));
                $('#sysConfigDlg :tabbable')[0].focus();
                var $tabs = $("#sysConfigDlg").find("header").find(".an-inline-tabs");
                $tabs.find('li').on('click', function (e) {
                    selectedTab = $(this);
                    var currTab = $tabs.find('.an-selected');
                    currTab.removeClass("an-selected");
                    currTab.attr({'tabindex': -1, 'aria-selected': 'false'});
                    selectedTab.addClass("an-selected");
                    selectedTab.attr({'tabindex': 0, 'aria-selected': 'true'});

                    $("#sysConfigDlg").find(".an-tabbed-form").hide();
                    selectedTab.css({"display": "flex"});
                    

                    if(this.id === 'featureFlagTab') {
                        $('#featureFlag-content').show();
                        renderFeatureFlag();
                        GCM$.accessibility.accessibilityCommon.setFocus($("#gridView"));
                    } else if (this.id === 'runtimeTab') {
                        $('#runtimeTimeout-content').show();
                        renderRuntimeTimeout();
                    }
                });
                GCM$.accessibility.tabAccessibility.tabKeyNav($tabs);
            });
        }
    }

    function renderFeatureFlag(){
        var html = Handlebars.templates['sysConfig_sysConfigDlgContent'](formData);
        $('#featureFlagContainer').empty().append(html);
        $("#featureFlagChkbx").off("change").on("change", function () {
            $("#saveSysConfig").prop("disabled", false);
        });
        featureFlagInstance = dataBindForm('#featureFlagForm', formData);
        VALIDATION$.validateOnInputChange($('#featureFlagForm'), $('#saveSysConfig'));   
    }

    function renderRuntimeTimeout(){
        var html = Handlebars.templates['sysConfig_runtimeTimeoutContent'](formData);
        $('#runtimeTimeoutContainer').empty().append(html);
        runtimeTimeoutInstance = dataBindForm('#runtimeTimeoutForm', formData);
        VALIDATION$.validateOnInputChange($('#runtimeTimeoutForm'), $('#saveSysConfig'));
    }

    function saveSysConfig() {
        OPM$.sysConfig.sysConfigService.saveSysConfig(formData.systemConfig)
        .done(function (data) {
            MSG$.showInfoMsg({status: 'Success', content: "Updated system configurations"});
        });
    }

    function dataBindForm(id, data) {
        var config = {
            el: id,
            data: data
        };
        return VUE$.createInstance(config);
    }


    return {
        launchSysConfigDlg: launchSysConfigDlg,
        saveSysConfig: saveSysConfig
    }
})();