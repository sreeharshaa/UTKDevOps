OPM$.sysConfig = OPM$.sysConfig || {};

OPM$.sysConfig.sysConfigService = (function() {

    function getSysConfig() {
        return GET_JSON$('/opm/systemConfig');
    }

    function saveSysConfig(jsonData) {
        return POST_JSON$({
            url: '/opm/systemConfig',
            data:  JSON.stringify(jsonData)
        });
    }

    function refreshDzDiscoverCache() {
        return POST_JSON$({
            url: '/opm/systemConfig/cacheRefresh',
            data:  null
        });
    }

    function getStandbyUsername() {
        return GET_JSON$('/opm/systemConfig/getStandbyUsername');
    }

    function oauthLogout(){
        return GET_JSON$('/oauth2/sign_out');
    }

    return {
        getSysConfig: getSysConfig,
        saveSysConfig: saveSysConfig,
        refreshDzDiscoverCache: refreshDzDiscoverCache,
        getStandbyUsername: getStandbyUsername,
        oauthLogout: oauthLogout
    };

})();