OPM$.DzAndCluster = OPM$.DzAndCluster || {};
OPM$.DzAndCluster.saved = OPM$.DzAndCluster.saved || {};

OPM$.DzAndCluster.saved.savedController = (function() {
    'use strict';

    var currentSavedDzOrClusterName = ''

    function handleOnClickSaved(e){
        var target = $(e.target);
        var type = $(e.target).closest('ul').prop('id') === 'dzSavedList' ? 'dz' : 
                    ($(e.target).closest('ul').prop('id') === 'clusterSavedList' ? 'cluster' : '');
        if(target.hasClass('an-icon-delete')){
            onDeleteSaved(e,type);
        }
        else if(target.closest("li").hasClass('savedListItem')){
            var savedDzOrClusterName =  $(e.target).closest("li").children('span').text();
            $('#dzSavedList li').removeClass('an-selected');
            $('#clusterSavedList li').removeClass('an-selected');
            target.closest("li").addClass('an-selected');
            getSavedDzOrCluster(savedDzOrClusterName, type);
        }
    }

    function getSavedDzOrCluster(savedDzOrClusterName, type){
            if(type==='dz'){
                $('#formPane').activity();
                OPM$.DzAndCluster.saved.savedService.getSavedDz(savedDzOrClusterName).done(function(data){
                    $("#formPane").empty();
                    currentSavedDzOrClusterName = savedDzOrClusterName;
                    FORM$.createForm('formPane', data);
                    OPM$.DzAndCluster.DzAndClusterController.renderFormControls(data.formType, 'dz');
                    disableBtnsForAttachType(type, data);
                }).always(function(){
                    $('#formPane').activity(false);
                })
            }
            else if(type=='cluster'){
                $('#formPane').activity();
                OPM$.DzAndCluster.saved.savedService.getSavedCluster(savedDzOrClusterName).done(function(data){
                    $("#formPane").empty();
                    currentSavedDzOrClusterName = savedDzOrClusterName;
                    var config = {
                        cloneFields: OPM$.DzAndCluster.K8s.K8sController.cloneFields,
                        deleteFields: OPM$.DzAndCluster.K8s.K8sController.deleteSelectedFields
                    };
                    FORM$.createForm('formPane', data, undefined, config);
                    OPM$.DzAndCluster.DzAndClusterController.renderFormControls(data.formType, 'cluster', data.platformType);
                    if(data.platformType === 'openstack'){
                        OPM$.DzAndCluster.DzAndClusterController.formFilter('basic');
                    }
                    disableBtnsForAttachType(type, data);
                }).always(function(){
                    $('#formPane').activity(false);
                })
            }
    }

    function disableBtnsForAttachType(formType, data) {
        var isAttach = false;
        if (!data || !data.forms) {
            return isAttach;
        }
        if (formType === 'dz') {
            for (var i = 0; i < data.forms.length; i++) {
                var form = data.forms[i];
                if (!form.fields) {
                    continue;
                }
                for (var j = 0; j < form.fields.length; j++) {
                    var field = form.fields[j];
                    if (field.name === 'type' && field.value === 'attach') {
                        isAttach = true;
                        break;
                    }
                }
                if (isAttach) break;
            }
        } else if (formType === 'cluster') {
            if (data.platformType === 'attach') {
                isAttach = true;
            }
        }
        // Hide the export template, clone and update buttons for attach type
        if(isAttach){
            $('#exportTemplateBtn').css('display', 'none');
            $('#cloneSavedBtn').css('display', 'none');
            $('#updateSavedBtn').css('display', 'none');
        }
    }

    function onDeleteSaved(e,type){
        var target = $(e.target);
        var savedDzOrClusterName = $(e.target).siblings('span').text();
        
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete the saved values '+ savedDzOrClusterName+'?',
            position: {my: 'left top', at: 'right bottom', of: $(e.target)},
            yes: function () {
               if(type==='dz'){
                OPM$.DzAndCluster.saved.savedService.deleteSavedDz(savedDzOrClusterName).done(function(res){
                    OPM$.DzAndCluster.DzAndClusterController.renderSavedList()
                    if(currentSavedDzOrClusterName === savedDzOrClusterName){
                        currentSavedDzOrClusterName = '';
                        $("#formPane").empty();
                    }
                }).always(function(){
                    $('#dzSavedList :tabbable')[0].focus();
                });
               }
               else if(type=='cluster'){
                OPM$.DzAndCluster.saved.savedService.deleteSavedCluster(savedDzOrClusterName).done(function(res){
                    OPM$.DzAndCluster.DzAndClusterController.renderSavedList()
                    if(currentSavedDzOrClusterName === savedDzOrClusterName){
                        currentSavedDzOrClusterName = '';
                        $("#formPane").empty();
                    }
                }).always(function(){
                    $('#clusterSavedList :tabbable')[0].focus();
                });
               }
            },
            close: function() {
                target.focus();
            }
        });
    }

    function updateDzorCluster(type){
        var formData = FORM$.getData('formPane');
        var override = ''
        MSG$.confirm({
            statement: 'Update Confirmation',
            question: 'Are you sure you want to update the saved values '+ currentSavedDzOrClusterName+'?',
            position: {my: 'center', at: 'center', of: 'body'},
            yes: function () {
                override = true;
               if(type==='dz'){
                var cloudType = '';
                _.find(formData.forms[0].fields, function(field){
                    if(field.name === 'type')
                        cloudType = field.value;
                })
                OPM$.DzAndCluster.saved.savedService.updateSavedDz(currentSavedDzOrClusterName,formData, override, cloudType).done(function(res){
                    MSG$.showInfoMsg({status: 'Success', content: res.successMessage});
                    getSavedDzOrCluster(currentSavedDzOrClusterName, type)
                }).always(function(){
                    $('#updateSavedBtn').focus();
                });
               }
               else if(type=='cluster'){
                OPM$.DzAndCluster.saved.savedService.updateSavedCluster(currentSavedDzOrClusterName, formData, override).done(function(res){
                    MSG$.showInfoMsg({status: 'Success', content: res.successMessage});
                    getSavedDzOrCluster(currentSavedDzOrClusterName, type);
                }).always(function(){
                    $('#updateSavedBtn').focus();
                });
               }
            },
            close: function() {
                $('#updateSavedBtn').focus();
            }
        });
    }

    function launchCloneDialog(e, type) {
        var html = Handlebars.templates['DzAndCluster_cloneSavedValues']();
        if ($('#cloneSavedValues').length < 1) {
            $('#DzAndClusterDialog').append(html);

            $('#cloneSavedValues').draggable({
                handle: 'header'
            }).position({
                my: "right top",
                at: "right bottom",
                of: $(e.target)
            });

            VALIDATION$.validateOnInputChange($("#cloneSavedValues"), $('#cloneSavedValuesButton'));
            $('#cloneSavedValuesButton').off().on('click', function () {
                var name = $('#cloneSavedValues input[name="name"]').val(),
                    data = FORM$.getData('formPane');
                cloneSavedValues(name, data, type);
            });

            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#cloneSavedValues'));
            $('#cloneSavedValues :tabbable')[0].focus();
            $('#cloneSavedValues').on('dialogClose', function () {
                $('#cloneSavedBtn')[0].focus();
            });
        }
    }

    function cloneSavedValues(name, data, type){
        if(type==='dz'){
            var cloudType = '';
            var override = false;
            _.find(data.forms[0].fields, function(field){
                if(field.name === 'type')
                    cloudType = field.value;
            })
            OPM$.DzAndCluster.saved.savedService.cloneSavedDz(name, data, override, cloudType).done(function(res){
                OPM$.DzAndCluster.DzAndClusterController.renderSavedList();
                MSG$.showInfoMsg({status: 'Success', content: res.successMessage});
                GCM$.common_functions.closeDialog('cloneSavedValues');
            }).always(function(){
                $('#updateSavedBtn').focus();
            });
           }
           else if(type=='cluster'){
            OPM$.DzAndCluster.saved.savedService.cloneSavedCluster(name, data).done(function(res){
                OPM$.DzAndCluster.DzAndClusterController.renderSavedList();
                MSG$.showInfoMsg({status: 'Success', content: res.successMessage});
                GCM$.common_functions.closeDialog('cloneSavedValues');
            }).always(function(){
                $('#updateSavedBtn').focus();
            });
           }
    }

    return {
        handleOnClickSaved: handleOnClickSaved,
        onDeleteSaved: onDeleteSaved,
        updateDzorCluster: updateDzorCluster,
        launchCloneDialog: launchCloneDialog
    }
})();