OPM$.DzAndCluster = OPM$.DzAndCluster || {};

OPM$.DzAndCluster.DzAndClusterController = (function() {
    var selectedTab = "";

    function openDzAndClusterDialog(){

        selectedTab = 'deploymentZoneLcmForm'; 
        var html = Handlebars.templates['DzAndCluster_DzAndCluster']();

        $('main > .an-layout-center-center').append(html);

        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#DzAndClusterDialog'), false);
        $('#DzAndClusterDialog :tabbable')[0].focus();

        renderManagedTree()

       
        renderSavedList();
            

        /*if(typeof tab !== 'undefined'){
            selectedTab = tab;
            $('.an-inline-tabs').find('li').removeClass('an-selected');
            $('.an-inline-tabs').find('[data="'+tab+'"]').closest('li').addClass('an-selected');
        }

        launchTab(selectedTab);
        getButtons(selectedTab);

        var $tabs = $("#DzAndClusterDialog").find("header").find(".an-inline-tabs");

        $tabs.find("li").on('click', function() {
            selectedTab = $(this).find('a').attr("data");

            $tabs.find("li").removeClass("an-selected");
            $tabs.find("li").attr({"tabindex": "-1", "aria-selected": "false"});
            $(this).addClass("an-selected");
            $(this).attr({"tabindex": "0", "aria-selected": "true"});
            launchTab(selectedTab);
            getButtons(selectedTab);
        });*/

        VALIDATION$.validateOnInputChange($('#createRepoDlg'), $('#addRepoBtn'));

        $('.accordion-container h3 span').on('click', function(e){
            var accordion$ = $(e.target).closest('.accordion-container').first();
            if(accordion$.hasClass('accordion-collapsed')){
                $('.accordion-container').addClass('accordion-collapsed').removeClass('accordion-expanded');
                accordion$.removeClass('accordion-collapsed').addClass('accordion-expanded');
            }
            if(accordion$.hasClass('managed-accordion')){
                renderManagedTree();
            }
            else if(accordion$.hasClass('saved-accordion')){
                renderSavedList();
            }
        })

    }

    function renderManagedTree(){
        OPM$.DzAndCluster.dzAndClusterService.getAllInstances()
            .done(function(data){
                loadTree(data, 'managed-tree-content', onTreeClick, 'delete');
            }).always(function(){
        });
    }
   

    function renderSavedList(){
        OPM$.DzAndCluster.dzAndClusterService.getAllSaved()
        .done(function(data){
            var html = Handlebars.templates['DzAndCluster_saved_savedList'](data);
            $('#savedContainer .accordion-content').empty().append(html);
            $('#dzSavedList li').on('click', OPM$.DzAndCluster.saved.savedController.handleOnClickSaved);
            $('#clusterSavedList li').on('click', OPM$.DzAndCluster.saved.savedController.handleOnClickSaved);
        }).always(function(){
        });
    }

    function loadTree(data, container, method, icon) {

        var config = {
            leafIcons: [icon],
            branchIcons: [icon],
            blockIcon: false,
            click: method,
            id: container,
            data: data
        };
        $('#'+container).empty().tree2(config);
    }

    function onTreeClick(e) {
        var target = $(e.target);
        e.stopPropagation();
        if(target.hasClass('an-icon-delete') || (target.hasClass('an-button') && $(target.children()[0]).hasClass('an-icon-delete'))){
            if(target.closest('li').attr("data-level") === "dz"){
                OPM$.DzAndCluster.dz.dzController.onDeleteDz(target.closest('li'));
            } else if(target.closest('li').attr("data-level") === "cluster") {
                var chartVal = target.closest('li').children('a').attr('data-chartval'),
                state = JSON.parse(chartVal).state;
                if(state === 'standby'){
                    MSG$.confirm({
                        statement: 'Delete Confirmation',
                        question: 'This cluster is in standby mode and only the reference is removed. Do you want to proceed?',
                        position: {my: 'center', at: 'center', of: 'body'},
                        yes: function () {
                            OPM$.DzAndCluster.K8s.K8sController.onDeleteCluster(target, target.closest('li').parent().closest('li').attr('data-id'), target.closest('li').attr('data-id'), $('#DzAndClusterDialog'), target.closest('li'));
                        }
                    });
                }
                else {
                    OPM$.DzAndCluster.K8s.K8sController.onDeleteCluster(target, target.closest('li').parent().closest('li').attr('data-id'), target.closest('li').attr('data-id'), $('#DzAndClusterDialog'), target.closest('li'));
                }
            }
        } else  if(!target.closest("li").hasClass('non-clickable')){
            if(target.closest('li').attr("data-level") === "dz") {
                OPM$.DzAndCluster.dz.dzController.getDeploymentZone(target.closest('li').attr('data-type'), target.closest('li').attr('data-id'));
                target.closest('ul.an-tree').find('li.an-selected').removeClass('an-selected');
                target.closest('li').addClass('an-selected');
            } else if(target.closest('li').attr("data-level") === "cluster") {
                OPM$.DzAndCluster.K8s.K8sController.getKubernetesCluster(target.closest('li').parent().closest('li').attr('data-id'), target.closest('li').attr('data-id'),target.closest('li').attr('data-name'),undefined, target.closest('li').parent().closest('li').attr('data-type'));
                target.closest('ul.an-tree').find('li.an-selected').removeClass('an-selected');
                target.closest('li').addClass('an-selected');
            }
        }
    }

    function renderCreateForm(addType) {
        if(addType === "cluster") {
            OPM$.DzAndCluster.K8s.K8sController.renderNewClusterForm();
        } else {
            OPM$.DzAndCluster.dz.dzService.getAllTypes().done(function (data) {
                var html = Handlebars.templates['DzAndCluster_dz_createDzDialog'](data);
                $('#formPane').empty().append(html);
                VALIDATION$.validateOnInputChange($('#createNewForm'), $('#addDzBtn'));
                $('#createNewForm').find(':tabbable')[0].focus();    
                renderFormControls("newDZ");
            });
        }   
        $("#crudDeploymentZones li").removeClass("an-selected");  
    }

    /*function saveData(){
        if (selectedTab === 'deploymentZoneLcmForm') {
            OPM$.DzAndCluster.dz.dzController.saveDeploymentZone();
        } else if (selectedTab === 'K8sLcmForm') {
            OPM$.DzAndCluster.K8s.K8sController.saveKubernetesCluster();
        }
    }*/

    function launchImportConfigDlg(){
        var html = Handlebars.templates['DzAndCluster_importConfig']();
        if (!($('#importConfigDlg').is(':visible'))) {
            $('body').append(html);

            $("#importConfigDlg").hide().fadeIn().draggable({
                handle: "header"
            }).position({
                my: "top",
                at: "right",
                of: $('#importSavedButton')
            });
            GCM$.common_functions.inputFile();
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#importConfigDlg'));
            $('#importConfigDlg :tabbable')[0].focus();
            $('#importConfigDlg').on('dialogClose', function () {
                $('#importSavedButton')[0].focus();
            });
        }
    }

    function rendrDzK8Templates(){
        $("#importConfigDlg").activity();
        OPM$.DzAndCluster.K8s.K8Service.renderDzK8Templates()
            .done(function (data) {
                var tpl = Handlebars.templates['DzAndCluster_dzClusterTemplates'](data);
                $(".cn-select-templates").detach();
                $("#importForm").append(tpl);


                $('#selectTemplateBtn').off('keyup');
                $('#templatesList').off('keyup');
                GCM$.accessibility.menuAccessibility.makeMenuKeyNav($('#templatesList'), $('#selectTemplateBtn'));

                $('#templatesList').find('li').on('click', function(e) {
                    e.stopPropagation(); e.preventDefault();
                    var selectedTpl = $(e.target).text().trim();
                    $(e.target).closest('ul').find('li.an-selected').removeClass('an-selected');
                    $(e.target).closest('li').addClass('an-selected');
                    $('#templatesList').slideUp("normal", function () {
                        $('#templatesList').hide();
                    });
                    $('#selectTemplateBtn')[0].focus();

                    $('#configFormPane').activity();
                    OPM$.DzAndCluster.K8s.K8Service.renderDzK8Tpl(selectedTpl)
                        .done(function (res) {
                            $('#selectTemplateBtn span').text(selectedTpl);
                            updateConfigForm(res);
                            $("#importForm label").first().find('span').text("");
                            $("#importForm input[type='file']").val('');
                        }).always(function () {
                            $('#configFormPane').activity(false);
                    })
                });

                $('#templatesList').find('li').on('keyup', function(e) {
                    if (e.keyCode === GCM_KEY$.RIGHT_ARROW) {
                        $(e.target).find('button')[0].focus();
                    }
                });

                $('#templatesList').find('li button').on('keyup', function(e) {
                    if (e.keyCode === GCM_KEY$.LEFT_ARROW) {
                        $(e.target).closest('li')[0].focus();
                    }
                });
            }).always(function () {
            $("#importConfigDlg").activity(false);
        })
    }

    function doImportFile(e, saveDZ) {
        e.stopPropagation();e.preventDefault();
        var fileData = new FormData($('#importForm')[0]);
        var name = '?name='+ fileData.get('dzCluster-name'), 
        saveDZ = typeof saveDZ !== 'undefined' ? (saveDZ ? '&action=saveDZ' : '&action=noSaveDZ') : '';
        fileData.delete('dzCluster-name');

        $('#importConfigDlg').activity();
        $.ajax({
            url: '/opm/cloudmap/importConfig'+name + saveDZ,
            data: fileData,
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data) {
                $('#importConfigDlg').activity(false);
                MSG$.showInfoMsg({status: 'Success', content: 'Saved Values imported successfully', });
                renderSavedList();
                GCM$.common_functions.closeDialog('importConfigDlg');
            },
            error: function (res) {
                if(res.responseJSON.action === "override"){
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: res.responseJSON.errorMessage,
                        yes: function () {
                            saveDZ = true;
                            doImportFile(e,saveDZ)
                        },
                        no: function (){
                            saveDZ = false;
                            doImportFile(e,saveDZ)
                        }
                    })
                }
                else {
                    MSG$.showErrorMsg({status: 'Error', content: res.responseJSON.errorMessage});
                }
                $('#importConfigDlg').activity(false);
            }
        });
    }

    function updateConfigForm(data) {
        GCM$.form.createForm('configFormPane', data);
        VALIDATION$.validateOnInputChange($("#configFormPane"), $('.config-buttons-set button'));
    }

    function deployConfig(overrideInfo) {
        var formData = FORM$.getData('configFormPane');
        $("#configFormPane").activity();
        OPM$.DzAndCluster.K8s.K8Service.deployClusterConfig(formData, overrideInfo)
            .done(function (data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                GCM$.common_functions.closeDialog('importConfigDlg');
            }).always(function (data) {
            $("#configFormPane").activity(false);
            OPM$.DzAndCluster.dz.dzController.getAllDzInstances();
            OPM$.DzAndCluster.K8s.K8sController.getK8ClusterInstances();
        }).fail(function (res) {
            if (res.responseJSON.result === "confirm") {
                MSG$.confirm({
                    statement: 'Confirmation',
                    question: res.responseJSON.errorMessage,
                    yes: function () {
                        var order = res.responseJSON.order,
                            urlStr = "";
                        if(order === 1){
                            urlStr = "?override1=true"
                        } else if(order > 1) {
                            urlStr = "?"+res.responseJSON.additionalData+"&override"+order+"=true"
                        }
                        deployConfig(urlStr);
                    }
                });
            }
        });
    }


    function launchExportDialog(e, formId, form) {
        if( $("#exportDlg").length > 0){
            $("#exportDlg").detach();
        }
        var html = Handlebars.templates["DzAndCluster_exportConfig"]({ form: form });
        var saveDBBool = 'false';
        $("body").append(html);

        $("#exportDlg").draggable({
            handle: "header"
        }).position({
            my: "right top",
            at: "right bottom",
            of: $(e.target)
        });
        $('input[type="radio"]').on('change', function(event){
            saveDBBool = event.target.value;
            if(saveDBBool  === 'true'){
                $('#saveValueFile').css('display', 'block');
            }
            else if(saveDBBool === 'false'){
                $('#saveValueFile').css('display', 'none');
            }
        })
        $('#exportButton').off().on('click', function(){
            doExport(formId,form, saveDBBool);
        });
        VALIDATION$.validateOnInputChange($('#exportDlg'), $('#exportButton'));
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#exportDlg'));
        $('#exportDlg :tabbable')[0].focus();
        $('#exportDlg').on('dialogClose', function () {
            e.target.focus();
        });
    }

    function doExport(formId, form, saveDBBool, override) {
        var formData = FORM$.getData(formId),
            fileName = $('#exportFilename').val(),
            templateUrl = '',
            url = '';
            if(typeof override === 'undefined')
                override = '';
        
            if(form.includes('saved')){
                templateUrl = form === "savedDZ" ? '?clusterTemplate=false': '?clusterTemplate=true';
                url = '/opm/cloudmap/exportConfig'+templateUrl;
            }
            else{
                var templateName = saveDBBool  === 'true' ? '&templateName='+$('#savedValueName').val() : ''
                templateUrl = formId === "formPane" ? '?clusterTemplate=true': '';
                url ='/opm/cloudmap/exportPlatformCluster'+templateUrl+'&saveInDB='+saveDBBool+templateName+override;
            }


        $("#"+formId).activity();
        AJAX$({
            type: "POST",
            contentType: "application/json",
            url: url,
            data: JSON.stringify(formData)
        }).done(function (data) {
            GCM$.common_functions.downloadTextAsFile(fileName, data);
            GCM$.common_functions.closeDialog("exportDlg");
            MSG$.showInfoMsg({status: 'Success', content: 'Saved Values exported successfully', });
        }).always(function () {
            $("#"+formId).activity(false);
        }).fail(function (res) {
            if(res.responseJSON.action === "override"){
                MSG$.confirm({
                    statement: 'Confirmation',
                    question: res.responseJSON.errorMessage,
                    yes: function () {
                        var override = '&override=true'
                        doExport(formId, form, saveDBBool, override)
                    }
                })
            }
            else {
            MSG$.showErrorMsg({status: 'Error', content: 'Export Failed', close: function() {
                    $('#exportButton')[0].focus();
                }
            });
        }
        })
    }
    
    function launchSaveDzClusterTpl() {
        var html = Handlebars.templates['DzAndCluster_saveDzClusterTemplate']({});
        if (!($('#saveDzClusterTplDlg').is(':visible'))) {
            $('body').append(html);

            $('#saveDzClusterTplDlg').draggable({
                handle: 'header'
            }).position({
                my: 'center',
                at: 'center',
                of: 'body'
            });

            VALIDATION$.validateOnInputChange($("#saveDzClusterTplDlg"), $('#saveDzClusterTplBtn'));
            $('#saveDzClusterTplBtn').off().on('click', function () {
                var name = $('#saveDzClusterTplDlg input[name="name"]').val(),
                    desc = $('#saveDzClusterTplDlg textarea[name="description"]').val(),
                    data = FORM$.getData('configFormPane');
                saveDzK8Template(name, desc, data);
            });

            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#saveDzClusterTplDlg'));
            $('#saveDzClusterTplDlg :tabbable').first()[0].focus();
            $('#saveDzClusterTplDlg').on('dialogClose', function () {
                $('#saveDzClusterTplDlg')[0].focus();
            });
        }
    }

    function saveDzK8Template(name, desc, data, override) {
        if(templateNameIsValid(name)) {
            $("#saveDzClusterTplDlg").activity();
            OPM$.DzAndCluster.K8s.K8Service.saveDzK8Template(name, desc, data, override)
                .done(function (data) {
                    GCM$.common_functions.closeDialog('saveDzClusterTplDlg');
                    rendrDzK8Templates();
                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage,
                        close: function() {
                            GCM$.common_functions.closeDialog('saveDzClusterTplDlg');
                        }
                    });
                }).fail(function (res) {
                if (res.responseJSON.result === "confirm") {
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: res.responseJSON.errorMessage,
                        yes: function () {
                            saveDzK8Template(name, desc, data, true);
                        }
                    });
                }
            }).always(function () {
                $("#saveDzClusterTplDlg").activity(false);
            });
        } else {
            MSG$.showErrorMsg({status: 'Error', content: 'Invalid Template Name!! No spaces are allowed.',
                close: function() { $('#saveDzClusterTplDlg')[0].focus(); }});
        }

    }

    function templateNameIsValid(name) {
        if(name.indexOf(" ") > -1){
            return false;
        } else {
            return true;
        }
    }

    function onDeleteTemplate(e) {
        e.preventDefault(); e.stopPropagation();
        var target = $(e.target),
            templateName = $(target).closest('li').find('a[name="templateName"]').text().trim();
        e.stopPropagation();
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete the template '+ templateName+'?',
            position: {my: 'left top', at: 'right bottom', of: $(e.target)},
            yes: function () {
                $('#selectTemplateBtn').activity();
                OPM$.DzAndCluster.K8s.K8Service.deleteDzK8Template(templateName)
                    .done(function (res) {
                        MSG$.showInfoMsg({status: 'Success', content: res.successMessage});
                        rendrDzK8Templates();
                    }).always(function () {
                    $('#selectTemplateBtn').activity(false);
                })
            },
            close: function() {
                $('#selectTemplateBtn')[0].focus();
            }
        });
    }

    function renderFormControls(formType, type, dzType) {
        var html = Handlebars.templates['DzAndCluster_formControls']({type: type, formType: formType}),
            headerStr;
        $('#formPane').append(html);
        
        switch (formType) {
            case 'managedDZ':
                headerStr = '<h4>Managed Deployment Zone Form</h4>';
                break;
            case 'managedCluster':
                headerStr = '<h4>Managed Cluster Form</h4>';
                break;
            case 'addDZ':
                headerStr = '<h4>Create Deployment Zone Form</h4>';
                break;
            case 'addCluster':
                headerStr = '<h4>Create Cluster Form</h4>';
                break;
            case 'savedDZ':
                headerStr = '<h4>Saved Deployment Zone Form</h4>';
                break;   
            case 'savedCluster':
                headerStr = '<h4>Saved Cluster Form</h4>';
                break;     
            case 'newDZ':
                headerStr = '<h4>Add Deployment Zone</h4>';
                break;
            case 'newCluster':
                headerStr = '<h4>Add Cluster</h4>';
                break;   
        }
        if((type === 'cluster' && (typeof dzType != undefined && dzType === 'openstack'))){
            var formPaneHeader = Handlebars.templates['DzAndCluster_formPaneHeader']()
            $('#formPane').prepend(formPaneHeader);
            $("#formHeaderPane").prepend(headerStr);
            $('#formHeaderPane h4').css('flex','1');
        }
        else{
            $("#formPane").prepend(headerStr);
        }
    }

    function showNoFormMessage(){
        var messageContainer = document.createElement("div");
        messageContainer.id = 'messageDiv'
        document.getElementById('formPane').appendChild(messageContainer);
        $('#messageDiv').text('No form data available.');
        $('#messageDiv').css('text-align', 'center');
    }

    function formFilter(tab) {
        var selectedTab = typeof tab !== "undefined" ? tab : $('#DzAndClusterDialog #filterSelection').val(),
            fields = $('#DzAndClusterDialog #formPane').find('input, textarea, select');

        if(selectedTab === "basic") {
            _.forEach(fields, function (field) {
                $(field).closest('label').removeClass('non-required-field');
                if ($(field).closest('label').hasClass('advanced-field')) {
                    $(field).closest('label').addClass('non-required-field');
                }
                if($(field).closest('label').hasClass('an-deleted')){
                    $(field).hide();
                }
            });
            $('fieldset.non-required').addClass('non-required-field');
        } else if (selectedTab === "advanced"){
            _.forEach(fields, function (field) {
                $(field).closest('label').removeClass('non-required-field');
            });
            $('fieldset.non-required').removeClass('non-required-field');
        }
        GCM$.form.setLabelWidths("formPane");
    }

    function updateGlobalStandbyMode(){ 
        var globalStandbyMode = $('#globalStandbyModeToggle input').prop('checked');

        if(!globalStandbyMode){
            OPM$.sysConfig.sysConfigService.getStandbyUsername().done(function (res) {
                var html = Handlebars.templates['DzAndCluster_globalStandby'](res);
                $('body').append(html);
                VALIDATION$.validateOnInputChange($('#standbyUpdateForm'), $('#updateGlobalStandbyModeBtn'));
                $('#updateGlobalStandbyModeBtn').off('click').on('click', function(){
                    var ip = $('#standbyIpAddress').val();
                    var m2mkeys =  $('#standbyM2MKeys').val();
                    saveGlobalStandbyMode(globalStandbyMode, ip , m2mkeys)
                })
            });
        }
        else if(globalStandbyMode) {
            saveGlobalStandbyMode(globalStandbyMode, null , null)
        }
    }

    function saveGlobalStandbyMode(globalStandbyMode, ip , m2mkeys){
        var OPMMode = globalStandbyMode ? 'active' : 'standby';
        MSG$.confirm({
            statement: 'Update Confirmation',
            question: 'Are you sure you want to update Global OPM Mode to: '+ OPMMode  +'?',
            position: {my: 'center', at: 'center', of: $('body')},
            yes: function () {
                $('body').activity()
                OPM$.DzAndCluster.dzAndClusterService.saveGlobalStandbyMode(OPMMode, ip, m2mkeys).done(function(data) {
                    if(data.globalStandbyMode != null || data.globalStandbyMode != undefined){
                        $('#globalStandbyModeToggle input').prop('checked', !data.globalStandbyMode);
                        MSG$.showInfoMsg({status: 'Success', content: 'Global OPM Mode updated successfully' });
                        if(data.globalStandbyMode)
                            $('#globalStandbyModeToggle').attr('title', "Standby mode");
                        else 
                            $('#globalStandbyModeToggle').attr('title', "Active mode");

                        if($("#globalStandbyModeDlg").length > 0){
                            GCM$.common_functions.closeDialog('globalStandbyModeDlg');
                        }
                    }
                }).fail( function(err) {
                    resetToPrevGlobalStandbyMode(globalStandbyMode)
                }).always(function() {
                    $('body').activity(false);
                })
            },
            no: function() {
                resetToPrevGlobalStandbyMode(globalStandbyMode)
                if(globalStandbyMode){
                    GCM$.common_functions.closeDialog('globalStandbyModeDlg');
                }
            },
            close: function() {
                resetToPrevGlobalStandbyMode(globalStandbyMode)
            }
        });

    }
    function resetToPrevGlobalStandbyMode(globalStandbyMode){
        if(globalStandbyMode){
            $('#globalStandbyModeToggle input').prop('checked' , false)
        }
        else if(!globalStandbyMode){
            $('#globalStandbyModeToggle input').prop('checked' , true)
        }
    }

    function closeGlobalStandbyDialog(){
        $('#globalStandbyModeToggle input').prop('checked' , true)
        GCM$.common_functions.closeDialog('globalStandbyModeDlg');
    }

    return {
        openDzAndClusterDialog: openDzAndClusterDialog,
        //saveData: saveData,
        renderCreateForm: renderCreateForm,
        launchImportConfigDlg: launchImportConfigDlg,
        doImportFile: doImportFile,
        deployConfig: deployConfig,
        launchExportDialog: launchExportDialog,
        launchSaveDzClusterTpl: launchSaveDzClusterTpl,
        onDeleteTemplate: onDeleteTemplate,
        renderFormControls: renderFormControls,
        renderSavedList: renderSavedList,
        loadTree: loadTree,
        renderManagedTree: renderManagedTree,
        showNoFormMessage: showNoFormMessage,
        formFilter: formFilter,
        saveGlobalStandbyMode: saveGlobalStandbyMode,
        updateGlobalStandbyMode: updateGlobalStandbyMode,
        closeGlobalStandbyDialog: closeGlobalStandbyDialog
    };

})();