OPM$.DzAndCluster = OPM$.DzAndCluster || {};

OPM$.DzAndCluster.dzAndClusterService = (function () {
    'use strict';

    function getAllInstances() {
        return GET_JSON$('/opm/cluster/getManaged');
    }

    function getAllSaved() {
        return GET_JSON$('/opm/cluster/getSaved');
    }

    function saveGlobalStandbyMode(globalStandbyMode, ip, m2mkeys) {
        var data  = {}
        if((ip!= null || ip!=undefined) && (m2mkeys!= null || m2mkeys!=undefined)){
            data  = {
                "ip": ip,
                "m2mkeys" : m2mkeys
            }
        }
        return POST_JSON$({
            url: '/opm/systemConfig/saveGlobalMode/'+globalStandbyMode,
            data:  JSON.stringify(data)
        });
    }

    return {
        getAllInstances: getAllInstances,
        getAllSaved: getAllSaved,
        saveGlobalStandbyMode: saveGlobalStandbyMode
    };

})();