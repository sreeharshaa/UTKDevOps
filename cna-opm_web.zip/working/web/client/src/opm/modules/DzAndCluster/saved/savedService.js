OPM$.DzAndCluster = OPM$.DzAndCluster || {};
OPM$.DzAndCluster.saved = OPM$.DzAndCluster.saved || {};

OPM$.DzAndCluster.saved.savedService = (function() {

    function getSavedDz(savedDzOrClusterName){
            return GET_JSON$('/opm/deploymentzone/getCloudPlatformConfigTemplate/' + savedDzOrClusterName);
            
    }

    function getSavedCluster(savedDzOrClusterName){
        return GET_JSON$('/opm/cluster/getClusterTemplate/' + savedDzOrClusterName);
    }

    function deleteSavedDz(savedDzOrClusterName){
            return  $.ajax({
                type: "DELETE", 
                dataType: 'json', 
                contentType: 'application/json', 
                url: '/opm/deploymentzone/deleteCloudPlatformConfigTemplate/' + savedDzOrClusterName
            });
    }
    function deleteSavedCluster(savedDzOrClusterName){
            return  $.ajax({
                type: "DELETE", 
                dataType: 'json', 
                contentType: 'application/json', 
                url: '/opm/cluster/deleteClusterTemplate/' + savedDzOrClusterName
            });
    }

    function updateSavedDz(savedDzOrClusterName, jsonData, override, type){
        var override = typeof override !== "undefined" ? '?override='+override : '';
        var type = typeof type !== "undefined" ? '&type='+type : '';
        return POST_JSON$({
            url: ' /opm/deploymentzone/saveCloudPlatformConfigTemplate/'+savedDzOrClusterName+override+type,
            data:  JSON.stringify(jsonData)
        });
    }

    function updateSavedCluster(savedDzOrClusterName, jsonData, override){
        var override = typeof override !== "undefined" ? '?override='+override : '';
        return POST_JSON$({
            url: '/opm/cluster/saveClusterTemplate/'+savedDzOrClusterName+override,
            data:  JSON.stringify(jsonData)
        });
    }

    function cloneSavedDz(newSavedDzOrClusterName,jsonData, override,type){
        var override = typeof override !== "undefined" ? '?override='+override : '';
        var type = typeof type !== "undefined" ? '&type='+type : '';
        return POST_JSON$({
            url:  '/opm/deploymentzone/saveCloudPlatformConfigTemplate/'+newSavedDzOrClusterName+override+type,
            data:  JSON.stringify(jsonData)
        });
    }

    function cloneSavedCluster(newSavedDzOrClusterName, jsonData){
        return POST_JSON$({
            url:  '/opm/cluster/saveClusterTemplate/'+newSavedDzOrClusterName,
            data:  JSON.stringify(jsonData)
        });
    }



    return {
        getSavedDz : getSavedDz,
        getSavedCluster: getSavedCluster,
        deleteSavedDz: deleteSavedDz,
        deleteSavedCluster: deleteSavedCluster,
        updateSavedDz: updateSavedDz,
        updateSavedCluster: updateSavedCluster,
        cloneSavedDz: cloneSavedDz,
        cloneSavedCluster: cloneSavedCluster
    }
})();