OPM$.DzAndCluster = OPM$.DzAndCluster || {};
OPM$.DzAndCluster.dz = OPM$.DzAndCluster.dz || {};

OPM$.DzAndCluster.dz.dzService = (function() {
    'use strict';

    function getAllTypes() {
        return GET_JSON$('/opm/deploymentzone/getAllDeploymentZone');
    }

    function getDeploymentZone(type, id, template, username) {

        var template = typeof  template !== 'undefined' ? '?templateName='+template : '';

        if(typeof id !== 'undefined') {
            return GET_JSON$('/opm/deploymentzone/getDeploymentZone/' + type + '?id=' + id);
        } if (username) {
            return GET_JSON$('/opm/deploymentzone/getDeploymentZone/' + type + '?userid='+ username);
        } else {
            return GET_JSON$('/opm/deploymentzone/getDeploymentZone/' + type + template);
        }
    }

    function getAllInstances() {
        return GET_JSON$('/opm/deploymentzone/getDeploymentZoneInstances');
    }

    function saveDeploymentZone(jsonData, dzId, override) {
        if(typeof dzId === "undefined") {
            var override = typeof override === "undefined" ? "" : override
            return POST_JSON$({
                url: '/opm/deploymentzone/saveDeploymentZone'+override,
                data: JSON.stringify(jsonData)
            });
        } else {
            return PUT_JSON$({
                url: '/opm/deploymentzone/updateDeploymentZone',
                data: JSON.stringify(jsonData)
            });
        }
    }

    function deleteDz(type, id) {
      return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/deploymentzone/deleteDeploymentZone/'+id});
        //return DELETE_JSON$('/opm/deploymentzone/deleteDeploymentZone/'+id);
    }

    function saveDzTemplate(name, type,data, override) {
        var override = typeof override !== "undefined" ? '&override='+override : '';
        return POST_JSON$({
            url: '/opm/deploymentzone/saveCloudPlatformConfigTemplate/'+name+'?type='+type+override,
            data:  JSON.stringify(data)
        });
    }

    function getTemplateNames(type) {
        return GET_JSON$('/opm/deploymentzone/getCloudPlatformConfigTemplateNames?type='+type);
    }

    function deleteTemplate(templateName) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/deploymentzone/deleteCloudPlatformConfigTemplate/'+templateName});
    }

    function isInternalUse() {
        return GET_JSON$('/opm/deploymentzone/isInternalUse');
    }

    function getDeployedDz(){
        return GET_JSON$('/opm/cluster/getDeploymentZoneInstances');
    }

    return {
        getAllTypes: getAllTypes,
        getDeploymentZone: getDeploymentZone,
        saveDeploymentZone: saveDeploymentZone,
        getAllInstances: getAllInstances,
        deleteDz: deleteDz,
        saveDzTemplate: saveDzTemplate,
        getTemplateNames: getTemplateNames,
        deleteTemplate: deleteTemplate,
        isInternalUse: isInternalUse,
        getDeployedDz: getDeployedDz
    };

})();