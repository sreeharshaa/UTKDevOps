OPM$.DzAndCluster = OPM$.DzAndCluster || {};
OPM$.DzAndCluster.dz = OPM$.DzAndCluster.dz || {};

OPM$.DzAndCluster.dz.dzController = (function() {
    'use strict';
    var vueInstance = [], selectedDzId, selectedType, selectedTemplate;

    function getAllDzInstances() {
        OPM$.DzAndCluster.dzAndClusterService.getAllInstances()
            .done(function(data){
                OPM$.DzAndCluster.DzAndClusterController.loadTree(data, 'managed-tree-content', onTreeClick, 'delete');
        }).always(function(){
        });
    }

    function onAddDz() {
        var selectedType = $('#createNewForm select[name="type"]').val(),
            template = $('#templatesList').find('li.an-selected').find('a[name="templateName"]').text(),
            username;

        if (document.getElementById("userNameForDZData")) {
            console.log("called userNameForDZData");
            username = $('#userNameForDZData').val().trim();
        }

        getDeploymentZone(selectedType, undefined, template, username);
    }
    
    function dataBindDzForm(data) {
        var vueConfig = {
            el: "#formPane",
            data: data,
            methods: [{
                name: 'stringify',
                method: function () {
                    return JSON.stringify(JSON.parse(JSON.stringify(this.$data)), null, '\t'); //JSON.stringify(this.$data, null, '\t');
                }
            },{
                name: 'toggleDisplayOfChildFieldset',
                method: function (event, path) {
                    if($('form fieldset[name="'+path+'"]').css('display') === "none") {
                        $('form fieldset[name="'+path+'"]').show();
                    } else {
                        $('form fieldset[name="'+path+'"]').hide();
                    }
                    GCM$.form.setLabelWidths("formPane");
                }
            }]
        };
        vueInstance = VUE$.createInstance(vueConfig);
    }

    function getDeploymentZone(type, id, template, username) {
        $('#formPane').activity();
        $("#dzUpdateBtn").prop('disabled', true);
        OPM$.DzAndCluster.dz.dzService.getDeploymentZone(type === 'attach'? 'existing' : type, id, template, username)
            .done(function(data){
                var update = typeof id !== "undefined" ? true : false;
                $("#formPane").empty();
                if((typeof data.forms !== 'undefined' && data.forms.length == 0) || typeof data.forms === 'undefined'){
                    OPM$.DzAndCluster.DzAndClusterController.showNoFormMessage();
                }else{   
                    FORM$.createForm('formPane', data);
                    OPM$.DzAndCluster.DzAndClusterController.renderFormControls(data.formType, 'dz');
                }
                if(type === 'existing' || type === 'attach'){
                    $('#saveDzTemplateBtn').css('display', 'none');
                }
                VALIDATION$.validateOnInputChange($("#formPane"), $('#deploymentZoneLcmFormBtn button'));
                selectedType = type;
                selectedDzId = id;
                selectedTemplate = typeof template !== "undefined" ? template : '';
                // username = typeof username !== "undefined" ? username : '';
                
                $('#formPane').on('keydown', function(e){
                    var target$ = $(e.target);
                    //Prevent space key press from scrolling 
                    if(e.keyCode === GCM_KEY$.SPACE && target$.attr('role') == 'switch'){
                        e.preventDefault();
                    }
                })
                switchButtons(update);
            }).always(function (){
                $('#formPane').activity(false);
            });
    }

    function saveDeploymentZone(override) {
        var formData = FORM$.getData('formPane'); // VUE$.getDataFromApp(vueInstance);
        $('#DzAndClusterDialog').activity();
        OPM$.DzAndCluster.dz.dzService.saveDeploymentZone(formData, selectedDzId, override)
            .done(function(data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage,
                    close: function() { $('#dzDeployUpdateBtn')[0].focus(); }});

                if($('#cloudMapView').css('display') === "block"){
                    var $container = $('#cloudMapView').find('.an-cluster-container');
                    OPM$.cloudMap.cloudMapController.renderCloudMap(JSON.parse($container).attr('data-set'));
                }
                if($('#mapContainer').css('display') === "block") {
                    OPM$.cloudMap.cloudMapController.displayMap();
                }
            }).always(function () {
                $('#DzAndClusterDialog').activity(false);
        }).fail(function (data) {
            if(data.responseJSON.result === "confirm"){
                if(data.responseJSON.action === "override"){
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: data.responseJSON.errorMessage,
                        yes: function () {
                            override = '?override=true';
                            saveDeploymentZone(override)
                        }
                    })
                }
            }
        });
    }

    function onTreeClick(e) {
        var target = $(e.target);
        e.stopPropagation();
        if(target.hasClass('an-icon-delete') || (target.hasClass('an-button') && $(target.children()[0]).hasClass('an-icon-delete'))){
            onDeleteDz(target.closest('li'));
        } else  if(target.closest("li").hasClass('leaf') && !target.closest("li").hasClass('non-clickable')){
            getDeploymentZone(target.closest('li').attr('data-type'), target.closest('li').attr('data-id'));
            target.closest('ul.an-tree').find('li.an-selected').removeClass('an-selected');
            target.closest('li').addClass('an-selected');
        }
    }

    function onDeleteDz(dzListitem){
        var type = dzListitem.attr('data-type');
        var id = dzListitem.attr('data-id');

        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete this deployment zone?',
            position: {my: 'left top', at: 'right bottom', of: $(event.target)},
            yes: function () {
                $('#DzAndClusterDialog').activity();
                $('#DzAndClusterDialog').addClass('an-selector-loading');
                $('#DzAndClusterDialog').attr('aria-busy', 'true');
                $('#DzAndClusterDialog')[0].focus();
                OPM$.DzAndCluster.dz.dzService.deleteDz(type, id)
                    .done(function (data) {
                        MSG$.showInfoMsg({
                            status: 'Success', content: data.successMessage,
                            close: function () { $('#managed-tree-content :tabbable')[0].focus(); }});
                        if (selectedDzId === id) {
                            $('#formPane').empty();
                        }
                        if ($('#cloudMapView').css('display') === "block") {
                            $("#logoContainer").show();
                            $("#cloudMapView, #mapContainer").hide();
                        }
                }).fail(function (data) {
                    $('#DzAndClusterDialog').activity(false);
                    getAllDzInstances();
                    if(selectedDzId === id){
                        $('#formPane').empty();
                    }
                    MSG$.showErrorMsg({status: 'Error', content: data.responseJSON.errorMessage,
                        close: function () { $('#managed-tree-content :tabbable')[0].focus(); }});
                }).always(function() {
                    $('#DzAndClusterDialog').activity(false);
                    $('#DzAndClusterDialog').removeClass('an-selector-loading');
                    $('#DzAndClusterDialog').removeAttr('aria-busy');
                });
            },
            close : function () {
                dzListitem.find('button')[0].focus();
            }
        });
    }

    function launchSaveTemplate() {
        var html = Handlebars.templates['DzAndCluster_saveTemplate'](selectedTemplate);
        if ($('#saveTemplateDlg').length < 1) {
            $('body').append(html);

            $('#saveTemplateDlg').draggable({
                handle: 'header'
            }).position({
                my: 'center',
                at: 'center',
                of: 'body'
            });

            VALIDATION$.validateOnInputChange($("#saveTemplateDlg"), $('#addBtn'));
            $('#addBtn').off().on('click', function () {
                var name = $('#saveTemplateDlg input[name="name"]').val(),
                    data = FORM$.getData('formPane');
                saveDzTemplate(name, data);
            });

            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#saveTemplateDlg'));
            $('#saveTemplateDlg :tabbable')[0].focus();
            $('#saveTemplateDlg').on('dialogClose', function () {
                $('#saveDzTemplateBtn')[0].focus();
            });
        }
    }

    function saveDzTemplate(name, data, override) {

        if(templateNameIsValid(name)) {
            OPM$.DzAndCluster.dz.dzService.saveDzTemplate(name, selectedType, data, override)
                .done(function (data) {
                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage,
                        close: function() {
                            $('#saveDzTemplateBtn')[0].focus();
                            selectedTemplate = name;
                            GCM$.common_functions.closeDialog('saveTemplateDlg');
                        }
                    });
                }).fail(function (res) {
                if (res.responseJSON.result === "confirm") {
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: res.responseJSON.errorMessage,
                        yes: function () {
                            saveDzTemplate(name, data, true);
                        }
                    });

                }
            });
        } else {
            MSG$.showErrorMsg({status: 'Error', content: 'Invalid Template Name!! No spaces are allowed.',
                close: function() { $('#saveTemplateDlg')[0].focus(); }});
        }

    }

    function templateNameIsValid(name) {
        if(name.indexOf(" ") > -1){
            return false;
        } else {
            return true;
        }
    }

    function onSelectType() {
        var selectedType = $('#createNewForm select[name="type"]').val();
        $("#createNewForm").activity();
        $("#selectTemplateBtn").prop("disabled", false);


        OPM$.DzAndCluster.dz.dzService.getTemplateNames(selectedType)
            .done(function (data) {
                data.templateNames = data.cloudPlatformConfigTemplateNames;
                data.type = selectedType;

                var html = Handlebars.templates['DzAndCluster_dz_dzTemplates'](data);
                $('#templates').empty().append(html);

                var radios = document.querySelectorAll('input[type=radio][name="dzDataImport"]');

                function changeHandler(event) {
                    $("#templatesList").find("li").removeClass("an-selected");
                    $("#addDzTemplatesLabel").text("Select...");
                    $("#userNameForDZData").val("");

                    if ( this.value === 'none' ) {
                        $("#userNameForDZData").prop("disabled", true);
                        $("#selectTemplateBtn").prop("disabled", true);
                    } else if ( this.value === 'template' ) {
                        $("#userNameForDZData").prop("disabled", true);
                        $("#selectTemplateBtn").prop("disabled", false);
                    } else if ( this.value === 'userData' ) {
                        $("#userNameForDZData").prop("disabled", false);
                        $("#selectTemplateBtn").prop("disabled", true);
                    }
                }

                Array.prototype.forEach.call(radios, function(radio) {
                    radio.addEventListener('change', changeHandler);
                });

                VALIDATION$.validateOnInputChange($('#createNewForm'), $('#addDzBtn'), undefined, undefined, undefined, true);

                $('#selectTemplateBtn').off('keyup');
                $('#templatesList').off('keyup');

                GCM$.accessibility.menuAccessibility.makeMenuKeyNav($('#templatesList'), $('#selectTemplateBtn'));

                $('#templatesList').find('li').on('click', function (e) {
                    var value = $(e.target).text();
                    $('#selectTemplateBtn span').text(value);
                    $(e.target).closest('ul').find('li.an-selected').removeClass('an-selected');
                    $(e.target).closest('li').addClass('an-selected');
                    $('#templatesList').slideUp("normal", function () {
                        $('#templatesList').hide();
                    });
                    $('#selectTemplateBtn')[0].focus();
                });

                $('#templatesList').find('li').on('keyup', function (e) {
                    if (e.keyCode === GCM_KEY$.RIGHT_ARROW) {
                        $(e.target).find('button')[0].focus();
                    }
                });

                $('#templatesList').find('li button').on('keyup', function (e) {
                    if (e.keyCode === GCM_KEY$.LEFT_ARROW) {
                        $(e.target).closest('li')[0].focus();
                    }
                });

            }).always(function() {
            $("#createNewForm").activity(false);
        });
    }

        function pickTemplate(e) {
            e.stopPropagation();
            if($('#templatesList').css('display') === "none") {
                $('#templatesList').show().slideDown().position({
                    my: "right top",
                    at: "right bottom",
                    of: '#selectTemplateBtn',
                    collision: "flipfit"
                });
            } else {
                $('#templatesList').slideUp("normal", function () {
                    $('#templatesList').hide();
                });
            }
        }

        function onDeleteTemplate(e) {
            var target = $(e.target),
                templateName = $(target).closest('li').find('a[name="templateName"]').text();
            e.stopPropagation();
            MSG$.confirm({
                statement: 'Delete Confirmation',
                question: 'Are you sure you want to delete the template '+ templateName+'?',
                position: {my: 'left top', at: 'right bottom', of: $(e.target)},
                yes: function () {
                    $('#selectTemplateBtn').activity();
                    OPM$.DzAndCluster.dz.dzService.deleteTemplate(templateName)
                        .done(function () {
                            onSelectType();
                        }).always(function () {
                        $('#selectTemplateBtn').activity(false);
                    })
                },
                close: function () {
                    $('#selectTemplateBtn')[0].focus();
                }
            });
        }

    function switchButtons(update) {
        if(update){
            $('#dzDeployUpdateBtn').text("Update");
        } else {
            $('#dzDeployUpdateBtn').text("Deploy");
        }
    }

    return {
        getAllDzInstances: getAllDzInstances,
        onAddDz: onAddDz,
        onDeleteDz: onDeleteDz,
        getDeploymentZone: getDeploymentZone,
        saveDeploymentZone: saveDeploymentZone,
        onTreeClick: onTreeClick,
        launchSaveTemplate: launchSaveTemplate,
        onSelectType: onSelectType,
        pickTemplate: pickTemplate,
        onDeleteTemplate: onDeleteTemplate,
    };

})();