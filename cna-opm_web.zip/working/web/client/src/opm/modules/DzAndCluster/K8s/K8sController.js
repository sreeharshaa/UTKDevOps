OPM$.DzAndCluster = OPM$.DzAndCluster || {};
OPM$.DzAndCluster.K8s = OPM$.DzAndCluster.K8s || {};

OPM$.DzAndCluster.K8s.K8sController = (function() {
    'use strict';
    var vueK8Instance = {}, selectedClusterId, selectedDzId, selectedClusterName, selectedType, selectedTemplate, k8ClusterState, isInternalUse;

    function getK8ClusterInstances() {

        OPM$.DzAndCluster.dzAndClusterService.getAllInstances()
            .done(function(data){
                OPM$.DzAndCluster.DzAndClusterController.loadTree(data, 'managed-tree-content', onTreeClick, 'delete');
            }).always(function(){
        });
    }

    function onSelectType() {
        var selectedDzVal = JSON.parse($('#createNewForm select[name="deploymentZone"]').val()),
            data = {"templateNames" : [], isInternalUse: false, type: "", dzSelected : 0}
        $("#createNewForm").activity();
        $("#selectTemplateBtn").prop("disabled", false);
                OPM$.DzAndCluster.K8s.K8Service.getTemplateNames(selectedDzVal.type === 'attach'? 'existing' : selectedDzVal.type)
                    .done(function (tplData) {


                        data.templateNames = tplData.clusterTemplateNames;
                        data.isInternalUse = isInternalUse;
                        data.type = selectedDzVal.type;
                        data.dzSelected = selectedDzVal.id; //This is to set user selected DZ value after deleting template, so user doesn't have to re-select DZ.

                        // console.log(JSON.stringify(data));

                        if(selectedDzVal.type === "existing" || selectedDzVal.type === "attach"){
                            data.existing = true;
                            data.attachType = $('input[name="cluster-attach-type"]:checked').val(); //$('#createNewForm select[name="attach_type"]').val();
                            data.globalStandbyMode =  $('#globalStandbyModeToggle input').prop('checked') ? 'Active' : 'Standby';
                        }
                        var html = Handlebars.templates['DzAndCluster_K8s_dzSelectList'](data);
                        $('#selectedDz').empty().append(html);

                        var radios = document.querySelectorAll('input[type=radio][name="clusterDataImport"]');

                        function changeHandler(event) {
                            $("#templatesList").find("li").removeClass("an-selected");
                            $("#selectTemplateBtn").find("span").text("Select...");
                            $("#userNameForClusterData").val("");

                            if ( this.value === 'none' ) {
                                $("#userNameForClusterData").prop("disabled", true);
                                $("#selectTemplateBtn").prop("disabled", true);
                            } else if ( this.value === 'template' ) {
                                $("#userNameForClusterData").prop("disabled", true);
                                $("#selectTemplateBtn").prop("disabled", false);
                            } else if ( this.value === 'userData' ) {
                                $("#userNameForClusterData").prop("disabled", false);
                                $("#selectTemplateBtn").prop("disabled", true);
                            }
                        }

                        Array.prototype.forEach.call(radios, function(radio) {
                            radio.addEventListener('change', changeHandler);
                        });


                        GCM$.common_functions.inputFile();
                        VALIDATION$.validateOnInputChange($('#createNewForm'), $('#addClusterBtn'), undefined, undefined, undefined, true);
                        $('#selectTemplateBtn').off('keyup');
                        $('#templatesList').off('keyup');
                        GCM$.accessibility.menuAccessibility.makeMenuKeyNav($('#templatesList'), $('#selectTemplateBtn'));

                        $('#templatesList').find('li').on('click', function(e) {
                            var value = $(e.target).text();
                            $('#selectTemplateBtn span').text(value);
                            $(e.target).closest('ul').find('li.an-selected').removeClass('an-selected');
                            $(e.target).closest('li').addClass('an-selected');
                            $('#templatesList').slideUp("normal", function () {
                                $('#templatesList').hide();
                            });
                            $('#selectTemplateBtn')[0].focus();
                        });

                        $('#templatesList').find('li').on('keyup', function(e) {
                            if (e.keyCode === GCM_KEY$.RIGHT_ARROW) {
                                $(e.target).find('button')[0].focus();
                            }
                        });

                        $('#templatesList').find('li button').on('keyup', function(e) {
                            if (e.keyCode === GCM_KEY$.LEFT_ARROW) {
                                $(e.target).closest('li')[0].focus();
                            }
                        });
            }).always(function() {
                $("#createNewForm").activity(false);
        });
    }

    function onAddCluster() {
        var dzId = JSON.parse($('#createNewForm select[name="deploymentZone"]').val()).id,
            //selectedTemplate = $('#selectedDz select[name="template"]').val();
            template = $('#templatesList').find('li.an-selected').find('a[name="templateName"]').text(),
            username,
            allRowsStaged = true,
            type = JSON.parse($('#createNewForm select[name="deploymentZone"]').val()).type;

        if (document.getElementById("userNameForClusterData")) {
            username = $('#userNameForClusterData').val().trim();
        }
        if($("#opmModeToggleParent").css('display') != "none")
            var OPMMode = $('#globalStandbyModeToggle input').prop('checked') ? 'active' : 'standby';
        //if(type === "existing" || type === "AWS"){
            if(type === "attach" || type === "existing"){
            var dzName = JSON.parse($('#createNewForm select[name="deploymentZone"]').val()).name
            var attachType = $('input[name="cluster-attach-type"]:checked').val(); //$("#createNewForm select[name='attach_type']").val();
            if(dzName.toLowerCase() === 'selfopm'){
                MSG$.showErrorMsg({status: 'Error', content: 'Attaching an existing cluster to SelfOPM deployment zone is not allowed.'});
            } else{
                if(attachType != "azure_attach" && ($("#opmModeToggleParent").css('display') != "none")){
                    MSG$.confirm({
                        statement: 'Add Cluster Confirmation',
                        question: 'Cluster will be in '+ OPMMode  +' attach mode as Global OPM Mode is set to ' + OPMMode +'. Proceed with adding attach cluster?',
                        position: {my: 'center', at: 'center', of: $('#DzAndClusterDialog')},
                        yes: function() {
                            renderAttachClusterForm(dzId, attachType);
                        }
                    });
                }
                else {
                    renderAttachClusterForm(dzId, attachType); 
                }
            }   
        } else {
            getKubernetesCluster(dzId, undefined, undefined, template, type, allRowsStaged, username);
        }
    }

    function onTreeClick(e) {
        var target = $(e.target);
        e.stopPropagation();
        if(target.hasClass('an-icon-delete') || (target.hasClass('an-button') && $(target.children()[0]).hasClass('an-icon-delete'))){
            onDeleteCluster(target, target.closest('li').parent().closest('li').attr('data-id'), target.closest('li').attr('data-id'), $('#DzAndClusterDialog'), target.closest('li'));
        } else  if(target.closest("li").attr('data-id') && target.closest("li").hasClass('leaf') && !target.closest("li").hasClass('non-clickable')){
            getKubernetesCluster(target.closest('li').parent().closest('li').attr('data-id'), target.closest('li').attr('data-id'),target.closest('li').attr('data-name'),undefined, target.closest('li').parent().closest('li').attr('data-type'));
            target.closest('ul.an-tree').find('li.an-selected').removeClass('an-selected');
            target.closest('li').addClass('an-selected');
        }
    }

    function getKubernetesCluster(dzId, clusterId, clusterName, template, type, allRowsStaged, username) {
        var allRowsStagedVal = allRowsStaged;
        $('#formPane').activity();
        OPM$.DzAndCluster.K8s.K8Service.getKubernetesCluster(dzId, clusterId, template, username)
            .done(function(data){

                // During create, any "seeded" nodes are staged and not yet created. They, therefore, can be removed before the create is committed by the user.
                data.allRowsStaged = allRowsStagedVal;
                formPostProcessing(dzId, clusterId, clusterName,template, type, data);

                var html = Handlebars.templates['sysConfig_featureFlagWarning'](selectedTemplate);
                if (data.featureFlag === true) {
                    $('#formPane').prepend(html);
                }

            }).always(function (){ 
                $('#formPane').activity(false);
            });
    }

    function formPostProcessing(dzId, clusterId, clusterName,template, type, data) {
        var update = typeof clusterId !== "undefined" ? true : false;

        var config = {
            cloneFields: OPM$.DzAndCluster.K8s.K8sController.cloneFields,
            deleteFields: OPM$.DzAndCluster.K8s.K8sController.deleteSelectedFields
        };
        $("#formPane").empty();
        if((typeof data.forms !== 'undefined' && data.forms.length == 0) || typeof data.forms === 'undefined'){
            OPM$.DzAndCluster.DzAndClusterController.showNoFormMessage()
        }else{ 
            FORM$.createForm('formPane', data, undefined, config);
            OPM$.DzAndCluster.DzAndClusterController.renderFormControls(data.formType, 'cluster', data.platformType);
            k8ClusterState = $('#formPane formBuilder select[name="opm_dr_standby"]').val();
            if(data.platformType === 'existing' || type === 'attach'){
                $('#saveTemplateBtn').css('display', 'none');
                $('#exportTemplateBtn').css('display', 'none');
            }
            managedModeChange(type)
        }

        if(type !== "existing" && type !=="attach" && type !== "AWS") {
            VALIDATION$.validateOnInputChange($("#formPane"), $('#K8sLcmFormBtn button'));
        } else {
            VALIDATION$.validateOnInputChange($("#formPane"), $('.an-k8-specific button'));
        }
        $('#formPane').on('keydown', function(e){
            //Prevent space key press from scrolling 
            var target$ = $(e.target);
            if(e.keyCode === GCM_KEY$.SPACE && target$.attr('role') == 'switch'){
                e.preventDefault();
            }
        })
        selectedClusterId = clusterId; selectedDzId = dzId; selectedClusterName = clusterName;
        selectedTemplate = typeof template !== "undefined" ? template : '';
        selectedType = type;
        switchButtons(update);
        $("#exportConfigBtn").prop('disabled', false);
        if(data.platformType === 'openstack'){
            OPM$.DzAndCluster.DzAndClusterController.formFilter('basic');
        }
    }
    //Function to support form validation on change of 'managed mode' field. 
    //Currently form validation is done on 'focusout' which does not satisy form validation crteria in 'managed mode' value change case
    function managedModeChange(type){
        $('#formPane formBuilder select[name="opm_dr_standby"]').on('change' , function(e){
            //setTimeout to pass the updated form after select options have been changed
            setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                if(VALIDATION$.isValid($("#formPane"), true)){
                    managedModeChangeHelper(type,false)
                }
                else {
                    managedModeChangeHelper(type,true)
                }
            }, 100)
        })
    }

    //Helper function for form validation on managed mode change to disable the action buttons in cluster view
    function managedModeChangeHelper(type,bool){
        if((type !== "existing" && type !=="attach") && type !== "AWS") {
            $('#K8sLcmFormBtn button').prop("disabled", bool)
        } else {
            $('.an-k8-specific button').prop("disabled", bool)
        }
    }

    function cloneFields(fieldset, index) {
        var fieldsetParent;
        if($(document.activeElement).parent().children().length>1)
            fieldsetParent = $(document.activeElement).closest('fieldset.an-extensible-fragment').parent();
        else
            fieldsetParent = $(document.activeElement).closest('fieldset');

        // Check if max limit has reached
        if(fieldset.rows.length >= fieldset.max){
            MSG$.showInfoMsg({content: 'Only maximum of "' + fieldset.max + '" are allowed.',
            close: function() { $('#DzAndClusterDialog')[0].focus(); } });
            return;
        }
        var clone = _.cloneDeep(JSON.parse(JSON.stringify(fieldset.rows[index])));

        // This row has not been saved to the back-end, so it is staged and can be removed by the user before saving.
        clone.stagedRow = true;

        if(!fieldset.useOriginalData) {
            _.forEach(clone.fields, function (field) {
                field.value = '';
                setDefaultValuesToEachField(field);
            });
        }
        clone.updated = true;
        fieldset.rows.splice(index+1,0,clone);
        
        // Scroll to newly appended "row"
        document.activeElement.scrollIntoView();

        //set focus to newly added fieldset first input
        setFocusToNewField(fieldsetParent, index);
        return fieldset;
    }

    function setFocusToNewField(fieldsetParent,index){
        setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
            var newFieldset = $(fieldsetParent).children('fieldset.an-extensible-fragment')[index+1];
            $(newFieldset).find('input').first().focus();
            if ($('#formHeaderPane #filterSelection').length == 1){
                var filterVal = $('#formHeaderPane #filterSelection').val();
                OPM$.DzAndCluster.DzAndClusterController.formFilter(filterVal);
            }
        },100)
    }

    function setDefaultValuesToEachField(field) {
        _.forEach(field.fieldsets, function (fieldset) {
            _.forEach(fieldset.rows, function (row) {
                _.forEach(row.fields, function (field2) {
                    field2.value = field2.defaultValue;
                    setDefaultValuesToEachField(field2);
                })
            })
        })
    }

    function deleteSelectedFields(event, rows, index, allRowsStaged) {

        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete this set of fields?',
            position: {my: 'left top', at: 'right bottom', of: $(event.target)},
            yes: function () {
                var deletedRow = rows[index];
                var nodeIp;

                if(deletedRow.stagedRow || allRowsStaged){
                    rows.splice(index, 1);
                } else {
                    _.forEach(deletedRow.fields, function (field) {
                        if (field.name === "k8_node_ip") {
                            nodeIp = field.value;
                            $('#formPane').activity();

                            // DELETE previously created node.
                            OPM$.DzAndCluster.K8s.K8Service.deleteNode(selectedDzId, selectedClusterId, nodeIp)
                                .done(function () {
                                    MSG$.showInfoMsg({status: 'Success', content: "Node deleted successfully",
                                        close: function() { event.target.focus(); }});
                                    //getKubernetesCluster(selectedDzId, selectedClusterId);
                                }).always(function () {
                                $('#formPane').activity(false);
                            });
                        } 
                    });
                    rows.splice(index, 1);
                }
            },
            close: function() {
                event.target.focus();
            }
        });
        return rows;
    }

    function saveKubernetesCluster(overrideInfo) {
        var formData = FORM$.getData('formPane'); //VUE$.getDataFromApp(vueK8Instance);

        $('#DzAndClusterDialog').activity();
        $('#DzAndClusterDialog').addClass('an-selector-loading');
        OPM$.DzAndCluster.K8s.K8Service.saveKubernetesCluster(formData, selectedClusterId, overrideInfo)
            .done(function (data) {
                    MSG$.showInfoMsg({
                        status: 'Success',
                        content: data.successMessage,
                        close: function() {
                            $('#createNewBtn').focus();
                        }
                    });

                    var returnedClusterId = ((typeof data.data !== "undefined" && data.data !== null) 
                    && typeof data.data.id !== "undefined") ? data.data.id : selectedClusterId; 
                    
                    getKubernetesCluster(selectedDzId, returnedClusterId);

                    if ($('#cloudMapView').css('display') === "block") {
                        var $container = $('#cloudMapView').find('.an-cluster-container');
                        OPM$.cloudMap.cloudMapController.renderCloudMap(JSON.parse($container.attr('data-set')));
                    }
            }).fail(function (res) {
                if (res.responseJSON.result === "confirm") {
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: res.responseJSON.errorMessage,
                        yes: function () {
                            var order = res.responseJSON.order,
                                urlStr = "";
                            if(order === 1){
                                urlStr = "?override1=true"
                            } else if(order > 1) {
                                urlStr = "?"+res.responseJSON.additionalData+"&override"+order+"=true"
                            }
                            saveKubernetesCluster(urlStr);
                        }
                    });
                }
            }).always(function () {
                $('#DzAndClusterDialog').activity(false);
                $('#DzAndClusterDialog').removeClass('an-selector-loading');
        });
    }


    function checkStateAndSaveCluster(formType){
        var formData = FORM$.getData('formPane'),
        standbyMode = $('#formPane formBuilder select[name="opm_dr_standby"]').val();
        //Create cluster prompts
        if(formType === 'addCluster'){
            if(standbyMode === 'standby'){
                MSG$.confirm({
                    statement: 'Create Confirmation',
                    question: 'Active cluster is already created and this action only creates a reference to the active cluster for disaster recovery. Do you want to proceed?',
                    position: {my: 'center', at: 'center', of: 'body'},
                    yes: function () {
                        saveKubernetesCluster();
                    }
                });
            }else{
                MSG$.confirm({
                    statement: 'Create Confirmation',
                    question: 'Active cluster creation will be attempted. Do you want to proceed?',
                    position: {my: 'center', at: 'center', of: 'body'},
                    yes: function () {
                        saveKubernetesCluster();
                    }
                });
            }
        }
        //Managed cluster prompts
        else if(formType === 'managedCluster'){
            if(standbyMode === 'standby'){
                // Mode: when cluster is switched from active to standby 
                 if(k8ClusterState !== standbyMode){
                    MSG$.confirm({
                        statement: 'Update Confirmation',
                        question: 'Cluster cannot be managed in standby mode. Do you want to proceed?',
                        position: {my: 'center', at: 'center', of: 'body'},
                        yes: function () {
                            saveKubernetesCluster();
                        }
                    });
                }
                //Mode: when cluster is is already in standby 
                else {
                    MSG$.showErrorMsg({status: 'Error', content: 'Cannot update cluster values in standby mode'});
                }
            }else{
                // Mode: when cluster is switched from standby to active
                if(k8ClusterState !== standbyMode){
                    MSG$.confirm({
                    statement: 'Update Confirmation',
                    question: 'If standby mode is switched to active, changes to current active OPM will not be synced. Do you want to proceed?',
                    position: {my: 'center', at: 'center', of: 'body'},
                    yes: function () {
                        saveKubernetesCluster();
                    }
                 });
                }
                // Mode: when cluster is already in active
                else {
                    saveKubernetesCluster();
                }
            }
        }
        
    }

    function onDeleteCluster(target, dzId, clusterId, selector, K8Treeitem) {

        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete this cluster?',
            challenge: true,
            position: {my: 'left top', at: 'right bottom', of: target},
            yes: function () {
                if(target.offsetParent()[0].id === "DzAndClusterDialog") {
                    $('#DzAndClusterDialog').activity();
                    $('#DzAndClusterDialog').addClass('an-selector-loading');
                    $('#DzAndClusterDialog').attr('aria-busy', 'true');
                    $('#DzAndClusterDialog')[0].focus();
                }
                else{
                    $('#cloudMapView').activity()
                }

                OPM$.DzAndCluster.K8s.K8Service.deleteCluster(dzId, clusterId)
                    .done(function (data) {
                        MSG$.showInfoMsg({status: 'Success', content: data.successMessage})
                        if (selectedClusterId === clusterId) {
                            $('#formPane').empty();
                        }

                        if ($('#cloudMapView').css('display') === "block") {
                            var $container = $('#cloudMapView').find('.an-cluster-container');
                            OPM$.cloudMap.cloudMapController.renderCloudMap(JSON.parse($container.attr('data-set')));
                        } else if ($('#mapContainer').css('display') === "block") {
                            OPM$.cloudMap.cloudMapController.displayMap();
                        }
                        $(".an-k8-specific button").prop('disabled', true);
                        $("#K8sUpdateBtn").prop('disabled', true);
                }).always(function(){
                    if ($('#cloudMapView').css('display') === "block") {
                        $('#cloudMapView').activity(false);
                    }
                    else{
                        $('#DzAndClusterDialog').activity(false);
                        $('#DzAndClusterDialog').removeClass('an-selector-loading');
                        $('#DzAndClusterDialog').removeAttr('aria-busy');
                    }
                }).fail(function (data) {
                        MSG$.showErrorMsg({status: 'Error', content: data.responseJSON.errorMessage})
                });
            },
            close: function() {
                if(K8Treeitem !== undefined && K8Treeitem !== null && K8Treeitem !== "") {
                    K8Treeitem.find('button')[0].focus();
                } else {
                    $(target).closest('.an-cluster').find('h2 i').focus();
                }
            }
        });
    }

    function switchButtons(update) {
        if(update){
            $('#K8sCreateUpdateBtn').text("Update");
        } else {
            $('#K8sTemplatesLabel').text("Create");
        }

        // if(selectedType !== "openstack"){
        //     $("#showStatusBtn").prop('disabled', true);
        // }
    }

    function renderAttachClusterForm(dzId, attachType) {
            $('#createNewForm').activity();
            if(attachType === "azure_attach"){
                var importFileData = new FormData($('#clusterConfigImportForm')[0]);
                var createImagePullSecret = false;
                createImagePullSecret=$("#azAttachImgPullSecretsToggle input").prop('checked');
                $.ajax({
                    url: '/opm/cluster/'+dzId+'/attachClusterViaFile?attachType='+attachType+'&createImagePullSecret='+createImagePullSecret,
                    data: importFileData, 
                    cache: false,
                    contentType: false,
                    processData: false,
                    type: 'POST',
                    success: function (data) {
                        $('#createNewForm').activity(false);
                        MSG$.showInfoMsg({
                            status: 'Success',
                            content: data.successMessage,
                            close: function() {
                                $('#formPane :tabbable')[0].focus();
                            }
                        });
                        OPM$.DzAndCluster.DzAndClusterController.renderManagedTree();
                        if ($('#cloudMapView').css('display') === "block") {
                            var $container = $('#cloudMapView').find('.an-cluster-container');
                            OPM$.cloudMap.cloudMapController.renderCloudMap(JSON.parse($container.attr('data-set')));
                        } else if ($('#mapContainer').css('display') === "block") {
                            OPM$.cloudMap.cloudMapController.displayMap();
                        }
                    },
                    error: function (res) {
                        MSG$.showErrorMsg({status: 'Error', content: res.responseJSON.errorMessage, close: function() {
                                $('#addClusterBtn')[0].focus();
                            }
                        });
                        $('#createNewForm').activity(false);
                    }
                });
        }
        else {
            var formData = {
                attach_type: "",
                dzId: "",
                ip: "",
                m2mkeys: "",
                createImagePullSecret: false
            };
            formData.attach_type = attachType;
            formData.dzId = dzId;
            formData.ip = $('#attachIpAddress').val();
            formData.username = $('#attachUsername').val();
            formData.m2mkeys = $('#attachM2MKeys').val();
            formData.createImagePullSecret = $("#attachImgPullSecretsToggle input").prop('checked');
            OPM$.DzAndCluster.K8s.K8Service.attachExistingCluster(dzId,formData).done(function (data) {
                    $('#createNewForm').activity(false);
                    MSG$.showInfoMsg({
                        status: 'Success',
                        content: data.successMessage,
                        close: function() {
                            $('#formPane :tabbable')[0].focus();
                        }
                    });
                    OPM$.DzAndCluster.DzAndClusterController.renderManagedTree();
                    if ($('#cloudMapView').css('display') === "block") {
                        var $container = $('#cloudMapView').find('.an-cluster-container');
                        OPM$.cloudMap.cloudMapController.renderCloudMap(JSON.parse($container.attr('data-set')));
                    } else if ($('#mapContainer').css('display') === "block") {
                        OPM$.cloudMap.cloudMapController.displayMap();
                    }
                }).fail(function(res){
                        $('#addClusterBtn')[0].focus();  
                        $('#createNewForm').activity(false);
                });
        }
    }

    function pickTemplate(e) {
        e.stopPropagation(); e.preventDefault();
        if($('#templatesList').css('display') === "none") {
            $('#templatesList').show().slideDown().position({
                my: "right top",
                at: "right bottom",
                of: '#selectTemplateBtn',
                collision: "flipfit"
            });
        } else {
            $('#templatesList').slideUp("normal", function () {
                $('#templatesList').hide();
            });
        }
    }

    function onDeleteTemplate(e) {
        var target = $(e.target),
            templateName = $(target).closest('li').find('a[name="templateName"]').text();
        e.stopPropagation();
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete the template '+ templateName+'?',
            position: {my: 'left top', at: 'right bottom', of: $(e.target)},
            yes: function () {
                $('#selectTemplateBtn').activity();
                OPM$.DzAndCluster.K8s.K8Service.deleteTemplate(templateName)
                    .done(function () {
                        onSelectType();
                    }).always(function () {
                    $('#selectTemplateBtn').activity(false);
                })
            },
            close: function() {
                $('#selectTemplateBtn')[0].focus();
            }
        });
    }

    function launchSaveTemplate() {
        var html = Handlebars.templates['DzAndCluster_saveTemplate'](selectedTemplate);
        if (!($('#saveTemplateDlg').is(':visible'))) {
            $('body').append(html);

            $('#saveTemplateDlg').draggable({
                handle: 'header'
            }).position({
                my: 'center',
                at: 'center',
                of: 'body'
            });

            VALIDATION$.validateOnInputChange($("#saveTemplateDlg"), $('#addBtn'));
            $('#addBtn').off().on('click', function () {
                var name = $('#saveTemplateDlg input[name="name"]').val(),
                    data = FORM$.getData('formPane');
                saveK8Template(name, data);
            });

            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#saveTemplateDlg'));
            $('#saveTemplateDlg :tabbable').first()[0].focus();
            $('#saveTemplateDlg').on('dialogClose', function () {
                $('#saveTemplateBtn')[0].focus();
            });
        }
    }

    function saveK8Template(name, data, override) {

        if(templateNameIsValid(name)) {
            OPM$.DzAndCluster.K8s.K8Service.saveK8Template(name, data, override)
                .done(function (data) {
                    selectedTemplate = name;
                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage,
                        close: function() {
                            GCM$.common_functions.closeDialog('saveTemplateDlg');
                        }
                    });
                }).fail(function (res) {
                    if (res.responseJSON.result === "confirm") {
                        MSG$.confirm({
                            statement: 'Confirmation',
                            question: res.responseJSON.errorMessage,
                            yes: function () {
                                saveK8Template(name, data, true);
                            }
                        });
                    }
            });
        } else {
            MSG$.showErrorMsg({status: 'Error', content: 'Invalid Template Name!! No spaces are allowed.',
                close: function() { $('#saveTemplateDlg')[0].focus(); }});
        }

    }

    function templateNameIsValid(name) {
        if(name.indexOf(" ") > -1){
            return false;
        } else {
            return true;
        }
    }

    function showStatus() {
        var el$ = $("#managed-tree-content").find("li.an-selected"),
            dzId = $(el$).closest('.branch').attr('data-id'),
            dzName = $(el$).closest('.branch').attr('data-name'),
            clusterId = $(el$).attr('data-id'),
            clusterName = $(el$).attr('data-name');

        OPM$.cloudMap.cloudMapController.showClusterStatus(undefined, dzId, clusterId, dzName, clusterName);
    }

    function onSelectClusterDzId(e){
        var selectedClusterDzVal = JSON.parse($(e.target).closest('select').val());
        if(selectedClusterDzVal.type === 'existing' || selectedClusterDzVal.type === 'attach'){
            $('#selectAttachTypes').show();
            $('#selectedDz').empty()
            $('input[name="cluster-attach-type"]:checked').prop('checked',false)
        }
        else{
            $('#selectAttachTypes').hide();
            if(selectedClusterDzVal.type === 'openstack'){
            }
            else if(selectedClusterDzVal.type === 'azure'){
            }
            onSelectType();
        } 
        

    }

    function renderNewClusterForm(){
        OPM$.DzAndCluster.dz.dzService.getDeployedDz()
            .done(function (data) {
                isInternalUse = data.isInternalUse;
                OPM$.DzAndCluster.K8s.K8Service.getAllAttachTypes()
                    .done(function (attachData) {
                        data.attachTypes = attachData.attachTypes;
                        var html = Handlebars.templates['DzAndCluster_K8s_createCluster'](data);
                        $('#formPane').empty().append(html);
                        $('#createNewForm :tabbable')[0].focus();
                        OPM$.DzAndCluster.DzAndClusterController.renderFormControls("newCluster");
                    });
            });
    }

    function onSelectAttachType(e){
        var attachTypeVal = $('input[name="cluster-attach-type"]:checked').val();
        console.log(attachTypeVal)
        onSelectType();
    }

    return {
        getK8ClusterInstances: getK8ClusterInstances,
        getKubernetesCluster: getKubernetesCluster,
        onAddCluster: onAddCluster,
        onSelectType: onSelectType,
        onTreeClick: onTreeClick,
        saveKubernetesCluster: saveKubernetesCluster,
        checkStateAndSaveCluster: checkStateAndSaveCluster,
        onDeleteCluster: onDeleteCluster,
        switchButtons: switchButtons,
        renderAttachClusterForm: renderAttachClusterForm,
        pickTemplate: pickTemplate,
        launchSaveTemplate: launchSaveTemplate,
        deleteSelectedFields: deleteSelectedFields,
        cloneFields: cloneFields,
        showStatus: showStatus,
        onDeleteTemplate: onDeleteTemplate,
        onSelectClusterDzId: onSelectClusterDzId,
        renderNewClusterForm: renderNewClusterForm,
        onSelectAttachType: onSelectAttachType
    };

})();