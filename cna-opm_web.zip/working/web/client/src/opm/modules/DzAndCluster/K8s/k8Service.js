OPM$.DzAndCluster = OPM$.DzAndCluster || {};
OPM$.DzAndCluster.K8s = OPM$.DzAndCluster.K8s || {};

OPM$.DzAndCluster.K8s.K8Service = (function() {
    'use strict';

    function getKubernetesCluster(dzId, clusterId, template, username) {

        if (username) {
            return GET_JSON$('/opm/cluster/getCluster/' + dzId + '?userid=' + username);
        } else if (typeof template !== 'undefined' && template !== "") {
            return GET_JSON$('/opm/cluster/getCluster/' + dzId + '?clusterTemplateName=' + template);
        } else if(typeof clusterId !== 'undefined') {
            return GET_JSON$('/opm/cluster/getCluster/' + dzId + '?id=' + clusterId);
        } else {
            return GET_JSON$('/opm/cluster/getCluster/' + dzId);
        }
    }

    function getAllDzForSelectedType(type) {
        return GET_JSON$('/opm/cluster/getDeploymentZoneInstances/'+type);
    }

    function getAllInstances() {
        return GET_JSON$('/opm/cluster/getClusters');
    }

    function saveKubernetesCluster(jsonData, clusterId, overrideInfo) {
        var override = typeof overrideInfo !== "undefined" ? overrideInfo : '';
        if(typeof clusterId !== "undefined"){
            return PUT_JSON$({
                url: '/opm/cluster/updateCluster/'+clusterId+override,
                data: JSON.stringify(jsonData)
            });
        } else {
            return POST_JSON$({
                url: '/opm/cluster/createCluster'+override,
                data: JSON.stringify(jsonData)
            });
        }
    }

    function deleteCluster(dzId, clusterId) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/cluster/deleteCluster/'+dzId+'/'+clusterId});
    }


    function deleteNode(dzId, clusterId, nodeIp) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/cluster/deleteNode/'+dzId+'/'+clusterId+'/'+nodeIp});
    }

    function getTemplateNames(type) {
        return GET_JSON$('/opm/cluster/getClusterTemplateNames?type='+type);
    }

    function attachExistingCluster(dzId, formData) {
        return POST_JSON$({
            url: '/opm/cluster/'+dzId+'/attachCluster',
            data: JSON.stringify(formData)
        });
    }

    function deleteTemplate(templateName) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/cluster/deleteClusterTemplate/'+templateName});
    }

    function saveK8Template(name ,data, override) {
        var override = typeof override !== "undefined" ? '?override='+override : '';
        return POST_JSON$({
            url: '/opm/cluster/saveClusterTemplate/'+name+override,
            data:  JSON.stringify(data)
        });
    }

    function deployClusterConfig(data, overrideInfo) {
        var override = typeof overrideInfo !== "undefined" ? overrideInfo : '';
        return POST_JSON$({
            url: '/opm/cloudmap/deployPlatformCluster'+override,
            data:  JSON.stringify(data)
        });
    }
    
    function renderDzK8Templates() {
        return GET_JSON$('/opm/dzCluster/getListOfTemplates');
    }

    function renderDzK8Tpl(templateName) {
        return GET_JSON$('/opm/dzCluster/getTemplate/'+templateName);
    }

    function saveDzK8Template(name, desc, data, override) {
        var override = typeof override !== "undefined" ? '&override='+override : '';
        return POST_JSON$({
            url: '/opm/dzCluster/saveTemplate/'+name+'?description='+desc+override,
            data:  JSON.stringify(data)
        });
    }

    function deleteDzK8Template(templateName) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/dzCluster/deleteTemplate/'+templateName});
    }

    function getAllAttachTypes(){
        return GET_JSON$('/opm/deploymentzone/getAllAttachType');
    }



    return {
        getKubernetesCluster: getKubernetesCluster,
        getAllDzForSelectedType: getAllDzForSelectedType,
        saveKubernetesCluster: saveKubernetesCluster,
        getAllInstances: getAllInstances,
        deleteCluster: deleteCluster,
        deleteNode: deleteNode,
        getTemplateNames: getTemplateNames,
        attachExistingCluster: attachExistingCluster,
        deleteTemplate: deleteTemplate,
        saveK8Template: saveK8Template,
        deployClusterConfig: deployClusterConfig,
        renderDzK8Templates: renderDzK8Templates,
        renderDzK8Tpl: renderDzK8Tpl,
        saveDzK8Template: saveDzK8Template,
        deleteDzK8Template: deleteDzK8Template,
        getAllAttachTypes: getAllAttachTypes
    };
    
})();