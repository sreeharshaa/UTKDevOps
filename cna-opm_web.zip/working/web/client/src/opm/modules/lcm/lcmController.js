OPM$.lcm = OPM$.lcm || {};

OPM$.lcm.lcmController = (function() {
    var lcmState;
    var updateParameter = {
        depChart:  '',
        depRevision: '',
        namespace: '',
        releaseName: '',
        clusterId: '',
        dzId: ''
    };
    function openLcmDialog(e, upgrade) {

        if ($('#lcmDlg').length < 1) {
            lcmState = upgrade;
            var cluster = {
                name: '',
                dzId: '',
                id: '',
                type: ''
            };
            if (typeof e !== "undefined") {
                //In case the dialog is launched from cluster view
                var el$ = $(e.target);
                cluster.name = el$.closest('.an-cluster').find('.cn-cluster-title-text').text();
                cluster.id = el$.closest('.an-cluster').attr('id');
                cluster.dzId = el$.closest('.an-cluster').attr('data-dzId');
                cluster.type = el$.closest('.an-cluster').attr('data-dzType');
            }

            var fed =  $(el$).closest('.an-cnf').length > 0 ? $(el$).closest('.an-cnf') :  $(el$).closest('.an-paas-component'),
                depChart = fed.attr('data-deployedChart'),
                depRevision = fed.attr('data-deployedRevision'),
                namespace = fed.attr('data-namespace'),
                releaseName = fed.attr('data-releaseName'),
                clusterId = fed.closest('.an-cluster').attr('id'),
                dzId = fed.closest('.an-cluster').attr('data-dzId');

            updateParameter = {
                depChart:  depChart,
                depRevision: depRevision,
                namespace: namespace,
                releaseName: releaseName,
                clusterId: clusterId,
                dzId: dzId
            }
            var data = {
                releaseUpgrade: upgrade === "releaseUpgrade" ? true : false,
                createConfig:  upgrade === "createConfig" ? true : false,
                instantiateConfig: (upgrade === 'simplifiedConfig' || upgrade === 'snapshotConfig') ? true : false,
                simplifiedConfig: upgrade === 'simplifiedConfig' ? true : false,
                snapshotConfig: upgrade === 'snapshotConfig' ? true : false
            };

            if(depRevision !== "" && depChart !== "") {
                if (upgrade !== "releaseUpgrade" && upgrade !=="chartUpgrade")
                     lcmHelperFn(data,upgrade)

                if(upgrade !=='createConfig' && upgrade !== 'simplifiedConfig' && upgrade !== 'snapshotConfig'
                    && upgrade !== "releaseUpgrade" && upgrade !=="chartUpgrade") {
                    //Install federation
                    OPM$.repoManagement.repoService.getAllChartRepos()
                        .done(function (data) {
                            data.releaseUpgrade = typeof upgrade !== "undefined" ? true : false
                            var fed_html = Handlebars.templates['lcm_federations_fedForm'](data);
                            $('#federationsLcmForm').empty().append(fed_html);
                            OPM$.lcm.federations.federationsController.contextualClusterSelection(cluster);
                        });
                }
                else if(upgrade === 'simplifiedConfig' || upgrade === 'snapshotConfig'){
                    //Bulk Instantiation Dialog
                    var repoClusterVal = OPM$.lcm.federations.federationsController.getRepoClusterVal();
                    var selectedGroup = OPM$.NFConfig.NFConfigController.getSelectedGroup();
                    $("#lcmButtonDiv").find('button, select').prop('disabled', true);
                    $("#issuOptions").prop('disabled', false);
                    $("#selectInstallChartLabel").css({'display': 'none'});
                    $('#lcmDlg').activity();
                    //Clearing 'prereq-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
                    Cookies.set('prereq-tree-content', {});
                    OPM$.lcm.federations.federationsService.renderAllPrerequisites(repoClusterVal, selectedGroup.name, false)
                        .done(function (data) {
                            OPM$.lcm.federations.federationsController.updateFlavorForm(data.flavorForm);
                            if(data.rollbackPolicyForISSU !== undefined && data.rollbackPolicyForISSU !== null){
                                $("#issuOptions").val('issu-'+data.rollbackPolicyForISSU);
                                $("#issuOptions").prop('disabled', true);
                            }
                            if(upgrade === 'snapshotConfig'){
                                OPM$.lcm.federations.federationsService.getAllSharedParamSets()
                                .done(function (sets) {
                                    var parsedData = {};
                                    parsedData = data.treeNode;
                                    _.assign(parsedData, sets);
                                    callInstantiatehandler(repoClusterVal,selectedGroup, parsedData, upgrade);
                                }).fail(function (error) {
                                    MSG$.showErrorMsg({status: 'Error', content: 'Could not load saved shared parameters list'});
                                    callInstantiatehandler(repoClusterVal,selectedGroup,data.treeNode, upgrade);
                                })
                            }
                            else{
                                callInstantiatehandler(repoClusterVal,selectedGroup,data.treeNode, upgrade);
                            }
                            $('#lcmDlg').activity(false);
                            GCM$.accessibility.accessibilityCommon.setFocus($('#lcmDlg'));
                       }).fail(function (error) {
                        $('#lcmDlg').activity(false);
                        if(error.responseJSON.result === "confirm"){
                            MSG$.confirm({
                                statement: error.responseJSON.errorCode,
                                question: error.responseJSON.errorMessage,
                                yes: function () {
                                    OPM$.lcm.federations.federationsService.renderAllPrerequisites(repoClusterVal, selectedGroup.name, true)
                                        .done(function (data) {
                                            callInstantiatehandler(repoClusterVal,selectedGroup,data.treeNode, upgrade);
                                            GCM$.accessibility.accessibilityCommon.setFocus($('#lcmDlg'));
                                    });
                                }, 
                                no: function () {
                                    GCM$.common_functions.closeDialog('lcmDlg');
                                    OPM$.NFConfig.NFConfigController.launchNFConfigDialog();
                                }
                            });
                        }
                    }).always(function(){
                        $('#lcmDlg').activity(false);
                    })
                }
                else if(upgrade === 'createConfig'){
                    //Create Config Set Dialog
                    OPM$.lcm.federations.federationsService.getAllSharedParamSets()
                       .done(function (sets) {
                           data.releaseUpgrade = false;
                           data.instantiateConfig = false;
                           data.createConfig = true;
                           _.assign(data, sets);
                           var fed_html = Handlebars.templates['lcm_federations_fedForm'](data);
                           $('#federationsLcmForm').empty().append(fed_html);
                           OPM$.lcm.federations.federationsController.resetSimplifiedUCData();
                           $("#helmChartToggleBtn").prop('disabled', true);
                           $("#instantiateSaveChartBtn").prop('disabled', true);
                           $("#instantiateCancelBtn").prop('disabled', true);
                           $("#launchSaveConfigSetBtn").prop('disabled', true);
                           $(".shared-values-btn").prop('disabled', true);
                           $("#addChartBtn").prop('disabled', true);
                           $("#selectClusterBtn").prop('disabled', false);
                           $("#selectSharedValues select").prop('disabled', true);
                           setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                               GCM$.accessibility.accessibilityCommon.setFocus($('#lcmDlg'));
                           },300);
                       });
                }
            }

            //For Release Upgrade
            if (upgrade === "releaseUpgrade" || upgrade ==="chartUpgrade") {

                OPM$.repoManagement.repoService.getAllChartRepos().done(function (repo) {
                    data.repoList = repo.repoList;
                    lcmHelperFn(data,upgrade)
                    data.releaseUpgrade = typeof upgrade !== "undefined" ? true : false
                    var fed_html = Handlebars.templates['lcm_federations_fedForm'](data);
                    $('#federationsLcmForm').empty().append(fed_html);
                    //OPM$.lcm.federations.federationsController.renderChartsInMuseum();
                    OPM$.lcm.federations.federationsController.contextualClusterSelection(cluster);
                    var singleSelectBool = OPM$.repoManagement.repoController.singleRepoAutoSelect(repo.repoList, $('#currentChartSelectedRepo'));
                    setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                        if(singleSelectBool){
                            renderUpgradeLcmView(dzId, clusterId, releaseName, namespace, depChart, depRevision, repo.repoList[0])
                        }}, 100)
                })

            }
        }
        else {
            MSG$.showErrorMsg({status: 'Error', content: 'A version of Life Cycle Management is already open. Please close it before trying to open another'});
        }
    }

    function lcmHelperFn(data, upgrade) {
        var html = Handlebars.templates['lcm_lcm'](data);

        if(upgrade !=='createConfig' && upgrade !== 'instantiateConfig') {
            $('main > .an-layout-center-center').append(html);
            $("#lcmDlg").hide().fadeIn();
        }
        else {
            $('main > .an-layout-center-center').append(html)
            $("#lcmDlg").hide().fadeIn().draggable({
                handle: "header"
            })
        }
        
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#lcmDlg'), false);
        $("#federationsLcmForm").css({"display": "flex"});
        $("#chartDetailToggle").css({'pointer-events':'none', 'opacity':'0.5'});
        $("#chartDetailToggle").find("li").removeAttr("tabindex");
        if($("#opmModeToggleParent").css('display') !== 'none' && ($("#globalStandbyModeToggle").length > 0 && (!$("#globalStandbyModeToggle input").first().prop('checked')))){
            $("#helmApplyBtn").css('display','none')
            if($("#stopBulkInstallBtn").length > 0)
                $("#stopBulkInstallBtn").css('display','none')
            if($("#upgradeCampaignBtn").length > 0)
                $("#upgradeCampaignBtn").css('display','none')
        }
    }

    function renderUpgradeLcmView(dzId, clusterId, releaseName, namespace, depChart, depRevision, repoName) {
        OPM$.lcm.federations.federationsService.getCnfReleaseInfo(dzId, clusterId, releaseName, namespace, depChart, depRevision, repoName)
            .done(function (data) {
                var selectedChart = {
                    repoName: data.repoName,
                    name: data.chartName,
                    version: data.version
                }, upgradeDetails = {
                    namespace: namespace,
                    relName: releaseName,
                    clusterId: clusterId,
                    dzId: dzId
                };

                //var releaseName2 = data.releaseName;
                $('#lcmDlg #currentChartLabel div span').text(data.chart);
                $('#lcmDlg #currentChartLabel').prop('tabindex', -1);
                $('#lcmDlg #currentChartLabel div span').attr('title', data.chart);

                OPM$.lcm.federations.federationsController.renderChartsTree(data.repoName, data.chartName, data.version, selectedChart, upgradeDetails);

                //renderFedViewInLcm(dzId, "openstack", selectedChart);
                renderFedViewInLcm(upgradeDetails);

                Cookies.set('selectedRepo', repoName);
            })
    }
    function callInstantiatehandler(repoClusterVal,selectedGroup,data, type){
        data.releaseUpgrade = false;
        data.instantiateConfig = true;
        data.type = type;
        var fed_html = Handlebars.templates['lcm_federations_fedForm'](data);
        $('#federationsLcmForm').empty().append(fed_html);
        $('#selectClusterBtn span').text(repoClusterVal.selectedCluster.clusterName);
        if(type === 'snapshotConfig')
            $("#selectSharedValues select").prop('disabled', true);
        OPM$.lcm.federations.federationsController.renderPrerequisitesList(selectedGroup, data)

        if(data.inherited === false && data.snapshot === false){
            $(".shared-values-btn").attr('disabled', true);
        }
    }

    function renderFedViewInLcm(upgradeDetails) {
    // Commenting this as the fed view isn't being displayed on GUI anymore

        /*$(".cn-embedded-fed-view").activity();
        OPM$.lcm.federations.federationsService.getFedInfo(upgradeDetails)
            .done(function (data) {
                $(".cn-embedded-fed-view").activity(false);
                var html = Handlebars.templates['lcm_federations_lcmFederation'](data);
                $(".cn-embedded-fed-view").empty().append(html).addClass('cn-cluster-fullscreen');

                OPM$.cloudMap.cloudMapController.cloudMapBindings();
                $(".cn-embedded-fed-view").find(".an-counter").off("click").on("click", function(event) {
                    event.stopPropagation();
                    $(this).closest(".cn-embedded-fed-view").toggleClass("cn-cluster-fullscreen");
                });
            });*/
    }

    function loadTree(data, container, method, leafIcon, branchIcon, integrateVue) {
        var branchIconArr = typeof branchIcon != "undefined" ? [branchIcon] : undefined
        var leafIconArr =  typeof leafIcon != "undefined" ? [leafIcon] : undefined
        var config = {
            leafIcons: leafIconArr,
            branchIcons: branchIconArr,
            blockIcon: false,
            click: method,
            id: container,
            data: data,
            integrateVue: integrateVue
        };
        $('#'+container).empty().tree2(config);
    }

    function filterData() {

        var val = typeof $('#filterInput').val() == "undefined" ? '' : $('#filterInput').val(),
            filterVal = val.split(' '),
            inputVal = filterVal[0],
            version = filterVal[1],
            listId = "tableData";

        //console.log(filterVal);
        $("#" + listId).css("opacity", "0.5");
        $("#" + listId + " li:not([id^='prerequisiteList'])").css({"position": "", "right": ""}).removeClass('cn-li-ignore');
        setTimeout(function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
            if ((inputVal === "" && !version) ||( version && version === "" && inputVal === "")) {
                $("#" + listId).css("opacity", "1");
            } else {
                if(version){
                    $("#" + listId + " li:not([id^='prerequisiteList']) div.cn-repo-chart-version:not(:contains('" + version + "'))").parent().css({
                        "position": "absolute",
                        "right": "-99999px"
                    }).addClass('cn-li-ignore').parent().css({"opacity": "1"});
                    $("#" + listId + " li:not([id^='prerequisiteList']) div.cn-repo-chart-name:not(:contains('" + inputVal + "'))").parent().css({
                        "position": "absolute",
                        "right": "-99999px"
                    }).addClass('cn-li-ignore').parent().css({"opacity": "1"});
                }else {
                    $("#" + listId + " li:not([id^='prerequisiteList']):not(:contains('" + inputVal + "'))").css({
                        "position": "absolute",
                        "right": "-99999px"
                    }).addClass('cn-li-ignore').parent().css({"opacity": "1"});
                }
            }
            $("#tableData").children('li').prop('tabindex', -1);
            $("li[id^='prerequisiteList-']").css('display', 'none');
            var tableDataList = $("#tableData").children('li').not('li.cn-li-ignore')
            if(tableDataList.length > 0)
               tableDataList.first().prop('tabindex', 0);
        }, 1000);

     //   $("#showLatestChartsIcon").prop("disabled", false);
    }

    function showPrereqHelp(that) {
        $(".cn-prereq-help").fadeIn().position({
            of: $(that),
            at: "left bottom",
            my: "left top"
        });
    }

    function nextConfigPane() {
        if(!$("#federationsLcmForm").children()[0].classList.contains('helm-chart-content')){
            var data = {}
            data.releaseUpgrade = false
            data.instantiateConfig = false
            data.createConfig = true
            var fed_html = Handlebars.templates['lcm_federations_fedForm'](data);
            $('#federationsLcmForm').empty().append(fed_html);
            $("#lcmButtonDiv").find('button, select').prop('disabled', false);
            $("#chartDetailToggle").css({'pointer-events':'unset', 'opacity':'1'});
            OPM$.lcm.federations.federationsController.renderPrerequisitesList();
        }
        else{
            OPM$.lcm.federations.federationsController.nextPrerequisite();
        }
    }

    function backConfigPane(){
        if($("#federationsLcmForm").children()[0].classList.contains('helm-chart-content')) {
            OPM$.lcm.federations.federationsController.previousPrerequisite();
        }else {
            //OPM$.lcm.NFConfigLcm.configController.renderCreatePane();
        }
    }

    function toggleMinMax() {
        //$("#lcmHeader").toggle();
        if(lcmState === 'createConfig'){
            $('#lcmDlg').toggleClass('cn-lcm-create-config');
            $('#enlargeLcm').toggle()
        }
        else if(lcmState === 'instantiateConfig'){
            $('#lcmDlg').toggleClass('cn-lcm-instantiate-config');
            $('#enlargeLcm').toggle()
        }
        $('#lcmDlg').toggleClass('cn-min-dialog');
        $('#minMaxLcm').toggleClass('an-icon-minus').toggleClass('an-icon-enlarge2');
        $("#enlargeDlgButton").toggle();
        if ($('#lcmDlg').hasClass('cn-min-dialog')){
            $('#minMaxDlgButton').attr('aria-pressed', 'true');
            $('#minMaxDlgButton').attr('title', 'Toggle minimize lcm dialog - on');
            $('#minMaxDlgButton').focus();
        }
        else{
            $('#minMaxDlgButton').attr('aria-pressed', 'false');
            $('#minMaxDlgButton').attr('title', 'Toggle minimize lcm dialog - off');
            $('#minMaxDlgButton').focus();
        }
    }

    function toggleEnlarge() {
            $('#lcmDlg').toggleClass('cn-enlarge-dialog');
            $('#minMaxDlgButton').toggle()
            if ($('#lcmDlg').hasClass('cn-enlarge-dialog')){
                $('#enlargeDlgButton').attr('aria-pressed', 'true')
            }
            else{
                $('#enlargeDlgButton').attr('aria-pressed', 'false');
            }
    }

    function renderRepoUpdate(e){
        var repoName = $("#currentChartSelectedRepo").val();
        renderUpgradeLcmView(updateParameter.dzId, updateParameter.clusterId, updateParameter.releaseName, updateParameter.namespace, updateParameter.depChart, updateParameter.depRevision, repoName)
    }

    function toggleSaveButton(){
        if($("#newConfigSetName").val().length > 0){
            $("#saveConfigSetButton").prop("disabled", false)
        }else {
            $("#saveConfigSetButton").prop("disabled", true)
        }
    }

    function renderChartMuseumDataByFilter(refresh) {
        if($("#NFTypeCombo").val() === "") {
            //If NF Type is not specified, render only the latest charts from the selected repo
            OPM$.lcm.federations.federationsController.getLatestCharts(refresh);
        } else {
            //If NF Type is specified, render all the versions of selected chart(NF Type) from the repo
            OPM$.lcm.federations.federationsController.renderAllChartVersions(refresh);
        }
    }

    return {
        openLcmDialog: openLcmDialog,
        loadTree: loadTree,
        renderFedViewInLcm: renderFedViewInLcm,
        filterData: filterData,
        showPrereqHelp: showPrereqHelp,
        nextConfigPane: nextConfigPane,
        backConfigPane: backConfigPane,
        toggleMinMax: toggleMinMax,
        toggleEnlarge: toggleEnlarge,
        renderRepoUpdate : renderRepoUpdate,
        toggleSaveButton: toggleSaveButton,
        renderChartMuseumDataByFilter: renderChartMuseumDataByFilter
    };

})();
