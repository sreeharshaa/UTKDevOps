OPM$.lcm = OPM$.lcm || {};
OPM$.lcm.upgradeCampaign = OPM$.lcm.upgradeCampaign || {};

OPM$.lcm.upgradeCampaign.upgradeCampaignService = (function() {

    function renderCampaigns() {
        return GET_JSON$('/opm/campaigns/getAllCampaigns');
        //return GET_JSON$('../json/getAllCamapigns.json');
    }

    function renderCanaryDetails(json) {
        return GET_JSON$('/opm/cnf/retrieveCanaryDeploymentInfo/'+json.dzId+'/'+json.id+'/'+json.repoName+'/'+json.name+'/'+json.version+'/'+json.releaseName+'/'+json.namespace);
        //return GET_JSON$('../json/get.json');
    }

    function getCampaign(name) {
        return GET_JSON$('/opm/campaigns/getCampaign/'+name);
        //return GET_JSON$('../json/getCampaign.json');
    }

    function saveCampaign(formData) {
        return POST_JSON$({
            url: '/opm/campaigns/saveCampaign',
            data: JSON.stringify(formData)
        });
    }

    function doDeleteCampaign(name) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/campaigns/deleteCampaign/'+name});
    }

    function executeStep(details, dryRun, operation) {
        var dryRun = typeof dryRun !== "undefined" ? dryRun : false,
            operation = typeof operation !== "undefined" ? '&oper='+operation : '';
        return POST_JSON$({
            url: '/opm/cnf/executeCanaryStep?dryrun='+dryRun+operation,
            data: JSON.stringify(details)
        });
    }

    return {
        renderCampaigns: renderCampaigns,
        renderCanaryDetails: renderCanaryDetails,
        getCampaign: getCampaign,
        saveCampaign: saveCampaign,
        doDeleteCampaign: doDeleteCampaign,
        executeStep: executeStep
    };

})();