OPM$.lcm = OPM$.lcm || {};
OPM$.lcm.consoleTabs = OPM$.lcm.consoleTabs || {};

OPM$.lcm.consoleTabs.tabsController = (function() {

    var consoleTabCount = 0, consoleOpenFlag = true, newConsoleUpdates = 0;

    function openConsoleTab(config, userSelected) {
        if(consoleOpenFlag)
            OPM$.layout.openSouth();
        var dataName, headerName = config.dzName+' - '+config.clusterName;

        if(typeof config !== "undefined" && typeof config.clusterName !== "undefined" && typeof config.releaseName !== "undefined") {
            dataName = config.clusterName+'::'+config.releaseName+'::'+config.task;
         } else if(typeof config !== "undefined" && typeof config.clusterName !== "undefined" &&  typeof config.releaseName === "undefined"){
             dataName = config.clusterName+'::::'+config.task;
         }

        if($('#consoleHeaderTabs li[data-headerName = "'+headerName+'"]').length > 0 ) {
            if($('#consoleTabs li[data-name="'+dataName+'"]').length > 0) {

                var selectedId = (typeof config.count!== "undefined") ? $('#consoleTabs li[data-count="' + config.count + '"]').attr('id') :
                $('#consoleTabs li[data-name="' + dataName + '"]').attr('id') ,
                    selectedCount = selectedId.split('-')[1];
                if (typeof config.data !== "undefined") {
                    $('#consoleTab-' + selectedCount + '-area').empty().append('<div id="consoleStatusTableDiv-' + selectedCount + '" class="console-table-div"></div>');
                    createStatusTable(config, selectedCount)
                    if(typeof config.timestamp !== "undefined") {
                        config.timestamp = new Date(config.timestamp).customFormat('#MM#/#DD#/#YYYY# #hh#:#mm#:#ss#');
                        $('#consoleTab-' + selectedCount + '-header div').empty().append('Timestamp: ' + config.timestamp);
                    }
                    
                }
                if(typeof config.helmResponses !=="undefined"){
                    $('#consoleTab-' + selectedCount + '-area').prepend('<br/><div id="consoleTabHelmResponse-' + selectedCount + '-area"> <b> Helm Responses </b> <br/> </div>');
                    config.helmResponses.forEach(function(helmResponse, index){
                        showHelmResponses(helmResponse,index, selectedCount);
                    })
                }
                if (userSelected) {
                    selectHeaderTab(config.dzName+' - '+config.clusterName);
                    selectTab(selectedCount);
                    if ($('#' + selectedId).find('span').hasClass('an-content-updated')) {
                        newConsoleUpdates--;
                        updateConsoleIcon()
                    }
                    $('#' + selectedId).find('span').removeClass('an-content-updated');

                } else {
                    if (!$('#' + selectedId).find('span').hasClass('an-content-updated') && !$('#' + selectedId).hasClass('an-selected')) {
                        $('#' + selectedId).find('span').addClass('an-content-updated');
                        newConsoleUpdates++;
                        updateConsoleIcon();
                    }
                }
            } else {
                selectHeaderTab(headerName);
                createNewTab(config);
                newConsoleUpdates++;
                updateConsoleIcon();
            }
        } else {
            createNewHeaderTab(config);
            createNewTab(config);
            $("#consoleTabs li").hide();
            $("#consoleTabs li[data-myheader='"+headerName+"']").show();
            newConsoleUpdates++;
            updateConsoleIcon();
        }
    }

    function createNewHeaderTab(config) {
        var html = Handlebars.templates['lcm_consoleTabs_addHeaderTab'](config);
        $('#consoleHeaderTabs').append(html);
        $('#consoleHeaderTabs li').removeClass('an-selected');
        $('#consoleHeaderTabs li:last').addClass("an-selected");
        $('#consoleHeaderTabs li:last').focus();

        $('#consoleHeaderTabs li').off('click').on('click', function (e) {
            var el$ = $(e.target);
            if(el$.hasClass('an-icon-close') || (el$.hasClass('an-button') && $(el$.children()[0]).hasClass('an-icon-close'))){
                closeConsoleHeaderTab(el$.closest('li').attr('data-headerName'));
            } else {
                selectHeaderTab($(e.target).closest('li').attr('data-headerName'));
            }
        })
        GCM$.accessibility.tabAccessibility.tabKeyNav($("#consoleHeaderTabs"), true);
    }

    function createNewTab(config) {
        config.consoleTabCount = consoleTabCount;
        var html1 = Handlebars.templates['lcm_consoleTabs_addConsoleTab'](config);
        $('#consoleTabs').append(html1);

        var html = Handlebars.templates['lcm_consoleTabs_consoleTab'](config);
        $('#consoleSection').append(html);
        selectTab(consoleTabCount);
        consoleTabCount++;
        createStatusTable(config, consoleTabCount-1);
        $('#consoleTabs li').off('click').on('click', function (e) {
            var el$ = $(e.target);
            if(el$.hasClass('an-icon-close') || (el$.hasClass('an-button') && $(el$.children()[0]).hasClass('an-icon-close'))){
                closeConsoleTab(el$.closest('li').attr('data-count'));
            } else {
                var names = el$.closest('li').attr('data-name').split("::"),
                config , count = el$.closest('li').attr('data-count');
                if(names.length == 3) {
                    config = {
                        dzName: el$.closest('li').attr('data-myheader').split(' - ')[0],
                        clusterName: names[0],
                        releaseName: names[1],
                        task: names[2],
                        count: count
                    };
                } else if(names.length === 2){
                    config = {
                        dzName: el$.closest('li').attr('data-myheader').split(' - ')[0],
                        clusterName: names[0],
                        task: names[1],
                        count: count
                    };
                }

                var userSelected = true;
                openConsoleTab(config, userSelected);
            }
        });
        GCM$.accessibility.tabAccessibility.tabKeyNav($("#consoleTabs"), true);
    }

    function createStatusTable(config, index){
        config.consoleTabCount = index;
        var html = Handlebars.templates['lcm_consoleTabs_consoleStatusTable'](config);
        $('#consoleStatusTableDiv-'+index).empty().append(html);
        setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
            _.forEach($('tbody[id^="consoleTableBody-' + index + '"]') , function(v, k) {
                $(v).find('tr').first().find('td').first().attr('tabindex', 0)
            });
            //Commenting out GCM table accessibility since there are no user actions in console status.
            // _.forEach(config.consoleTables.table, function (v, k){
            //     GCM$.accessibility.tableAccessibility.makeTableKeyNav($('tbody[id^="consoleTableBody-' + index + '-' + k +'"]'));
            // });
        },200)
    }

    function closeConsoleHeaderTab(name) {
        var $tab = $('#consoleHeaderTabs li[data-headerName = "'+name+'"]');
        if($tab.next().length > 0){
            selectHeaderTab($tab.next().attr("data-headername"));
        } else if($tab.prev().length > 0 ){
            selectHeaderTab($tab.prev().attr("data-headername"));
        }
        $('#consoleHeaderTabs li[data-headerName = "'+name+'"]').detach();

        _.forEach($("#consoleTabs li[data-myheader='"+name+"']"), function(el) {
            var tabcount = $(el).attr('data-count');
            closeConsoleTab(tabcount);
        })
    }
    
    function closeConsoleTab(deletedTabCount) {
        var elemId;
        if($('#consoleTab-'+deletedTabCount).hasClass('an-selected')) {
            if($('#consoleTab-'+deletedTabCount).next().length > 0){
                elemId = $('#consoleTab-'+deletedTabCount).next().attr('id').split('-').pop();
                selectTab(elemId);
            } else if($('#consoleTab-'+deletedTabCount).prev().length > 0) {
                elemId = $('#consoleTab-'+deletedTabCount).prev().attr('id').split('-').pop();
                selectTab(elemId);
            }
        }
        if($("#consoleTab-"+deletedTabCount).find('span').hasClass('an-content-updated')){
            if(newConsoleUpdates!==0)
                newConsoleUpdates = newConsoleUpdates-2;
        }else{
            if(newConsoleUpdates!==0)
                newConsoleUpdates--;
        }
        updateConsoleIcon();
        $('#consoleTab-'+deletedTabCount).detach();
        $('#consoleTab-'+deletedTabCount+'-header').detach();
        $('#consoleTab-'+deletedTabCount+'-area').detach();
    }

    function selectTab(selectedTabCount) {
        $('#consoleTabs li').removeClass('an-selected').attr('tabindex', '-1');
        $('#consoleSection >div').hide();
        $('#consoleSectionPopup div').show();
        $('#consoleTab-'+selectedTabCount).addClass('an-selected').attr('tabindex', 0);
        $("#consoleTab-"+selectedTabCount).focus();
        $('#consoleTab-'+selectedTabCount+'-header').show();
        $('#consoleTab-'+selectedTabCount+'-area').show();
    }

    function selectHeaderTab(headerName) {
        $("#consoleHeaderTabs li").removeClass('an-selected').attr('tabindex', '-1');
        $("#consoleHeaderTabs li[data-headerName='"+headerName+"']").addClass('an-selected').attr('tabindex', 0);
        $("#consoleTabs li").hide();
        $("#consoleTabs li[data-myheader='"+headerName+"']").show();
        selectTab($($("#consoleTabs li:visible")[0]).attr("data-count"));
    }

    function toggleConsoleFlag(){
        if(consoleOpenFlag) {
            consoleOpenFlag = false;
            $('#consolePopupToggle input').removeAttr('checked');
            $('#consolePopupToggle').attr('aria-checked', false);
            $("#consoleSectionPopup").attr('title','Turn automatic popup on');
        }
        else {
            consoleOpenFlag = true;
            $('#consolePopupToggle input').prop('checked', 'checked');
            $('#consolePopupToggle').attr('aria-checked', true);
            $("#consoleSectionPopup").attr('title','Turn automatic popup off');
        }
    }

    function toggleConsole(){
        if($('#consolePaneIcon').hasClass('focus-icon')){
            OPM$.layout.closeSouth();
        }
        else{
            OPM$.layout.openSouth();
        }
    }

    function updateConsoleIcon(){
        if(newConsoleUpdates > 0){
            $("#consoleIconCount").text(newConsoleUpdates);
            $("#consolePaneIcon").attr('title', 'Toggle Console tabs pane, contains '+newConsoleUpdates+' tabs');
            if($("#consoleIconCount").css('display') === 'none')
                $("#consoleIconCount").css('display', 'inline-block');
        }
        else {
            $("#consoleIconCount").css('display', 'none');
            $("#consoleIconCount").text(newConsoleUpdates);
            $("#consolePaneIcon").attr('title', 'Toggle Console tabs pane');
        }
    }

    function showHelmResponses(helmResponse, index, selectedCount){
        $('#consoleTabHelmResponse-' + selectedCount + '-area').append('<br/><div id="consoleStatusHelmDiv-' + index+'-'+selectedCount + '">'+ 
        '<b>Type: </b>'+helmResponse.type+'<br/>'+
        '<b>Command: </b>'+helmResponse.command+'<br/>'+
        '<b>Response: </b>'+helmResponse.response+'<br/>'+
        '<b>Timestamp: </b>'+helmResponse.timestamp+'<br/>'+
        '<b>Status: </b>'+helmResponse.status+'<br/>'
        +'</div>');
    }


    return {
        openConsoleTab: openConsoleTab,
        toggleConsoleFlag: toggleConsoleFlag,
        toggleConsole: toggleConsole
    };

})();