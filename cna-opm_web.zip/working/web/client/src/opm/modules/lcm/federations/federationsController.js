OPM$.lcm = OPM$.lcm || {};
OPM$.lcm.federations = OPM$.lcm.federations || {};

OPM$.lcm.federations.federationsController = (function() {
    'use strict';
    var selectedChart = {
            repoName: '',
            name: '',
            version: ''
        }, selectedCluster = {
            dzId: '',
            id: '',
            type: ''
        }, prereqTraverse = {
            curBranch: '',
            curLeaf: ''
        },
        olderSelectedChart = {
            repoName: '',
            name: '',
            version: ''
        },
        repoClusterVal = {
            repoName: '',
            selectedCluster: {}
        },
        instantiateData = {},
        instantiateDetails = {
            releaseName: '',
            namespace: '',
            clusterId: '',
            dzId: '',
            nfAndPaasInstanceId: '',
            group: '',
            branchName: ''
        },
        originalFormData = {},
        simplifiedUCData = {},
        selectedUpdateConfigNF = {
            chartName: '',
            version: '',
            nfAndPaasInstanceId: ''
        },
        currDisplayedDifference;

    function renderHelmChart(name, dirName, selectedChart, upgradeDetails, tagAttr, markdownFile, format,instantiateDetails, prevChart) {
        $("#form-pane").activity();
        $("#helmChartName").text(name)
       // $("#chartDifferences").css({'display': 'inline-table'});
        $("#chartName").text(selectedChart.name+' - '+ selectedChart.version);
        if(markdownFile){
            var url = '/opm/repos/retrieveFile?dirName=' + dirName + '&fileName=' + name + '&chartName=' + selectedChart.name + '&repoName=' + selectedChart.repoName + '&version=' + selectedChart.version;
            getPackageMarkdownFile(url);
            $("#form-pane").activity(false);
        } else {
            $('#instantiateHeaderDiv').find('button').attr('disabled', 'disabled');
            OPM$.lcm.federations.federationsService.renderForm(name, dirName, selectedChart, upgradeDetails, tagAttr, format,instantiateDetails, prevChart)
                .done(function (data) {
                    $.extend(true, originalFormData, data);

                    //prevChart is used only when a new chart is selected by the user
                    var showDifferences = typeof prevChart !== "undefined"? true: false;
                    updateForm(data, format, showDifferences);
                    if(data.newAttrsCnt > 0 || data.updatedAttrsCnt > 0 || data.deletedAttrsCnt > 0)
                        $("#chartDifferences").css('display', 'block');
                        $("#newAttrCount").text(data.newAttrsCnt);
                        $("#newAttrCount").attr('aria-label',data.newAttrsCnt+';');
                        $("#changedAttrCount").text(data.updatedAttrsCnt);
                        $("#changedAttrCount").attr('aria-label',data.updatedAttrsCnt+';');
                        $("#deletedAttrCount").text(data.deletedAttrsCnt);
                        $("#deletedAttrCount").attr('aria-label',data.deletedAttrsCnt+';');
                    $('#importIcon, #exportIcon, #expertIcon').each(function () {
                        $(this).prop('disabled', false);
                    });
                    // if(!$("#pinPrerequisitesBtn").hasClass("prerequisitesPinned")) {
                    //     loadPrerequisitesRecipe(selectedChart.repoName, selectedChart.name, selectedChart.version);
                    //     $('#prerequisite-recipe').slideDown();
                    // }
                }).always(function () {
                    $('#instantiateHeaderDiv').find('button').attr('disabled', false);
                    $("#form-pane").activity(false);
                    // When user selects a new chart, the form is refreshed to validate the new values
                    // Disable the save chart button until all the required values are provided and validated
                    try {
                        VALIDATION$.validateOnInputChange($('#values-output'), $("#instantiateSaveChartBtn"), undefined, undefined, undefined, true);
                    }
                    catch (error) {
                        console.log(error);
                    }
            });
        }
    }

    function showPerFedHelmOptions(){
        var config = {
            disableSetLabel: true
        };
        //Sending parameters: nfConfigSetName, chartRepoName, dzId, clusterId for API call
        OPM$.lcm.federations.federationsService.showPerFedHelmOptions(instantiateDetails.group.name, repoClusterVal.repoName, repoClusterVal.selectedCluster.dzId, repoClusterVal.selectedCluster.id).done(function (data) {
            $('#instantiateSaveChartBtn').attr('title', 'Save updated per fed helm options');
            $('#instantiateCancelBtn').attr('title', 'Discard updated per fed helm options');
            $('#form-pane').addClass('helm-options');
            GCM$.form.createForm('values-output', data, undefined, config);
            $.extend(true, originalFormData, data);
            toggleHelmChartView();
        });
    }


    function updateForm(data, format, showDifferences) {
        var config = {
            disableSetLabel: true
        };
        GCM$.form.createForm('values-output', data, undefined, config);
        $("#filterSelection").prop('disabled', false);
        if(showDifferences && $("#values-output form").find(".an-differences").length > 0)
            $("#filterSelection").val("differences");
        formPostProcessing();
        $('#values-output').on('keydown', function(e){
            //Prevent space key press from scrolling 
            var target$ = $(e.target);
            if(e.keyCode === GCM_KEY$.SPACE && target$.attr('role') == 'switch'){
                e.preventDefault();
            }
        })
        //console.log($("#selectClusterBtn").closest('dialog').hasClass("cn-lcm-instantiate-config"))
        if($("#values-output form").find(".an-differences").length > 0) {
            $("#scrollToNxtDiff, #scrollToPrevDiff").prop('disabled', false);
        } else {
            $("#scrollToNxtDiff, #scrollToPrevDiff").prop('disabled', true);
        }
        currDisplayedDifference = undefined;
        if(!$("#selectClusterBtn").closest('dialog').hasClass("cn-lcm-instantiate-config"))
            $('#selectClusterBtn').attr('disabled', false);

        if(format === "yaml") {
            $('.CodeMirror').detach();
            $('#yamlEditor').empty().append(data.dataContent);
            GCM$.common_functions.invokeCodemirror("yamlEditor", "YAML");
            $('#parentFormContainer').addClass('cn-expert-mode');
        } else {
            $('.CodeMirror').detach();
            $('#parentFormContainer').removeClass('cn-expert-mode');
        }
    }

    function renderExistingForm(e, relName, format) {
        var myFormat;
        var selectedVal;

        if(typeof relName === "undefined"){
            selectedVal = $(e.target).closest('li').text();
        } else {
            selectedVal = relName;
        }

        if(typeof format !== "undefined"){
            myFormat = format;
        } else {
            if($('#parentFormContainer').hasClass('cn-expert-mode')){
                myFormat = "yaml";
            }
        }
        $('#values-output').activity();

        OPM$.lcm.federations.federationsService.renderExistingForm(selectedChart, selectedVal, myFormat)
            .done(function (data) {
                var config = {
                    disableSetLabel: true
                };
                GCM$.form.createForm('values-output', data, undefined, config);
                formPostProcessing();
                $('#values-output').on('keydown', function(e){
                    //Prevent space key press from scrolling 
                    var target$ = $(e.target);
                    if(e.keyCode === GCM_KEY$.SPACE && target$.attr('role') == 'switch'){
                        e.preventDefault();
                    }
                })
                if(data.newAttrsCnt > 0 || data.updatedAttrsCnt > 0 || data.deletedAttrsCnt > 0)
                    $("#chartDifferences").css('display', 'block');
                $("#newAttrCount").text(data.newAttrsCnt);
                $("#newAttrCount").attr('aria-label',data.newAttrsCnt+';');
                $("#changedAttrCount").text(data.updatedAttrsCnt);
                $("#changedAttrCount").attr('aria-label',data.updatedAttrsCnt+';');
                $("#deletedAttrCount").text(data.deletedAttrsCnt);
                $("#deletedAttrCount").attr('aria-label',data.deletedAttrsCnt+';');

                if(myFormat === "yaml") {
                    $('#yamlEditor').empty().append(data.dataContent);
                    $('.CodeMirror').detach();
                    GCM$.common_functions.invokeCodemirror("yamlEditor", "YAML");
                    $('#parentFormContainer').addClass('cn-expert-mode');
                } else {
                    $('.CodeMirror').detach();
                    $('#parentFormContainer').removeClass('cn-expert-mode');
                }
                $('#formTabs li[class="an-disabled"]').removeClass("an-disabled");

            }).always(function () {
                $('#values-output').activity(false);
        })
    }

    function launchDependencyPicker(e) {
        e.stopPropagation();
        if ($('#dependencyPickerDlg').length < 1) {
            var el$ = $(e.target),
                dependency = JSON.parse(el$.attr('data-dependency'));
            OPM$.lcm.federations.federationsService.renderDependencies(dependency.component)
                .done(function (data) {
                    data.dependency = dependency;
                    var html = Handlebars.templates['lcm_federations_dependencyPicker'](data);
                    $(html).appendTo('#lcmDlg');
                    $('#dependencyPickerDlg').draggable({
                        handle: "header"
                    }).position({
                        my: "center",
                        at: "center",
                        of: $('#values-output')
                    });
                    GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#dependencyPickerDlg'))
                    $('#dependencyPickerDlg i').mouseenter(showStatusDetails);
                    $('#dependencyPickerDlg i').mouseleave(function () {
                        $('#depStatusPopup').detach();
                    });
                });
        }
        else{
            MSG$.showErrorMsg({status: 'Error', content: 'Dependency Picker is already open. Please close it before trying to open another'});
        }
    }

    function launchImportDialog() {
        var json = {};

        if($('#uploadDialog').length > 0){
            refreshImportStatus();
        } else {
            $('body').activity();
            OPM$.lcm.federations.federationsService.getImportStatus()
                .done(function (res) {
                    json = res;
                    OPM$.repoManagement.repoService.getAllChartRepos()
                        .done(function (data) {
                            json.chartRepos = data.repoList;

                            OPM$.repoManagement.repoService.getAllImageRepos()
                                .done(function (data1) {
                                    json.imageRepos = data1.repoList;

                                    doLaunchImport(json);
                                });
                        });
                });
        }
    }

    function doLaunchImport(json) {
        var html = Handlebars.templates['lcm_federations_import'](json);
        $(html).appendTo('body');
        $("#uploadDialog").draggable({
            handle: "header"
        }).position({
            my: "center",
            at: "center",
            of: "body"
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#uploadDialog'));
        GCM$.common_functions.inputFile();
        $('body').activity(false);

        if(!json.isImportRunning){
            VALIDATION$.validateOnInputChange($('#importForm'), $('#uploadButton'), undefined, undefined, undefined, true);
        }
        $('#uploadButton').off().on('click', importChartsAndImages);
        OPM$.repoManagement.repoController.singleRepoAutoSelect(json.chartRepos, $('#importSelectChart'));
    }

    function refreshImportStatus() {
        $('#uploadDialog').activity();
        OPM$.lcm.federations.federationsService.getImportStatus()
            .done(function (res) {
                $('#importStatusPane').empty().append(res.status);
            }).always(function () {
                $('#uploadDialog').activity(false);
        })
    }

    function toggleUpgradeCampaignPane() {
        $("#upgrade-campaign-content").toggle();
        $("#values-output").toggle();
        if($("#upgrade-campaign-content").css('display') === "block"){
            OPM$.lcm.upgradeCampaign.upgradeCampaignController.getData();
            $('#helmApplyBtn').prop('disabled', true);
            $('#stopBulkInstallBtn').prop('disabled', true);
        } else {
            $('#helmApplyBtn').prop('disabled', false);
            $('#stopBulkInstallBtn').prop('disabled', false);
        }
    }

    function importChartsAndImages(event) {
        event.stopPropagation();event.preventDefault();
        var data = new FormData($('#importForm')[0]);
        var chartRepoName = $($('#importForm').find('select')[0]).val(),
            imageRepoName = $($('#importForm').find('select')[1]).val();

        $('#uploadDialog').activity();
        $.ajax({
            url: '/opm/repos/upload/'+chartRepoName+'/'+imageRepoName,
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data) {
                MSG$.showInfoMsg({status: 'Success', content: 'Import started successfully'});
                $('#uploadDialog').activity(false);
                GCM$.common_functions.closeDialog('uploadDialog');
            },
            error: function (res) {
                MSG$.showErrorMsg({status: 'Error', content: 'Import Failed'});
                $('#uploadDialog').activity(false);
            }
        });
    }

    function launchChartMuseum(fed, makeRepoReadonly) {
        var repoSelected;
        if($('#chartMuseumDlg').length === 0) {

            OPM$.repoManagement.repoService.getAllChartRepos()
                .done(function (data) {
                    data.status = fed;
                    data.readonlyRepo = makeRepoReadonly;
                    if (fed === 'newChartLabelInstantiate' || fed === 'newChartLabel') {
                        data.instantiate = selectedChart.name
                        data.newChartSelection = true;
                    } else if(fed === 'updateConfigNF'){
                        data.instantiate = selectedUpdateConfigNF.chartName;
                    }
                    var html = Handlebars.templates['lcm_federations_chartMuseum'](data);
                    $('#lcmDlg').append(html);
                    if(Cookies.get('chartMode')){
                        $("#nfChartPinned").css('display', 'flex');
                        $("#chartMuseumDlg").css('display' , 'none');
                        $('#nfChartPinned').append($("#chartMuseumDiv"));
                        $("#chartMuseumDlg").detach($("#chartMuseumDiv"));
                        $('#pinNFBtn').addClass('nfChartPinned').attr('aria-pressed', 'true');
                        $('#chartMuseumHeader button#closeBtn').css('display', 'none')
                        if($('#lcmDlg').hasClass('cn-lcm-create-config')){
                            $('#pinnedChartCreateConfig').css('display', 'block');
                        }
                    }
                    OPM$.repoManagement.repoController.singleRepoAutoSelect(data.repoList, $('#lcmSelectedRepo'));
                    if(data.repoList.length === 1)
                        $("#filterListByKeyword").prop('disabled', false);
                    else
                        $("#filterListByKeyword").prop('disabled', true);
                    GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#chartMuseumDlg'))
                    if (fed === 'updateConfigNF'){
                        $('#chartMuseumDlg').addClass('updateConfigNF');
                    }
                    $('#chartMuseumDlg').draggable({
                        handle: "header"
                    })
           });
        }
    }

    function renderChartsInMuseum(e, repoSelected) {
        var sel;
        if(typeof e !== "undefined" && !_.isEmpty(e)){
            sel = $(e.target).val();
        }
        else if(typeof repoSelected !== "undefined" && !_.isEmpty(repoSelected)){
            sel = repoSelected;
        }

        if(typeof sel !== "undefined" && sel !== "") {
            var option = $('.an-crud-list select option[value="' + sel + '"]');
            $(option).attr('selected', true);
            $('#museum-tree-content').activity();
            $("#chartMuseumSection").addClass("an-selector-loading");
            OPM$.lcm.federations.federationsService.getChartsList(sel)
                .done(function (data) {
                    var html = Handlebars.templates['lcm_federations_chartMuseumTable'](data);
                    $('#museum-tree-content').empty().append(html);

                    //var filterText = $('#filterInput').val();
                    OPM$.lcm.lcmController.filterData(undefined, 'tableData');
                   
                    if($('#chartMuseumDlg').length > 0 && !($('#chartMuseumDlg').hasClass('updateConfigNF'))) {
                        $('#chartMuseumDiv ul').off('click').on('click', OPM$.lcm.federations.federationsController.onClickChartsList);
                    } else if($('#chartMuseumDlg').length > 0 && $('#chartMuseumDlg').hasClass('updateConfigNF')){
                        $('#chartMuseumDiv ul').off('click').on('click', OPM$.lcm.federations.federationsController.onSelectChart);
                    }
                    else{
                        $('#lcmDlg #museum-tree-content ul').off('click').on('click', OPM$.lcm.federations.federationsController.onSelectChart);
                    }
                    GCM$.accessibility.listAccessibility.makeListKeyNav($("#tableData"));
                }).always(function () {
                    $('#museum-tree-content').activity(false);
                    $("#chartMuseumSection").removeClass("an-selector-loading");
            });
        } else if(sel == "") {
            $('#museum-tree-content').empty();
        }
    }

    function onClickChartsList(e) {
        var el$ = $(e.target).closest('li');
        $('#chartMuseumDiv ul li').removeClass('an-selected');
        el$.addClass('an-selected');
        if($('#pinnedChartCreateConfig').css('display') === 'none'){
            $('#selectChartBtn').attr('disabled', false);
            $('#selectChartBtnReg').attr('disabled', true);
        }
        else if($('#pinnedChartCreateConfig').css('display') === 'block'){
            $('#selectChartBtnReg').attr('disabled', false);
            $('#selectChartBtn').attr('disabled', true);
        }
        var id = $('#chartMuseumDiv ul').find('li.an-selected').attr("id").split("-")[1];
        if($("#prerequisiteList-"+id).css('display') === 'none') {
            var repoName = $('#chartMuseumDiv').find('select').val(),
                chartName = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-name').text(),
                chartVersion = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-version').text();
            $("[id^='prerequisiteList-']").css('display', 'none');

            $('#chartMuseumDiv ul').find('li.an-selected').activity()
            OPM$.lcm.federations.federationsService.renderPrerequisites(repoName, chartName, chartVersion)
                .done(function (data) {

                    $("#prerequisiteList-" + id).css('display', 'block')
                    var html = Handlebars.templates['lcm_federations_prerequisiteList'](data);
                    $("#prerequisiteList-" + id+ " div").empty().append(html);
                    GCM$.accessibility.listAccessibility.makeListKeyNav($("#prerequisiteList-" + id + " div ol"));

                }).always(function () {
                    $('#chartMuseumDiv ul').find('li.an-selected').activity(false)
            });
        }
        else {
            $("#prerequisiteList-" + id).css('display', 'none')
        }
        //Select chart action moved from chartMuseum handlebars on chart click
        if($("#lcmDlg").hasClass('cn-lcm-install'))
            newSelectChart();
        else if($("#lcmDlg").hasClass('cn-lcm-instantiate-config'))
            pickNewChartVersion();
        else
            pickNewChartInMuseum();
    }

    function pickNewChartInMuseum() {

        selectedChart.repoName = $('#chartMuseumDiv').find('select').val();
        selectedChart.name = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-name').text();
        selectedChart.version = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-version').text();

        if(!$("#lcmDlg").hasClass('cn-lcm-create-config')) {
            $('#selectNewChartBtn span').val(selectedChart.name + '-' + selectedChart.version);
            $('#selectNewChartBtn span').text(selectedChart.name + '-' + selectedChart.version);

            var details = getReleaseNameAndNamespace(FORM$.getData('values-output')),
                upgradeDetails = {
                    namespace: details.namespace,
                    relName: details.releaseName,
                    clusterId: selectedCluster.id,
                    dzId: selectedCluster.dzId
                }, tagAttr = true; //tagAttr flag is used by the back-end to set the changed field counts and flags(newAttr, override, deleted)

            var prevChart = $("#newChartIndicator").length > 0 ? $("#currentChartName").text() : undefined //Backend needs this information for merging values.yaml during chart upgrade

            renderChartsTree(selectedChart.repoName, selectedChart.name, selectedChart.version, selectedChart, upgradeDetails, tagAttr, undefined, prevChart);
        }
    }

    function onSelectChart(e) {
        var el$ = $(e.target).closest('li');
        $('#museum-tree-content ul li').removeClass('an-selected');
        el$.addClass('an-selected');

        selectedChart.repoName = $("#lcmSelectedRepo").val();
        selectedChart.name = $(el$).find('.cn-repo-chart-name').text();
        selectedChart.version = $(el$).find('.cn-repo-chart-version').text();
        if(!($('#chartMuseumDlg').length > 0)){
            selectedChart.repoName = $(el$).closest('.an-crud-list').find('select').val();
            renderChartsTree(selectedChart.repoName, selectedChart.name, selectedChart.version);
        }

    }

    function loadPrerequisitesRecipe(repoName, chartName, chartVersion) {
        var $preReq = $('#prerequisite-recipe');

        $preReq.activity();
        OPM$.lcm.federations.federationsService.renderPrerequisites(repoName,chartName, chartVersion)
            .done(function (data) {
                if(repoName === 'config')
                    data.instantiateConfig = true
                var html = Handlebars.templates['lcm_federations_prerequisites'](data);
                $preReq.empty().append(html);

                $("#pinPrerequisitesBtn").off("click").on("click", function() {
                    $(this).toggleClass("prerequisitesPinned");
                });
            }).always(function () {
                $preReq.activity(false);
            });

        $preReq.off("click", "a.cn-prereq-name").on("click", "a.cn-prereq-name", function(e) {
            var preReqChartName = $(e.target).text().trim();

            callRenderAllChartVersions(repoName, preReqChartName);
        });

        $preReq.off("click", "a.cn-prereq-version").on("click", "a.cn-prereq-version", function(e) {
            var preReqChartName = $(e.target).closest(".cn-prereq-name-version").find(".cn-prereq-name").text().trim(),
                prereqChartVersion = $(e.target).text().trim();

            callRenderAllChartVersions(repoName, preReqChartName, prereqChartVersion);
            renderChartsTree(repoName, preReqChartName, prereqChartVersion);
        });
    }

    function renderChartsTree(repoName, chartName, version, selChart, upgradeDetails, tagAttr, instantiateDetails, prevChart) {
        //upgradeDetails(dzId, clusterId, releaseName, namespace) will not be undefined only in case of upgrade
        if(typeof selChart !== "undefined"){
            selectedChart = selChart;
        }
        $("#helm-tree-content").activity();
        if($("#lcmDlg").hasClass('cn-lcm-instantiate-config') || $("#lcmDlg").hasClass('cn-lcm-create-config')){
            $("#form-pane").activity();
            $('#prereq-tree-content').css('pointer-events', 'none');
        }
        $('#federationsLcmForm .cn-embedded-fed-view').empty().append('<div>Federation View</div>');
        //Clearing 'helm-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
        Cookies.set('helm-tree-content div', {});
        OPM$.lcm.federations.federationsService.renderChartsTree(repoName,chartName, version)
            .done(function (data) {
                OPM$.lcm.lcmController.loadTree (data, 'helm-tree-content div#helmChartContainer', OPM$.lcm.federations.federationsController.onTreeClick);
                //Clearing 'helm-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
                Cookies.set('helm-tree-content div', {});
                var name = "values.yaml", dirName;
                var selector = $('#helm-tree-content li[data-tree-path="/'+name+'"]');
                if(selector.length > 0) {
                    var values = _.filter(data.branch , function(arr){
                        if(arr['name'] === 'values.yaml')
                            return arr;
                    })
                    if(values.length > 0){
                       dirName = values[0]['type'];
                    }
                    else{
                        dirName = $(selector).attr('data-type');
                    }
                    renderHelmChart(name, dirName, selectedChart, upgradeDetails, tagAttr, undefined,undefined,instantiateDetails, prevChart);
                    $('#helm-tree-content div ul.an-tree li').removeClass('an-selected');
                    $(selector).addClass('an-selected');

                    $('#helmTitle').text(chartName + '-' + version)
                        .attr('title', chartName + '-' + version);
                }
                $('#helm-tree-content div ul.an-tree').prop('aria-busy', true);
                if(tagAttr){
                    $('#formTabs li[class="an-disabled"]').removeClass("an-disabled");
                }
                if(data.canary || $("#lcmDlg").hasClass("cn-lcm-upgrade-release")){
                    $(".cn-canary-btn").prop('disabled', false);
                }
                $("#selectNewChartBtn").prop('disabled', false);
                $("#chartDetailToggle").css({'pointer-events': 'unset', 'opacity': '1'});
                $("#chartDetailToggle").find("li").prop("tabindex", -1);
                $("#chartDetailToggle").find("li.an-selected").prop("tabindex", 0);

        }).always(function () {
            $("#helm-tree-content").activity(false);
            if($("#lcmDlg").hasClass('cn-lcm-instantiate-config') || $("#lcmDlg").hasClass('cn-lcm-create-config')){
                $("#form-pane").activity(false);
                $('#prereq-tree-content').css('pointer-events', 'unset');
            }
        });
    }

    function onTreeClick(e) {
        var target = $(e.target);
        e.stopPropagation();
        if(target.closest('li').hasClass('leaf') && !target.closest('li').hasClass('non-clickable')) {
            target.closest('ul.an-tree').find('li.an-selected').removeClass('an-selected');
            target.closest('li').addClass('an-selected');

            if(target.closest('li').find('a').text().indexOf("values") >= 0 && target.closest('li').find('a').text().indexOf(".yaml") >= 0) {
                renderHelmChart(target.closest('li').attr('data-name'), target.closest('li').attr('data-type'), selectedChart);
            } else {
                var markDownFile = true;
                renderHelmChart(target.closest('li').attr('data-name'), target.closest('li').attr('data-type'), selectedChart, undefined, undefined, markDownFile);
            }
        }
    }

    function saveFed() {
        var format;
        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to apply the above changes to a live network',
            yes: function () {
                var jsonData = FORM$.getData('values-output'),
                    chartDetails = getReleaseNameAndNamespace(jsonData);

                var upgrade = false;
                if($('#lcmDlg #newChartLabel').length > 0){
                     upgrade = true;
                }

                if($('#parentFormContainer').hasClass('cn-expert-mode')){
                    jsonData.dataContent = GCM$.common_functions.editor["yamlEditor"].getValue();
                    format = "yaml";
                }

                if(upgrade && $('.cn-embedded-fed-view li').length > 0){
                    jsonData.revision = $('.cn-embedded-fed-view li').attr('data-deployedrevision');
                }

                if(isValid(chartDetails)) {
                    doSaveFed(jsonData, selectedCluster, selectedChart, chartDetails, upgrade, undefined, format);
                }
            }
        });
    }

    function doSaveFed(jsonData, selectedCluster, selectedChart, chartDetails, upgrade, override, format) {
        $("#values-output").activity();
        OPM$.lcm.federations.federationsService.saveFed(jsonData, selectedCluster, selectedChart, chartDetails, upgrade, override, format)
            .done(function (data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
            }).always(function () {
                $("#values-output").activity(false);
        }).fail(function (data) {
            if(data.responseJSON.result === "confirm"){
                if(data.responseJSON.action === "rollback") {
                    MSG$.confirm({
                        statement: 'Rollback Confirmation',
                        question: data.responseJSON.errorMessage,
                        yes: function () {
                            performRollbackCnf($("#values-output"), chartDetails, selectedChart, selectedCluster);
                        }
                    });
                } else if(data.responseJSON.action === "override" || data.responseJSON.action === "override_oos"){
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: data.responseJSON.errorMessage,
                        yes: function () {
                            var override;
                            if(data.responseJSON.action === "override"){
                                override = '?override=true';
                            } else if(data.responseJSON.action === "override_oos"){
                                override = '?override=true&override_oos=true';
                            }
                            doSaveFed(jsonData, selectedCluster, selectedChart, chartDetails, upgrade, override, format);
                        }
                    });
                }
            }
        });
    }

    function rollbackCnf(e) {
        var el$ = $(e.target);
        var fed = $(el$).closest('.an-cnf').length > 0 ? $(el$).closest('.an-cnf') : $(el$).closest('.an-paas-component'),
            depChart = fed.attr('data-deployedChart'),
            depRevision = fed.attr('data-deployedRevision'),
            namespace = fed.attr('data-namespace'),
            releaseName = fed.attr('data-releaseName'),
            clusterId = fed.closest('.an-cluster').attr('id'),
            dzId = fed.closest('.an-cluster').attr('data-dzId');

        OPM$.lcm.federations.federationsService.getCnfReleaseInfo(dzId, clusterId, releaseName, namespace, depChart, depRevision)
            .done(function (data) {
                var selChart = {
                    repoName: data.repoName,
                    name: data.chartName,
                    version: data.version
                }, chartDetails = {
                    releaseName: releaseName,
                    namespace: namespace
                }, selCluster = {
                    id: clusterId,
                    dzId: dzId
                }, selector = fed;

                MSG$.confirm({
                    statement: 'Confirm',
                    question: 'Are you sure you want to rollback '+releaseName+'?',
                    yes: function () {
                        performRollbackCnf(selector, chartDetails, selChart, selCluster);
                    },
                    close: function () {
                        $(fed).find('h4 i').focus();
                    }
                });
            });
    }

    function performRollbackCnf(selector, chartDetails, selChart, selCluster, override, canary) {
        selector.activity();
        OPM$.lcm.federations.federationsService.performRollback(chartDetails, selChart, selCluster, override)
            .done(function (data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                if(canary){
                    OPM$.lcm.upgradeCampaign.upgradeCampaignController.postRollback();
                }
            }).always(function () {
                selector.activity(false);
                if($(".an-cluster-container").is(":visible")){
                    var json = JSON.parse($(".an-cluster-container").attr('data-set'));
                    json.forceRefresh = true;
                    OPM$.cloudMap.cloudMapController.renderCloudMap(json);
                }

        }).fail(function (data) {
            if (data.responseJSON.result === "confirm" && data.responseJSON.action === "override") {
                MSG$.confirm({
                    statement: 'Confirmation',
                    question: data.responseJSON.errorMessage,
                    yes: function () {
                        var override = true;
                        performRollbackCnf(selector, chartDetails, selChart, selCluster, override);
                    }
                });
            }
        });
    }

    function pickCluster(e) {
        e.stopPropagation(); e.preventDefault();
        if($('#pickClusterDlg').length === 0) {
            $(e.target).closest('button').first().prop('disabled', true);
            var clusterBtn = 'selectClusterBtn'
            if($(e.target).offsetParent().offsetParent().attr("id") === 'snapshotDialog')
                clusterBtn = 'selectSnapshotClusterBtn';
            $(e.target).closest('button').first().activity();
            OPM$.DzAndCluster.K8s.K8Service.getAllInstances()
                .done(function (data) {
                    $(e.target).closest('button').first().prop('disabled', false);
                    $(e.target).closest('button').first().activity(false);
                    if($(e.target).offsetParent().attr("id") === "NFConfigDialog"){
                        addRepoData(data)
                    }
                    else{
                        var html= Handlebars.templates['lcm_federations_pickClusterDlg']();
                        if($(e.target).offsetParent().offsetParent().attr("id") === "snapshotDialog"){
                            $('#pickClusterDlg').addClass('snapshot-cluster')
                            $("#snapshotDialog").append(html);

                        }
                        else {
                            $('body').append(html);
                        }

                    $('#pickClusterDlg').draggable({
                        handle: "header"
                    }).position({
                            my: "",
                            at: "",
                            of: "body"
                    });
                    GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#pickClusterDlg'));     
                    var clusterBtnRect =  $("#"+clusterBtn)[0].getBoundingClientRect();
                    var left = clusterBtnRect.right - $('#pickClusterDlg').width();
                    var top = clusterBtnRect.top + clusterBtnRect.height;
                    if($(e.target).offsetParent().offsetParent().attr("id") === "snapshotDialog"){
                        //Update these values with calculated val
                        $('#pickClusterDlg').css({'left': -353, 'top' : 85});
                        if($(window).height() < 700)
                            $('#pickClusterDlg').css('top', '0px');
                        if($(window).width() < 650)
                            $('#pickClusterDlg').css('left', '0px');
                    }else {
                        $('#pickClusterDlg').css({'left': left, 'top' : top, 'float' : 'left', 'position' : 'relative'});
                        if($(window).height() < 700)
                            $('#pickClusterDlg').css('top', '0px');
                        if($(window).width() < 650)
                            $('#pickClusterDlg').css('left', '0px');
                    }
                    OPM$.lcm.lcmController.loadTree(data, 'clusters-tree-content', OPM$.lcm.federations.federationsController.onClusterClick);
                   
                    if($(e.target).offsetParent().offsetParent().attr("id") === 'snapshotDialog')
                        GCM$.accessibility.accessibilityCommon.setLastActiveEle('pickClusterDlg',$('#selectSnapshotClusterBtn'));
                    else
                        GCM$.accessibility.accessibilityCommon.setLastActiveEle('pickClusterDlg',$('#selectClusterBtn'));
                }});
        }
    }

    function addRepoData(data){
        OPM$.repoManagement.repoService.getAllChartRepos()
        .done(function (repoData) {
            var html = Handlebars.templates['lcm_federations_pickClusterDlg'](repoData);
            $("#NFConfigDialog").append(html);
            $('#selectNfRepoNameDiv').show();
            $('#pickClusterDlg').draggable({
                handle: "header"
            }).position({
                my: "right",
                at: "right",
                of: "body"
            });
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#pickClusterDlg'));
            $('#pickClusterDlg').css({'left' : '40vw', 'top' : '10vh'});
            $('#pickClusterDlg').addClass('instantiate-cluster')
            OPM$.lcm.lcmController.loadTree(data, 'clusters-tree-content', OPM$.lcm.federations.federationsController.onClusterClick);
            OPM$.repoManagement.repoController.singleRepoAutoSelect(repoData.repoList, $('#selectNfRepoName'))
            GCM$.accessibility.accessibilityCommon.setLastActiveEle('pickClusterDlg',$('#instantiateIcon'));
        });
    }

    function onClusterClick(e) {
        var target = $(e.target);
        e.stopPropagation();
        if(target.closest('li').hasClass('leaf') && !target.closest('li').hasClass('non-clickable')){
            $('#clusters-tree-content li').removeClass('an-selected');
            target.closest('li').addClass('an-selected');
            if(target.offsetParent().offsetParent()[0].id === 'NFConfigDialog')
                onSelectRepoName(e);
            else
                $('#pickClusterBtn').attr('disabled', false);
        }
    }

    function onSelectRepoName(e){
        if($("#selectNfRepoName").val() !== "" &&
            $("#clusters-tree-content").find('li.leaf.an-selected').length === 1)
            $('#pickClusterBtn').attr('disabled', false);
        else
            $('#pickClusterBtn').attr('disabled', true);
    }

    function onSelectCluster(e, nfConfig) {
        var clusterBtn = 'selectClusterBtn'
        if($('#pickClusterDlg').offsetParent().attr("id") === "NFConfigDialog"){
            var repoName = $('#selectNfRepoName').val();
        }
        if($('#pickClusterDlg').offsetParent().attr("id") === "snapshotDialog"){
            clusterBtn = 'selectSnapshotClusterBtn'
        }
        var el$ = $('#clusters-tree-content').find('li.an-selected');
        var selectedClusterName = el$.attr('data-name');
        $('#'+clusterBtn+' span').text(selectedClusterName);
        selectedCluster.id = el$.attr('data-id');
        selectedCluster.dzId = el$.parent().closest('li').attr('data-id');
        selectedCluster.type = el$.closest('li.branch').attr('data-type');
        GCM$.common_functions.closeDialog('pickClusterDlg');

        if($('#'+clusterBtn+' span').offsetParent().offsetParent().attr("id") === "snapshotDialog"){
            OPM$.NFConfig.snapshotController.clusterSelected(selectedCluster);
        }
        else if($('#pickClusterDlg').offsetParent().attr("id") === "NFConfigDialog"){
            repoClusterVal.repoName = repoName;
            repoClusterVal.selectedCluster = selectedCluster;
            repoClusterVal.selectedCluster.clusterName = el$.attr('data-name');
            var type = $("#NFConfigDialog").hasClass('cn-simplified') ? 'simplifiedConfig': 'snapshotConfig';
            OPM$.lcm.lcmController.openLcmDialog(e, type)
        }
        else if(clusterBtn === "selectClusterBtn" && $("#selectClusterBtn").offsetParent().offsetParent().attr('id') === 'lcmDlg'
        && $("#lcmDlg").hasClass('cn-lcm-create-config')){
            $("#addChartBtn").prop('disabled', false);
        }
        else{
            VALIDATION$.validateOnInputChange($('#values-output'), $('#fedButtons button'), undefined, undefined, undefined, true);
        }
    }

    function launchDryRun() {
        if($('#lcmDlg').hasClass('cn-lcm-instantiate-config')){
            launchBulkInstallDryRun();
        }
        else{
            var format;

            var jsonData = FORM$.getData('values-output'),
                chartDetails = getReleaseNameAndNamespace(jsonData);

            if($('#parentFormContainer').hasClass('cn-expert-mode')){
                jsonData.dataContent = GCM$.common_functions.editor["yamlEditor"].getValue();
                format = "yaml";
            }

            var isUpgrade = false;
            if(!$('#lcmDlg').hasClass('cn-lcm-install')){
                isUpgrade = true;
            }
            if(isValid(chartDetails)) {
                $("#dryRunBtn").activity({width:2});
                OPM$.lcm.federations.federationsService.getDryRunResult(jsonData, selectedCluster, selectedChart, chartDetails, isUpgrade, format)
                    .done(function (data) {
                        _.assign(data, {
                            title: "Dry Run",
                            dryRun: true
                        });
                        var html = Handlebars.templates['lcm_federations_dryRun'](data);
                        $('body').append(html);
                        $("#dryRunDialog").hide().fadeIn().draggable({
                            handle: "header"
                        }).position({
                            my: "center",
                            at: "center",
                            of: "body"
                        });
                        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#dryRunDialog'));
                    }).always(function (data) {
                        $("#dryRunBtn").activity(false);
                });
            }
        }
    }

    function launchBulkInstallDryRun() {
        var issuOption=$('#issuOptions').val();
        var issu = false;
        var dryRun = true;
        var rollbackPolicy = null;
        switch(issuOption){
            case 'issu-False': break;
            case 'issu-rollbackOnFailure': { issu= true; rollbackPolicy= 'rollbackOnFailure'; break;} 
            case 'issu-pauseOnFailure': { issu= true; rollbackPolicy= 'pauseOnFailure'; break;} 
        }
            $("#dryRunBtn").activity({width:2});
            OPM$.lcm.federations.federationsService.bulkInstallFeds(repoClusterVal, instantiateData.name, false, instantiateData, issu, rollbackPolicy, false, dryRun)
                .done(function (data) {
                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                }).always(function (data) {
                    $("#dryRunBtn").activity(false);
            });
    }

    function getReleaseNameAndNamespace(data) {
        var chartDetails = {
            releaseName: '',
            namespace: ''
        };
        _.forEach(data.forms[0].fieldsets[0].fields, function(field){
            if(field.name === "releaseName"){
                chartDetails.releaseName = field.value;
            } else if(field.name === "namespaces"){
                chartDetails.namespace = field.value;
            }
        });
        return chartDetails;
    }

    function isValid(chartDetails) {
        if((typeof chartDetails.namespace !== "undefined" && chartDetails.namespace !== "" )
        && (typeof chartDetails.releaseName !== "undefined" && chartDetails.releaseName !== "")){
            if(chartDetails.namespace.indexOf("_") < 0 && chartDetails.releaseName.indexOf("_") < 0) {
                return true;
            } else {
                MSG$.showErrorMsg({status: 'Error', content: 'Namespace and ReleaseName cannot contain underscore'});
                return false;
            }
        }
        else {
            MSG$.showErrorMsg({status: 'Error', content: 'Namespace and ReleaseName cannot be empty'});
            return false;
        }
    }

    function onDependencyListClick(e) {
        var target = $(e.target);
        e.stopPropagation();
        $('#dependencyPickerDlg tr').removeClass('an-selected');
        target.closest('tr').addClass('an-selected');
        $('#selectPaasBtn').attr('disabled', false);
    }

    function onSelectPaasDependency() {
        //Assign the selected values to form's VUE data and re-create the form

        var td = $('#dependencyPickerDlg tr[class="an-selected"]').find('td'),
            depAttributes = JSON.parse($('#dependencyPickerDlg tbody').attr('data-dep'));

        var jsonData= JSON.parse($(td).attr('data-values'));
        OPM$.lcm.federations.federationsService.retrievePaasValues(jsonData, depAttributes)
            .done(function (res) {
                var data = FORM$.getData('values-output');
                _.forEach(res.attributes, function (attr) {

                    var $el = $("#values-output").find('input[data-xpath="'+attr.xpath +'"]'),
                        fbPath = $($el).attr('data-fbpath') + '.value';
                    _.set(data, fbPath, attr.value);
                });
                GCM$.common_functions.closeDialog('dependencyPickerDlg');
            });
    }

    function showStatusDetails(e) {
        var status = JSON.parse($(e.target).attr('data-status')),
            html = Handlebars.templates['lcm_federations_dependencyStatus'](status);
        $(html).appendTo('body').show().position({
            my: "left top",
            at: "right center",
            of: $(e.target),
            collision: "flipfit"
        })
    }

    function contextualClusterSelection(cluster) {
        selectedCluster.dzId = cluster.dzId;
        selectedCluster.id = cluster.id;
        selectedCluster.type = cluster.type;
        if(typeof cluster.name !== "undefined" && cluster.name !== '') {
            $('#selectClusterBtn span').text(cluster.name);
        }

        //OPM$.lcm.federations.federationsController.launchChartMuseum();
    }

    function copyToClipboard(id) {

        var elem = document.getElementById(id);
        var targetId = "_hiddenId", target;

        target = document.getElementById(targetId);
        if(!target) {
            target = document.createElement("textarea");
            target.style.position = "absolute";
            target.style.left = "-9999px";
            target.style.top = "0";
            target.id = targetId;
            document.body.appendChild(target);
        }
        target.textContent = elem.textContent;

        var currentFocus = document.activeElement;
        target.focus();
        target.setSelectionRange(0, target.value.length);

        var succeed;
        try {
            succeed = document.execCommand("copy");
        } catch (e){
            succeed = false;
        }

        if(currentFocus && typeof currentFocus.focus === "function"){
            currentFocus.focus();
        }

        target.textContent = "";
        if(succeed){
            MSG$.showInfoMsg({status: 'Success', content: 'Contents copied to clipboard!'});
        } else {
            MSG$.showErrorMsg({status: 'Error', content: 'Error copying! Please use ctrl+A to copy'});
        }
    }

    function formPostProcessing(tab) {

        var selectedTab = typeof tab !== "undefined" ? tab : $('#filterSelection').val(),
            fields = $('#lcmDlg #values-output form').find('input, textarea, select');

        if(selectedTab === "required") {
            _.forEach(fields, function (field) {
                $(field).closest('label').removeClass('non-required-field');
                if ($(field).attr('required') !== 'required' && !$(field).closest('label').hasClass('an-fb-exposed')) {
                    $(field).closest('label').addClass('non-required-field');
                }
                if($(field).closest('label').hasClass('an-deleted')){
                    $(field).hide();
                }
            });
            $('fieldset.non-required').addClass('non-required-field');
        } else if (selectedTab === "all"){
            _.forEach(fields, function (field) {
                $(field).closest('label').removeClass('non-required-field');
                if ($(field).attr('required') !== 'required') {
                    $(field).closest('label').removeClass('non-required-field');
                }
                if($(field).closest('label').hasClass('an-deleted')){
                    $(field).hide();
                }
            });
            $('fieldset.non-required').removeClass('non-required-field');
        } else if (selectedTab === "differences"){
            _.forEach(fields, function (field) {
                $(field).closest('label').removeClass('non-required-field');
                if (!$(field).closest('label').hasClass('an-differences')) {
                    $(field).closest('label').addClass('non-required-field');
                }
                if($(field).closest('label').hasClass('an-deleted')){
                    $(field).show();
                }
            });
            $('fieldset.non-required').removeClass('non-required-field');
        }
        else if (selectedTab === "chartDifferences"){
            _.forEach(fields, function (field) {
                $(field).closest('label').removeClass('non-required-field');
                if (!$(field).closest('label').hasClass('an-differences')) {
                    $(field).closest('label').addClass('non-required-field');
                }
            });
        }

        if($('#lcmDlg').hasClass('cn-lcm-instantiate-config')) {
            VALIDATION$.validateOnInputChange($('#values-output'), $("#instantiateSaveChartBtn"), undefined, undefined, undefined,true);
        }
        else{
            VALIDATION$.validateOnInputChange($('#values-output'), $('#fedButtons button'), undefined, undefined, OPM$.lcm.federations.federationsController.checkIfClusterIsSelected, true);
        }

        $('#values-output').off("click", "button.an-combobox-toggle").on("click", "button.an-combobox-toggle", GCM$.common_functions.onClickComboBox); // combo box
        $('#values-output').find(".faux-dropdown").off('click').on('click', renderExistingForm);
        $('#values-output').find('.an-icon-dependency').off('click').on('click', launchDependencyPicker);
    }

    function getAllChartVersions(e) {

        var el$ = $(e.target),
            selectedRepo = $("#lcmSelectedRepo").val(),
            chartKeyword = $("#NFTypeCombo").val();

        if($(el$).attr('aria-selected', false)) {
            callRenderAllChartVersions(selectedRepo, chartKeyword);
        } else if ($(el$).attr('aria-selected', true)) {
            $('#museum-tree-content').activity();
            if(selectedRepo !== "") {
               getLatestCharts();
            } else {
                $('#museum-tree-content').empty();
            }
        }
    }

    function callRenderAllChartVersions(repoName, chartKeyword ,chartName, chartVersion, refresh) {
        $('#museum-tree-content').activity();
        $("#chartMuseumSection").addClass("an-selector-loading");

        OPM$.lcm.federations.federationsService.renderAllChartVersions(repoName, chartKeyword,chartName, chartVersion, refresh)
            .done(function (data) {
                var html = Handlebars.templates['lcm_federations_chartMuseumTable'](data);

                $('#museum-tree-content').empty().append(html);
                $("#refreshChartsBtn").prop('disabled', false);
                $("#refreshChartsBtn").attr('title', new Date(parseInt(data.timestamp)));
                //$('#showAllVersionsBtn').attr('title', 'Show latest charts').find("an-icon").removeClass('an-icon-eye-plus').addClass('an-icon-clear-filter2');
                if($('#chartMuseumDlg').length > 0 && !($('#chartMuseumDlg').hasClass('updateConfigNF'))) {
                    $('#chartMuseumDiv ul').off('click').on('click', OPM$.lcm.federations.federationsController.onClickChartsList);
                } else if($('#chartMuseumDlg').length > 0 && $('#chartMuseumDlg').hasClass('updateConfigNF')){
                    $('#chartMuseumDiv ul').off('click').on('click', OPM$.lcm.federations.federationsController.onSelectChart);
                }
                else{
                    $('#lcmDlg #museum-tree-content ul').off('click').on('click', OPM$.lcm.federations.federationsController.onSelectChart);
                }
                GCM$.accessibility.listAccessibility.makeListKeyNav($('#tableData'));

                OPM$.lcm.lcmController.filterData();

            }).always(function () {
            $('#museum-tree-content').activity(false);
            $("#chartMuseumSection").removeClass("an-selector-loading");
        });
    }

    function getLatestCharts (refresh) {
        var selectedRepo = $("#lcmSelectedRepo").val(),
            chartKeyword = $("#NFTypeCombo").val();

        $('#museum-tree-content').activity();
        $("#chartMuseumSection").addClass("an-selector-loading");

        OPM$.lcm.federations.federationsService.getChartsList(selectedRepo, refresh)
            .done(function (data) {
                var html = Handlebars.templates['lcm_federations_chartMuseumTable'](data);
                $('#museum-tree-content').empty().append(html);
                $("#refreshChartsBtn").prop('disabled', false);
                $("#refreshChartsBtn").attr('title', new Date(parseInt(data.timestamp)));
                //$('#showAllVersionsBtn').removeClass('an-icon-clear-filter2').addClass('an-icon-eye-plus').attr('title', 'Show all versions of charts');
                if($('#chartMuseumDlg').length > 0 && !($('#chartMuseumDlg').hasClass('updateConfigNF'))) {
                    $('#chartMuseumDiv ul').off('click').on('click', OPM$.lcm.federations.federationsController.onClickChartsList);
                } else if($('#chartMuseumDlg').length > 0 && $('#chartMuseumDlg').hasClass('updateConfigNF')){
                    $('#chartMuseumDiv ul').off('click').on('click', OPM$.lcm.federations.federationsController.onSelectChart);
                }
                else{
                    $('#lcmDlg #museum-tree-content ul').off('click').on('click', OPM$.lcm.federations.federationsController.onSelectChart);
                }
                GCM$.accessibility.listAccessibility.makeListKeyNav($("#tableData"));

                OPM$.lcm.lcmController.filterData();
            }).always(function () {
            $('#museum-tree-content').activity(false);
            $("#chartMuseumSection").removeClass("an-selector-loading");
        });
    }

    function checkIfClusterIsSelected() {
        var text = $('#lcmDlg #selectClusterBtn').find('span').text();
        if(text === "Select Cluster..."){
            return false;
        } else {
            return true;
        }
    }

    function demoCanaryUpgrade() {
        $(".cn-step-one").activity();
        $("#nextCanaryBtn").prop("disabled", true);

        setTimeout(function() { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
            $(".cn-step-one").activity(false).css({"background": "#00b300"});
            $("#canaryRollback").prop("disabled", false);
        }, 5000);

        $("#nextCanaryBtn").prop("disabled", false);
    }

    function updateStatus(data) {
        var config = {
            clusterName: data.clusterName,
            dzName: data.dzName,
            releaseName: typeof data.releaseName !== "undefined" ? data.releaseName : undefined,
            task: data.task,
            timestamp: data.timestamp,
            data: data.content,
            consoleTables: data.data,
            helmResponses: data.helmResponses
        };
        OPM$.lcm.consoleTabs.tabsController.openConsoleTab(config);
        OPM$.app.resetLogoutTime()
    }

    function updateFedInLcm(data) {
        var details = getReleaseNameAndNamespace(FORM$.getData('values-output'));
        if(selectedCluster.dzId === data.deploymentZoneId && selectedCluster.id === data.clusterId
           && details.releaseName === data.releaseName) {

            var html = Handlebars.templates['lcm_federations_lcmFederation'](data.content);
            $(".cn-embedded-fed-view").empty().append(html).addClass('cn-cluster-fullscreen');

            OPM$.cloudMap.cloudMapController.cloudMapBindings();
            $(".cn-embedded-fed-view").find(".an-counter").off("click").on("click", function(event) {
                event.stopPropagation();
                $(this).closest(".cn-embedded-fed-view").toggleClass("cn-cluster-fullscreen");
            });
            //Replacing the current chart name with the updated one
            var currentChart = data.content.cnf.tooltip.chart;
            $('#lcmDlg #currentChartLabel div span').text(currentChart);
            $('#lcmDlg #currentChartLabel').prop('tabindex', -1);
            $('#lcmDlg #currentChartLabel div span').attr('title', currentChart);
        }
    }

    function getPackageMarkdownFile(url) {

        $.ajax({
            url: url,
            type: 'GET',
            dataType: "text",
            success: function(data) {
                var markdown = new window.markdownit();
                var html = markdown.render(data);

                $("#values-output").empty().append("<div tabindex='0' role='presentation' aria-label='"+ data+ "' class='an-markdown'>" + html + "</div>");
            }
        });
    }
    
    function toggleExpertMode() {
        var treeContent = $("#lcmDlg").hasClass('cn-lcm-instantiate-config') ? $("#prereq-tree-content") : $("#helm-tree-content"),
            target = $(treeContent).find('li.an-selected'), format, dataContent,
            chartVal = $(target).find('a').attr('data-chartval'),
            nfAndPaasInstanceId = (chartVal !== "" && typeof chartVal !== 'undefined') ?  JSON.parse(chartVal).nfAndPaasInstanceId: undefined;

        if ((target.closest('li').find('a').text().indexOf("values") >= 0 && target.closest('li').find('a').text().indexOf(".yaml") >= 0) ||
                $("#lcmDlg").hasClass('cn-lcm-instantiate-config')) {
            if(!$('#parentFormContainer').hasClass('cn-expert-mode')){
                format = "yaml";
            } else {
                format = "";
                dataContent = GCM$.common_functions.editor["yamlEditor"].getValue();
            }
            var formData = FORM$.getData('values-output'),
                details = getReleaseNameAndNamespace(formData),
                upgradeDetails = {
                    namespace: typeof details.namespace !== "undefined" ? details.namespace : '',
                    relName: typeof details.releaseName !== "undefined" ? details.releaseName : ''
                };

            formData.dataContent = typeof dataContent !== "undefined" ? dataContent : formData.dataContent;

            // if(isValid(details)) {
                $('#values-output').activity();
                OPM$.lcm.federations.federationsService.convertValues(formData, selectedChart, upgradeDetails.relName, upgradeDetails.namespace, format, nfAndPaasInstanceId)
                    .done(function (data) {
                        updateForm(data, format);
                        if(format === "yaml")
                            $('#expertIcon').attr('aria-pressed', 'true');
                        else
                            $('#expertIcon').attr('aria-pressed', 'false');
                    }).always(function () {
                    $("#values-output").activity(false);
                });
            //}

        } else {
            var markDownFile = true;
            renderHelmChart(target.closest('li').attr('data-name'), target.closest('li').attr('data-type'), selectedChart, undefined, undefined, markDownFile);
        }
    }
    
    function importValues() {
        if( $("#importValuesDlg").length > 0){
            $("#importValuesDlg").detach();
        }
        var html = Handlebars.templates["lcm_federations_importValues"]();
        $('body').append(html);

        $("#importValuesDlg").draggable({
            handle: "header"
        }).position({
            my: "right-100 top",
            at: "right bottom",
            of: $("#importIcon")
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#importValuesDlg'));
        GCM$.common_functions.inputFile();
        VALIDATION$.validateOnInputChange($('#importValuesForm'), $('#importButton'), undefined, undefined, undefined, true);

        $("#importButton").on('click', doImportValues);

    }

    function doImportValues(e) {
        e.stopPropagation();e.preventDefault();
        var format,
            data = new FormData($('#importValuesForm')[0]);

        if($('#parentFormContainer').hasClass('cn-expert-mode')){
            format = "yaml";
        } else {
            format = "";
        }

        $('#importValuesDlg').activity();
        $.ajax({
            url: '/opm/cnf/importValuesFile/'+selectedChart.repoName+'/'+selectedChart.name+'/'+selectedChart.version+'?format='+format,
            data: data,
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data) {
                MSG$.showInfoMsg({status: 'Success', content: 'Values imported successfully'});
                $('#importValuesDlg').activity(false);
                GCM$.common_functions.closeDialog('importValuesDlg');

                updateForm(data, format);
            },
            error: function (res) {
                MSG$.showErrorMsg({status: 'Error', content: 'Import Failed'});
                $('#importValuesDlg').activity(false);
            }
        });
    }
    
    function launchExportDialog() {
        if( $("#exportValuesDlg").length > 0){
            $("#exportValuesDlg").detach();
        }
        var html = Handlebars.templates["lcm_federations_exportValues"]();
        $("body").append(html);

        $("#exportValuesDlg").draggable({
            handle: "header"
        }).position({
            my: "right-100 top",
            at: "right bottom",
            of: $("#exportIcon")
        });
        $('#exportButton').off().on('click', OPM$.lcm.federations.federationsController.exportValues);
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#exportValuesDlg'));
    }
    
    function exportValues() {
        var format,
            formData = FORM$.getData('values-output'),
            fileName = $('#exportFilename').val();

        if($('#parentFormContainer').hasClass('cn-expert-mode')){
            format = "yaml";
        } else {
            format = "";
        }

        $("#values-output").activity();
        AJAX$({
            type: "POST",
            contentType: "application/json",
            url: '/opm/cnf/exportValuesData/?format='+format,
            data: JSON.stringify(formData)
        }).done(function (data) {
            GCM$.common_functions.downloadTextAsFile(fileName, data);
            GCM$.common_functions.closeDialog("exportValuesDlg");
        }).always(function () {
            $("#values-output").activity(false);
        }).fail(function () {
            MSG$.showErrorMsg({status: 'Error', content: 'Import Failed'});
        })
    }

    function getChartDetails() {
        var data = {};
        _.assign(data, selectedChart, selectedCluster, getReleaseNameAndNamespace(FORM$.getData('values-output')));
        return data;
    }

    function rollbackCanary(canary) {
        var chartDetails = getReleaseNameAndNamespace(FORM$.getData('values-output')),
            selector = $("#canarySteps");
        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to rollback '+chartDetails.releaseName+'?',
            yes: function () {
                performRollbackCnf(selector, chartDetails, selectedChart, selectedCluster, undefined, canary);
            }
        });

    }

    function validateKeywordFilter(e) {
        if($("#lcmSelectedRepo").val() !== "") {
            $("#filterListByKeyword").prop("disabled", false);
        } else {
            $("#filterListByKeyword").prop("disabled", true);
        }
    }

    function getClusterData(e){
        var el$ = $(e.target).closest('li');
        $('#clusterContainerList ul li').removeClass('an-selected');
        el$.addClass('an-selected');

        OPM$.lcm.federations.federationsService.renderPrerequisites('cnhelm-vrel','fed-upf','1.0.0-9-sym').done(function(data){
            data.instantiateConfig = true;
            var html = Handlebars.templates['lcm_federations_prerequisites'](data);
            $('#prerequisite-recipe').show().empty().append(html);
        })

        //loadPrerequisitesRecipe('cnhelm-vrel', 'fed-upf', '1.0.0-9-sym')
        callInstantiatePrerequisiteHandler()
    }

    function toggleHelmChartView() {
        $("#helmTreeContent").toggle();

        if($("#helmTreeContent").css('display') == 'block'){
            $('#pinHelmBtn').focus();
            if(!($('#pinHelmBtn').hasClass('helmChartPinned')))
                GCM$.accessibility.dialogAccessibility.trapFocus($('#helmTreeContent'));
                $("#helmTreeContent").on('keyup', function (e) {        
                    if (e.keyCode === GCM_KEY$.ESCAPE) { //Added escape handler separately since this is a div (not a dialog).
                        e.stopPropagation();
                        $("#helmTreeContent").hide();
                        $('#helmChartToggleBtn').focus();
                    }
                });
            $('#helmChartToggleBtn').attr('aria-pressed', 'true')
        }
        else if($("#helmTreeContent").css('display') == 'none') {
            $('#helmChartToggleBtn').focus();
            $('#helmTreeContent').off('keydown');
            $('#helmChartToggleBtn').attr('aria-pressed', 'false')
        }

    }

    function callInstantiatePrerequisiteHandler(){
        // $('#prerequisite-recipe').off("click", "a.cn-prereq-name").on("click", "a.cn-prereq-name", function(e) {
        //     var preReqChartName = $(e.target).text().trim();
        //
        //     callRenderAllChartVersions('cnhelm-vrel', preReqChartName);
        // });

        $('#prerequisite-recipe').off("click", "a.cn-prereq-version").on("click", "a.cn-prereq-version", function(e) {
            var preReqChartName = $(e.target).closest(".cn-prereq-name-version").find(".cn-prereq-name").text().trim(),
                prereqChartVersion = $(e.target).text().trim();
            selectedChart.repoName = 'cnhelm-vrel';
            selectedChart.name = preReqChartName;
            selectedChart.version = prereqChartVersion;
            //callRenderAllChartVersions('cnhelm-vrel', preReqChartName, prereqChartVersion);

            renderChartsTree('cnhelm-vrel', preReqChartName, prereqChartVersion);
        });
    }

    function callPrerequisiteHandler(e) {
        var target = $(e.target);
        e.stopPropagation();
        if(target.closest('li').hasClass('leaf')) {
            target.closest('ul.an-tree').find('li.an-selected').removeClass('an-selected');
            target.closest('li').addClass('an-selected');
            var targetValues = target.closest('li').find('a').text().split(" - ");
            selectedChart.repoName = 'cnhelm-vrel';
            selectedChart.name = targetValues[0];
            selectedChart.version = targetValues[1];

            prereqTraverse.curLeaf = target.closest('li');
            prereqTraverse.curBranch = prereqTraverse.curLeaf.closest("li.branch");
            toggleNextBtn()
            //callRenderAllChartVersions('cnhelm-vrel', preReqChartName, prereqChartVersion);
            renderChartsTree('cnhelm-vrel', targetValues[0], targetValues[1]);
        }
    }

    function renderPrerequisitesList(group,preReqData) {
        if(group.name!==undefined){
            originalFormData = {};
            olderSelectedChart = {};
            instantiateData = preReqData;
            instantiateDetails.group = group;
            OPM$.lcm.lcmController.loadTree(preReqData, 'prereq-tree-content', OPM$.lcm.federations.federationsController.onBulkInstallFedClick, undefined, 'update', true);
            $('#helmApplyBtn').prop('disabled', false);
            $('#stopBulkInstallBtn').prop('disabled', false);
            GCM$.common_functions.closeDialog('NFConfigDialog');
        }else {
            OPM$.lcm.federations.federationsService.createNfConfigPrereq().done(function (data) {
                OPM$.lcm.lcmController.loadTree(data, 'prereq-tree-content' );
                //Clearing 'prereq-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
                Cookies.set('prereq-tree-content', {});
                //var html = Handlebars.templates['lcm_federations_prerequisites'](data);
                //$('#prerequisite-recipe').show().empty().append(html);
                prereqTraverse.curBranch = '';
                prereqTraverse.curLeaf = '';
                $("#backBtn").prop('disabled', false)
                nextPrerequisite()

                //Remove this after updating the api
                $('#selectClusterBtn').attr('disabled', false);
            })
        }
    }

    function nextPrerequisite() {
        if(prereqTraverse.curBranch === '' || prereqTraverse.curBranch === undefined) {
            prereqTraverse.curBranch = $("#prereq-tree-content").find("li.branch")[0];
            prereqTraverse.curLeaf = $("#prereq-tree-content").find("li.leaf")[0];
            if($(prereqTraverse.curBranch).hasClass("an-collapsed"))
                $($(prereqTraverse.curBranch).children()[0]).trigger('click');
            $($(prereqTraverse.curLeaf).find('a')[0]).trigger('click');
        }else {
            var nextLeaf = $(prereqTraverse.curLeaf).next()[0];

            if(nextLeaf!= undefined){
                prereqTraverse.curLeaf = nextLeaf
            }
            else{
                var nextBranch = $(prereqTraverse.curBranch).next()[0];
                var nextLeaf = $(nextBranch).find("li.leaf")[0];
                prereqTraverse.curBranch = nextBranch;
                prereqTraverse.curLeaf = nextLeaf;
                if($(prereqTraverse.curBranch).hasClass("an-collapsed"))
                    $($(prereqTraverse.curBranch).children()[0]).trigger('click');
            }
            $($(prereqTraverse.curLeaf).find('a')[0]).trigger('click');
        }
        toggleNextBtn()
    }

    function previousPrerequisite() {
        var prevLeaf = $(prereqTraverse.curLeaf).prev()[0];
        if(prevLeaf != undefined){
            prereqTraverse.curLeaf = prevLeaf
            $($(prereqTraverse.curLeaf).find('a')[0]).trigger('click');
        }else{
            var prevBranch = $(prereqTraverse.curBranch).prev()[0];
            if(prevBranch !=undefined){
                prereqTraverse.curBranch = prevBranch;
                var len = $(prereqTraverse.curBranch).find("li.leaf").length
                prereqTraverse.curLeaf = $(prereqTraverse.curBranch).find("li.leaf")[len-1]
                $($(prereqTraverse.curLeaf).find('a')[0]).trigger('click');
            }else{
                OPM$.lcm.NFConfigLcm.configController.renderCreatePane();

            }
        }
        toggleNextBtn()
    }

    function toggleNextBtn() {
        if(($(prereqTraverse.curLeaf).next()[0] === undefined) && ($(prereqTraverse.curBranch).next()[0] === undefined))
            $("#nextBtn").prop('disabled', true)
        else if($("#nextBtn").prop('disabled'))
            $("#nextBtn").prop('disabled', false)
    }

    function getRepoClusterVal(){
        return repoClusterVal;
    }

    function bulkInstallFeds() {
        var issuOption=$('#issuOptions').val();
        var issu = false;
        var rollbackPolicy = null;
        var clusterName= $("#selectClusterBtn span").first().text();
        switch(issuOption){
            case 'issu-False': break;
            case 'issu-rollbackOnFailure': { issu= true; rollbackPolicy= 'rollbackOnFailure'; break;} 
            case 'issu-pauseOnFailure': { issu= true; rollbackPolicy= 'pauseOnFailure'; break;} 
        }
        var issuPolicy = '';
        if (issu) issuPolicy = '<br/> Rollback Policy: '+rollbackPolicy;
        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to apply following changes to live network?' 
            + '<br/> Cluster: '+clusterName
            + '<br/> Configuration set: ' + instantiateData.name 
            + '<br/> In-service upgrade: '+ issu 
            + issuPolicy,
            yes: function () {
                $('#federationsLcmForm').activity();
                
                OPM$.lcm.federations.federationsService.bulkInstallFeds(repoClusterVal, instantiateData.name, false, instantiateData, issu, rollbackPolicy).done(function (data) {
                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                    if(data.data !== undefined && data.data !== null &&
                        data.data.fedTimeout !== undefined && data.data.fedTimeout !== null){
                        var fedTimeout = data.data.fedTimeout;
                        if(typeof fedTimeout === 'number')
                            OPM$.app.updateMaxInactivity(fedTimeout + 900) //15 mins buffer to longest fed timeout set by user
                        else
                            OPM$.app.updateMaxInactivity(parseInt(fedTimeout) + 900)
                     } 
                }).fail(function (error) {
                    if (error.responseJSON.result === "confirm") {
                        MSG$.confirm({
                            statement: error.responseJSON.errorCode,
                            question: error.responseJSON.errorMessage,
                            yes: function () {
                                $('#federationsLcmForm').activity()
                                var override, abandon;
                                if(error.responseJSON.order === 0){
                                    override = true;
                                    abandon = error.responseJSON.additionalData.split('=')[1];
                                }
                                else if(error.responseJSON.order === 1){
                                    abandon = true;
                                    override = error.responseJSON.additionalData.split('=')[1];
                                }
                                OPM$.lcm.federations.federationsService.bulkInstallFeds(repoClusterVal, instantiateData.name, override, instantiateData, issu, rollbackPolicy, abandon).done(function (data) {
                                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                                    if(data.data !== undefined && data.data !== null &&
                                        data.data.fedTimeout !== undefined && data.data.fedTimeout !== null){
                                        var fedTimeout = data.data.fedTimeout;
                                        if(typeof fedTimeout === 'number')
                                            OPM$.app.updateMaxInactivity(fedTimeout + 900) //15 mins buffer to longest fed timeout set by user
                                        else
                                            OPM$.app.updateMaxInactivity(parseInt(fedTimeout) + 900)
                                     } 
                                }).always(function () {
                                    $('#federationsLcmForm').activity(false)
                                })
                            }
                        });
                    }
                }).always(function () {
                    $('#federationsLcmForm').activity(false)
                })
            }
        });
    }

    function stopBulkInstallation() {
        var issuOptionSelected = false;
        var confirmMessage = 'stop'
        if($("#issuOptions").val() === 'issu-rollbackOnFailure' || $("#issuOptions").val() === 'issu-pauseOnFailure'){
            issuOptionSelected = true;
            confirmMessage = 'abandon'
        }
        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to ' + confirmMessage + ' the bulk installation?',
            yes: function () {
                $('#federationsLcmForm').activity();
                OPM$.lcm.federations.federationsService.stopBulkInstallation(repoClusterVal, instantiateData.name, instantiateData, issuOptionSelected).done(function (data) {
                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                }).fail(function (data) {
                    if (data.responseJSON.result === "confirm") {
                        MSG$.confirm({
                            statement: 'Confirmation',
                            question: data.responseJSON.errorMessage,
                            yes: function () {
                                OPM$.lcm.federations.federationsService.stopIssuInstallation(repoClusterVal,instantiateData.name, instantiateData).done(function (data) {
                                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                                })},
                        });
                    }
                }).always(function () {
                    $('#federationsLcmForm').activity(false);
                })
            }
        });
    }

    function updateNFInstallStatus(data) {
        var currentChart = $("#prereq-tree-content").find('li').first().attr("data-name");
        if(selectedCluster.dzId === data.deploymentZoneId && selectedCluster.id === data.clusterId
            && currentChart === data.treeNode.branch[0].name) { //Filters by cluster and chartName
                if(data.rollbackPolicyForISSU == undefined || data.rollbackPolicyForISSU === null){
                    $("#issuOptions").prop('disabled', false);
                }
                else if(data.rollbackPolicyForISSU === 'pauseOnFailure' || data.rollbackPolicyForISSU === 'rollbackOnFailure'){
                    $("#issuOptions").prop('disabled', true);
                }
            $(".inprogress-activity").activity(false);
            OPM$.lcm.lcmController.loadTree(data.treeNode, 'prereq-tree-content', OPM$.lcm.federations.federationsController.onBulkInstallFedClick, undefined, 'update', true);
            //Clearing 'prereq-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
            Cookies.set('prereq-tree-content', {});
            _.forEach($("#prereq-tree-content").find("li.branch"), function (ele) {
                if($(ele).find("button.an-expandable").first().hasClass('an-icon-scroll_triangle_right_dark'))
                    $(ele).find("button.an-expandable").first().click();
            });
            $(".inprogress-activity").activity({width: 0.5});
            OPM$.app.resetLogoutTime();
        }
    }

    function pinChart(pinVal){
        if(pinVal === 'helm') {
            if ($('#pinHelmBtn').hasClass('helmChartPinned')) {
                $('#helmTreeContent').addClass('helm-tree-config').removeClass('an-dialog-pane-left')
                $('#pinHelmBtn').removeClass('helmChartPinned').attr('aria-pressed', 'false').focus();
                GCM$.accessibility.dialogAccessibility.trapFocus($('#helmTreeContent'));
            } else {
                $('#helmTreeContent').removeClass('helm-tree-config').addClass('an-dialog-pane-left')
                $('#pinHelmBtn').addClass('helmChartPinned').attr('aria-pressed', 'true').focus();
                $('#helmTreeContent').off('keydown')
            }
        }
        else if (pinVal === 'nf') {
            var appendList = ['chartMuseumHeader','chartMuseumSection','chartMuseumFooter']
            if ($('#pinNFBtn').hasClass('nfChartPinned')) {
                $("#nfChartPinned").css('display', 'none')
                $("#chartMuseumDlg").css('display' , 'block')
                // _.forEach(appendList, function (ele){
                //     $('#nfChartPinned').detach($("#"+ele))
                //     $("#chartMuseumDlg").append($("#"+ele))
                // })
                $('#nfChartPinned').detach($("#chartMuseumDiv"))
                $("#chartMuseumDlg").append($("#chartMuseumDiv"))
                $('#pinNFBtn').removeClass('nfChartPinned').attr('aria-pressed', 'false').focus();
                if(Cookies.get('chartMode'))
                    Cookies.remove('chartMode')
                $('#chartMuseumHeader button#closeBtn').css('display', 'block')
                if($('#lcmDlg').hasClass('cn-lcm-create-config')){
                    $('#pinnedChartCreateConfig').css('display', 'none');
                }
            } else {
                $("#nfChartPinned").css('display', 'flex');
                $("#chartMuseumDlg").css('display' , 'none');
                // _.forEach(appendList, function (ele){
                //     $('#nfChartPinned').append($("#"+ele))
                //     $("#chartMuseumDlg").detach($("#"+ele))
                // })
                $('#nfChartPinned').append($("#chartMuseumDiv"));
                $("#chartMuseumDlg").detach($("#chartMuseumDiv"));
                $('#pinNFBtn').addClass('nfChartPinned').attr('aria-pressed', 'true').focus();
                if(!Cookies.get('chartMode'))
                    Cookies.set('chartMode', 'pinned')
                $('#chartMuseumHeader button#closeBtn').css('display', 'none')
                if($('#lcmDlg').hasClass('cn-lcm-create-config')){
                    $('#pinnedChartCreateConfig').css('display', 'block');
                }
            }
        }
    }
    function newSelectChart(){
        selectedChart.repoName = $('#chartMuseumDiv').find('select').val();
        selectedChart.name = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-name').text();
        selectedChart.version = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-version').text();

        $('#selectInstallChartBtn span').val(selectedChart.name+'-'+selectedChart.version);
        $('#selectInstallChartBtn span').text(selectedChart.name+'-'+selectedChart.version);
        //GCM$.common_functions.closeDialog('chartMuseumDlg');

        renderChartsTree(selectedChart.repoName, selectedChart.name, selectedChart.version);
    }

    function onBulkInstallFedClick(e) {
        e.stopPropagation();
        if ($(e.target).closest('li').hasClass('leaf')) {
           if (checkFormClean()) {
                $('#prereq-tree-content').css('pointer-events', 'none');
                var target = $(e.target);
                originalFormData = {};
                olderSelectedChart = {};
                var span = target.closest('span');
                $('#prereq-tree-content li').removeClass('an-selected');
                target.closest('li').addClass('an-selected');
                var chartVal = target.closest('li').children('a').data('chartval')
                selectedChart.repoName = repoClusterVal.repoName;
                selectedChart.name = chartVal.chart;
                selectedChart.version = chartVal.version;
                instantiateDetails.namespace = chartVal.namespace;
                instantiateDetails.releaseName = chartVal.releaseName;
                instantiateDetails.nfAndPaasInstanceId = chartVal.nfAndPaasInstanceId;
                instantiateDetails.clusterId = selectedCluster.id;
                instantiateDetails.dzId = selectedCluster.dzId;
                instantiateDetails.branchName = $(e.target).closest('li.branch').data('name');
                renderChartsTree(selectedChart.repoName, selectedChart.name, selectedChart.version, undefined, undefined, true, instantiateDetails)
                $("#instantiateFedChartName").text(selectedChart.name + '-' + selectedChart.version);
                $("#instantiateFedChartName").attr('title',selectedChart.name + '-' + selectedChart.version);
                $("#instantiateFedChartName").prop('tabindex', 0);
                $("#instantiateFedNewChartName").text("Select New Chart...");
                $("#instantiateFedNewChartName").attr('title',"Select New Chart...");
                $('#instantiateSaveChartBtn').attr('title', 'Save updated chart values');
                $('#instantiateCancelBtn').attr('title', 'Discard updated chart values');
                $('#form-pane').removeClass('shared-param'); $('#form-pane').removeClass('overlay-param'); $('#form-pane').removeClass('helm-options');
                $("#selectSharedValues select").prop('disabled', true);
           } else {
                MSG$.confirm({
                    statement: 'Confirm',
                    question: 'There are unsaved changes in the form. Do you want to save the changes before switching to new chart?',
                    yes: function () {
                        saveChartHelper();
                    },
                    no: function () {
                        originalFormData = {};
                        onBulkInstallFedClick(e);
                    }
                });
           }
        } 
        if ($(e.target).hasClass('status-icon')){
            OPM$.DzAndCluster.dzAndClusterService.getAllInstances()
            .done(function(data){
                var dz = data.branch.find(function(val) {val.id = selectedCluster.dzId; return val;});
                showStatusfromInstallStatusIcon(e, dz.name);
            });
        }
        if($(e.target).hasClass('an-icon-update')){
            var el$ = $(e.target);
            selectedUpdateConfigNF.chartName = $(el$).closest('li').attr('data-chartName'),
            selectedUpdateConfigNF.version = $(el$).closest('li').attr('data-version');
            selectedUpdateConfigNF.nfAndPaasInstanceId=JSON.parse($(el$).closest('li').children('a').attr('data-chartval')).nfAndPaasInstanceId;
            launchChartMuseum('updateConfigNF');
        }
    }

    function onSaveChart() {
        var jsonData = FORM$.getData('values-output'), 
        question = 'Are you sure you want to save updated chart values?';
        if(($('#form-pane').hasClass('shared-param') && $("#lcmDlg").hasClass('cn-simplified')) ||
        ($('#form-pane').hasClass('shared-param') && $("#lcmDlg").hasClass('cn-snapshot'))) {
            question = 'Are you sure you want to save updated shared parameter values?';
        } else if($('#form-pane').hasClass('overlay-param') && $("#lcmDlg").hasClass('cn-snapshot')) {
            question = 'Are you sure you want to save updated overlay parameter values?';
        }
        else if(($('#form-pane').hasClass('helm-options') && $("#lcmDlg").hasClass('cn-simplified')) ||
        ($('#form-pane').hasClass('helm-options') && $("#lcmDlg").hasClass('cn-snapshot'))) {
            question = 'Are you sure you want to save updated per fed helm options?';
        }
        MSG$.confirm({
            statement: 'Confirm',
            question: question,
            yes: function () {
                saveChartHelper()
            }
        });
    }

    function saveChartHelper(){

        var format;
        if($('#parentFormContainer').hasClass('cn-expert-mode')){
            format = "yaml";
            var formData = FORM$.getData('values-output'),
                details = getReleaseNameAndNamespace(formData),
                dataContent = GCM$.common_functions.editor["yamlEditor"].getValue();

            formData.dataContent = typeof dataContent !== "undefined" ? dataContent : formData.dataContent;
            if(isValid(details)) {
                var override = false;
                callSaveChart(selectedChart, instantiateDetails, formData, format, override)
            }
        }
        else {
            var jsonData = FORM$.getData('values-output');
            if(($('#form-pane').hasClass('shared-param') && $("#lcmDlg").hasClass('cn-simplified')) ||
                ($('#form-pane').hasClass('shared-param') && $("#lcmDlg").hasClass('cn-snapshot'))) {
                var sharedParamData = {
                    aggregateVals: simplifiedUCData.aggregateVals,
                    sharedParamsForm: jsonData
                }, nfConfigSetName = $("#launchInheritedSharedValuesBtn").parent().find('span').text(),
                type = $("#NFConfigDialog").hasClass('cn-simplified') ? 'simplified': 'snapshot';
                saveSharedValues(nfConfigSetName, sharedParamData, type, 'inherited');
            } else if(($('#form-pane').hasClass('overlay-param') && $("#lcmDlg").hasClass('cn-snapshot'))) {
                var overlayParamData = {
                    overlayConfForm: jsonData
                }, nfConfigSetName = $("#launchSharedValuesBtn").parent().find('span').text();
                saveSharedValues(nfConfigSetName, overlayParamData, 'snapshot', 'overlay');
            } else if (($('#form-pane').hasClass('helm-options') && $("#lcmDlg").hasClass('cn-simplified')) ||
                ($('#form-pane').hasClass('helm-options') && $("#lcmDlg").hasClass('cn-snapshot'))) {
                var nfConfigSetName = $("#launchInheritedSharedValuesBtn").parent().find('span').text();
                var helmOptionsParam = {
                    repoName: repoClusterVal.repoName,  
                    dzId: repoClusterVal.selectedCluster.dzId,
                    clusterId: repoClusterVal.selectedCluster.id
                }
                saveSharedValues(nfConfigSetName, jsonData, undefined, 'helmOptions', helmOptionsParam);
            }
            else {
                var override = false;
                callSaveChart(selectedChart, instantiateDetails, jsonData, format, override);
            }
        }
    }

    function callSaveChart(selectedChart, instantiateDetails, jsonData, format, override){
        $("#form-pane").activity()
        if(instantiateDetails.branchName === (olderSelectedChart.name + '-' + olderSelectedChart.version))
            instantiateDetails.branchName = selectedChart.name + "-" + selectedChart.version;
        OPM$.lcm.federations.federationsService.saveUpdatedChart(selectedChart.repoName, selectedChart.name, selectedChart.version,
            instantiateDetails.releaseName, instantiateDetails.namespace, instantiateDetails.nfAndPaasInstanceId, jsonData, format, instantiateDetails.group.name, override).done(function (data) {
            MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
            OPM$.lcm.federations.federationsService.retrieveUpdatedPrereq(selectedChart.repoName, instantiateDetails.dzId,
                instantiateDetails.clusterId, instantiateDetails.group.name).done(function (prereqdata) {
                OPM$.lcm.lcmController.loadTree(prereqdata.treeNode, 'prereq-tree-content', OPM$.lcm.federations.federationsController.onBulkInstallFedClick, undefined, 'update', true);
                //Clearing 'prereq-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
                Cookies.set('prereq-tree-content', {});
                originalFormData = {};
                //Remember the last clicked chart and trigger it again
                var branch = $("#prereq-tree-content").find("li.branch[data-name='"+instantiateDetails.branchName+"']");
                $(branch.find("button.an-expandable")[0]).trigger('click');
                var lastClickedChart = $(branch).find("li.leaf[data-name='"+selectedChart.name + "-" + selectedChart.version+"']");
                $(lastClickedChart.find('a')[0]).trigger('click');
            });
        }).fail(function (data) {
            if(data.responseJSON.result === "confirm"){
                if(data.responseJSON.action === "override"){
                    MSG$.confirm({
                        statement: 'Confirmation',
                        question: data.responseJSON.errorMessage,
                        yes: function () {
                            var override = true;
                            callSaveChart(selectedChart, instantiateDetails, jsonData, format, override)
                        }
                    })
                }
            }
        }).always(function () {
            $("#form-pane").activity(false);
        })
    }

    function saveSharedValues(nfConfigSet, jsonData, type, sharedParamType, helmOptionsParam) {
        OPM$.lcm.federations.federationsService.saveSharedValues(nfConfigSet, jsonData, type, sharedParamType, helmOptionsParam)
            .done(function (data) {
                MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                originalFormData = {};
                if($('#form-pane').hasClass('shared-param')) {
                    //Shared values in instantiation and snapshot dialog
                    var configSetType = $('#lcmDlg').hasClass('cn-simplified') ? 'simplifiedConfig' : 'snapshotConfig';
                    getSharedValues(nfConfigSet, undefined, undefined, configSetType, 'inherited' );
                } 
                else if($('#form-pane').hasClass('overlay-param')) {
                    //Overlay values in snapshot dialog
                    getSharedValues(nfConfigSet, undefined, undefined, 'snapshotConfig', 'overlay');
                } 
                else if($('#form-pane').hasClass('helm-option')){
                    showPerFedHelmOptions();
                }
            });
    }

    function onDiscardChart() {
        var jsonData = FORM$.getData('values-output'), 
        question = 'Are you sure you want to discard all updated chart values?';
        if($('#form-pane').hasClass('shared-param')) {
            question = 'Are you sure you want to discard all updated shared parameter values?';
        } 
        else  if($('#form-pane').hasClass('overlay-param')) {
            question = 'Are you sure you want to discard all updated overlay parameter values?';
        }
        else if($('#form-pane').hasClass('helm-options')){
            question = 'Are you sure you want to discard all updated per fed helm options?';
        }
        MSG$.confirm({
            statement: 'Confirm',
            question: question,
            yes: function () {
                if($('#form-pane').hasClass('shared-param')) {
                    //Shared values in instantiation dialog
                    var nfConfigSetName = $("#launchInheritedSharedValuesBtn").parent().find('span').text();
                    var configSetType = $('#lcmDlg').hasClass('cn-simplified') ? 'simplifiedConfig' : 'snapshotConfig';
                    getSharedValues(nfConfigSetName, undefined, undefined, configSetType, 'inherited' );
                } else if($('#form-pane').hasClass('overlay-param')) {
                    //Overlay values in instantiation dialog
                    var nfConfigSetName = $("#launchSharedValuesBtn").parent().find('span').text();
                    getSharedValues(nfConfigSetName, undefined, undefined, 'snapshotConfig', 'overlay');
                } else if($('#form-pane').hasClass('helm-options')){
                    showPerFedHelmOptions();
                } else {
                    if(!$.isEmptyObject(olderSelectedChart))
                        $.extend(true, selectedChart, olderSelectedChart)
                    originalFormData = {};
                    renderChartsTree(selectedChart.repoName, selectedChart.name, selectedChart.version, undefined, undefined, true, instantiateDetails)
                    $("#instantiateFedNewChartName").text("Select New Chart...");
                    $("#instantiateFedNewChartName").attr("title", "Select New Chart...");
                }
            }
        });
    }

    function renderAllChartVersions(refresh) {
        var selectedRepo = $("#lcmSelectedRepo").val(),
            chartKeyword = $("#NFTypeCombo").val();
        callRenderAllChartVersions(selectedRepo, chartKeyword, undefined, undefined, refresh);
    }

    function pickNewChartVersion() {
        originalFormData = {};
        $.extend(true, olderSelectedChart, selectedChart)
        selectedChart.repoName = $('#chartMuseumDiv').find('select').val();
        selectedChart.name = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-name').text();
        selectedChart.version = $('#chartMuseumDiv ul').find('li.an-selected').find('.cn-repo-chart-version').text();
        $("#instantiateFedNewChartName").text(selectedChart.name + '-' + selectedChart.version);
        $("#instantiateFedNewChartName").val(selectedChart.name + '-' + selectedChart.version);
        $("#instantiateFedNewChartName").attr('title',selectedChart.name + '-' + selectedChart.version);
        //GCM$.common_functions.closeDialog('chartMuseumDlg');
        var prevChart = $("#newChartIndicator").length > 0 ? $("#instantiateFedChartName").text() : undefined //Backend needs this information for merging values.yaml

        renderChartsTree(selectedChart.repoName, selectedChart.name, selectedChart.version, undefined, undefined, true, instantiateDetails, prevChart);
    }

    function checkFormClean() {
        if ($.isEmptyObject(originalFormData) || typeof originalFormData.forms == 'undefined' 
        || $('#parentFormContainer').hasClass('cn-expert-mode')) {
            return true;
        } else {
            var jsonData = FORM$.getData('values-output');
            //Extracting forms data and removing the methods for comparision
            var strNewForm = JSON.stringify(jsonData.forms)
            var orgForm = JSON.stringify(originalFormData.forms)
            return _.isEqual(JSON.parse(strNewForm),JSON.parse(orgForm));
        }
    }

    function refreshPrereqTree(branchIcon, integrateVue) {
        OPM$.lcm.federations.federationsService.retrieveUpdatedPrereq(repoClusterVal.repoName, selectedCluster.dzId,
            selectedCluster.id, instantiateDetails.group.name).done(function (prereqdata) {
            OPM$.lcm.lcmController.loadTree(prereqdata.treeNode, 'prereq-tree-content', OPM$.lcm.federations.federationsController.onBulkInstallFedClick, undefined, branchIcon, integrateVue);
            //Clearing 'prereq-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
            Cookies.set('prereq-tree-content', {});
            originalFormData = {};
        });
    }

    function launchSaveConfigSet(){
        var config_html = Handlebars.templates['lcm_federations_createConfigSet']();
        $('#federationsLcmForm').append(config_html);
        var left = document.getElementById('launchSaveConfigSetBtn').getBoundingClientRect().left
        - document.getElementById('lcmDlg').getBoundingClientRect().left +
            document.getElementById('launchSaveConfigSetBtn').getBoundingClientRect().width;
        var top = document.getElementById('launchSaveConfigSetBtn').getBoundingClientRect().top
            - document.getElementById('lcmDlg').getBoundingClientRect().top +
            document.getElementById('launchSaveConfigSetBtn').getBoundingClientRect().height;
        $('#createConfigSetDialog').css({'top': top , 'left' : '-'+left+'px'});
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#createConfigSetDialog'));
        VALIDATION$.validateOnInputChange($('#saveConfigSetForm'), $('#saveConfigSetButton'), undefined, undefined, undefined, true);
    }

    function saveConfigSet(override){
        var nfConfigSetName = $("#newConfigSetName").val();
        $("#lcmDlg").activity();
        var clusterName =  $('#selectClusterBtn span').text()
        simplifiedUCData.treeNode = GCM$.tree2.getVueDataById('prereq-tree-content');
        simplifiedUCData.sharedParamsForm = FORM$.getData('values-output');
        OPM$.lcm.federations.federationsService.createConfigSet(selectedChart.repoName,
            selectedCluster.dzId, selectedCluster.id,nfConfigSetName, override,simplifiedUCData)
            .done(function(res){
                MSG$.showInfoMsg({status: 'Success', content: res.successMessage});
                $('#lcmDlg').detach();
                $('#NFConfigDialog').detach();
                repoClusterVal.repoName = res.data.chartRepoName;
                repoClusterVal.selectedCluster.dzId = res.data.dzId;
                repoClusterVal.selectedCluster.id = res.data.clusterId;
                repoClusterVal.selectedCluster.clusterName = clusterName;
                selectedCluster.dzId = res.data.dzId;
                selectedCluster.id = res.data.clusterId;
                OPM$.NFConfig.NFConfigController.setSelectedGroup(res.data);
                setTimeout(function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                    OPM$.lcm.lcmController.openLcmDialog(undefined, 'simplifiedConfig');
                }, 1000);
        }).fail(function (error) {
            $('#lcmDlg').activity(false);
            if (error.responseJSON.result === "confirm") {
                MSG$.confirm({
                    statement: error.responseJSON.errorCode,
                    question: error.responseJSON.errorMessage,
                    yes: function () {
                        var override = "true";
                        saveConfigSet(override);
                    }});
            }
        }).always(function () {
            $('#lcmDlg').activity(false);
        });
    }

    function selectConfigChart(){
        setupChartDepHelper('chartMuseumDlg', selectedChart.name, selectedChart.version, 'add')
    }

    function getSharedValues(nfConfigSetName, refresh, sharedParams, type, sharedParamType){
        if (checkFormClean()) {
        var config = {
            disableSetLabel: true
        };

        $("#prereq-tree-content li").removeClass('an-selected');
        $("#selectNewChartBtn").addClass("disabled");
        $('.CodeMirror').detach();
        $('#parentFormContainer').removeClass('cn-expert-mode');
        if(typeof nfConfigSetName !== "undefined") {
            $("#lcmDlg").activity();
            originalFormData = {}
            OPM$.lcm.federations.federationsService.renderSharedValues(nfConfigSetName, refresh, simplifiedUCData, type, sharedParamType, repoClusterVal)
                .done(function (data) {
                    simplifiedUCData.sharedParamsForm = _.cloneDeep(data.sharedParamsForm);
                    simplifiedUCData.overlayConfForm = _.cloneDeep(data.overlayConfForm);
                    simplifiedUCData.aggregateVals = _.cloneDeep(data.aggregateVals);
                    if(!_.isEmpty(data) && !_.isEmpty(data.overlayConfForm)) {
                        $('#instantiateSaveChartBtn').attr('title', 'Save updated overlay configuration values');
                        $('#instantiateCancelBtn').attr('title', 'Discard updated overlay configuration values');
                        $('#form-pane').addClass('overlay-param');
                        GCM$.form.createForm('values-output', data.overlayConfForm, undefined, config);
                        $.extend(true, originalFormData, data.overlayConfForm);
                        $("#selectSharedValues select").prop('disabled', true);
                    } else if(!_.isEmpty(data) && !_.isEmpty(data.sharedParamsForm)) {
                        $('#instantiateSaveChartBtn').attr('title', 'Save updated shared parameter values');
                        $('#instantiateCancelBtn').attr('title', 'Discard updated shared parameter values');
                        $('#form-pane').addClass('shared-param');
                        GCM$.form.createForm('values-output', data.sharedParamsForm, undefined, config);
                        $.extend(true, originalFormData, data.sharedParamsForm);
                        if(type === 'snapshotConfig')
                            $("#selectSharedValues select").prop('disabled', false);
                    } else {
                        $("#values-output").empty();
                    }
                    $("#chartDifferences").css('display', 'none');
                    $("#instantiateFedChartName").text("");
                    $("#selectNewChartBtn, #expertIcon").prop('disabled', true);
                    if($("#lcmDlg").hasClass('cn-lcm-instantiate-config'))
                        VALIDATION$.validateOnInputChange($('#values-output'), $("#instantiateSaveChartBtn"), undefined, undefined, undefined, true);
                    else{
                        VALIDATION$.validateOnInputChange($('#values-output'), $("#launchSaveConfigSetBtn"), undefined, undefined, undefined, true);
                    }
                    $('#values-output').on('keydown', function(e){
                        //Prevent space key press from scrolling
                        var target$ = $(e.target);
                        if(e.keyCode === GCM_KEY$.SPACE && target$.attr('role') == 'switch'){
                            e.preventDefault();
                        }
                    });
                }).always(function () {
                $("#lcmDlg").activity(false);
            })
        } else {
            if (!_.isEmpty(sharedParams)) {
                GCM$.form.createForm('values-output', sharedParams, undefined, config);
                VALIDATION$.validateOnInputChange($('#values-output'), $("#launchSaveConfigSetBtn"), undefined, undefined, undefined, true);
                $('#values-output').on('keydown', function(e){
                    //Prevent space key press from scrolling 
                    var target$ = $(e.target);
                    if(e.keyCode === GCM_KEY$.SPACE && target$.attr('role') == 'switch'){
                        e.preventDefault();
                    }
                })
            } else {
                $("#values-output").empty();
            }
        }

        }
        else {
            MSG$.confirm({
                statement: 'Confirm',
                question: 'There are unsaved changes in the form. Do you want to save the changes before switching to new chart?',
                yes: function () {
                    saveChartHelper();
                },
                no: function () {
                    originalFormData = {};
                    getSharedValues(nfConfigSetName, refresh, sharedParams, type, sharedParamType);
                }
            });
        }
    }

    function updateFlavorForm(data) {
        $("#lcmFlavorSelect").remove();
        var html = Handlebars.templates['lcm_federations_flavorForm'](data);
        $(html).insertAfter('#selectClusterBtn');
    }

    function deleteNfFromConfigSet(e){
        var el$ = $(e.target),
            chartName = $(el$).closest('li').attr('data-chartName'),
            version = $(el$).closest('li').attr('data-version');
        if(el$.hasClass('an-icon-delete')) {
            //Remove chart from config set list
            MSG$.confirm({
                statement: 'Confirm',
                question: 'Are you sure you want to remove the chart '+chartName+'?',
                yes: function () {
                    setupChartDepHelper('lcmDlg', chartName, version, 'remove')
                }
            });
        }
        else if(el$.prop('type') === 'checkbox' && el$.is('input')){
            simplifiedUCData.treeNode = GCM$.tree2.getVueDataById('prereq-tree-content');
            simplifiedUCData.sharedParamsForm = FORM$.getData('values-output');
            setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                    setupChartDepHelper('lcmDlg', 'none', 'none', 'update')
            }, 100)
        }
    }

    function setupChartDepHelper(activityId, chartName, chartVersion, action){
        $("#"+activityId).activity();
        OPM$.lcm.federations.federationsService.setupChartForDeployment(selectedChart.repoName,
            selectedCluster.dzId, selectedCluster.id, chartName, chartVersion, action, simplifiedUCData)
            .done(function(res){
                if(typeof res.treeNode !== 'undefined')
                // flag to GCM tree2 module to add checkboxes to second level elements. Currently used only in OPM Create Config
                    res.treeNode.checkable = true;
                simplifiedUCData = _.cloneDeep(res);
                OPM$.lcm.lcmController.loadTree(res.treeNode, 'prereq-tree-content', OPM$.lcm.federations.federationsController.deleteNfFromConfigSet, undefined, 'delete', true);
                //Clearing 'prereq-tree-content' cookie to avoid HTTP Bad Request Error due to large data accumulation
                Cookies.set('prereq-tree-content', {});
                getSharedValues(undefined, false, res.sharedParamsForm);
                $("#selectSharedValues select").prop('disabled', false);
                if(action === 'add'){
                    updateFlavorForm(res.flavorForm);
                    if(!($('#pinNFBtn').hasClass('nfChartPinned')))
                        GCM$.common_functions.closeDialog("chartMuseumDlg");
                }
                var branch = $("#prereq-tree-content").find("li.branch[data-name='"+chartName+"-"+chartVersion+"']");
                $(branch.find("button.an-icon-scroll_triangle_right_dark")[0]).trigger('click');
            }).always(function () {
                $("#"+activityId).activity(false);
        })
    }

    function onSelectSharedParamSet(e) {
        var nfConfigSetName = $(e.target).val();
        if(nfConfigSetName !== "") {
            if($('#lcmDlg').hasClass('cn-lcm-create-config')|| $('#lcmDlg').hasClass('cn-lcm-instantiate-config')){
                simplifiedUCData.treeNode = GCM$.tree2.getVueDataById('prereq-tree-content');
            }
            simplifiedUCData.sharedParamsForm = FORM$.getData('values-output');
            getSharedValues(nfConfigSetName, true);
        }
    }

    function addNewChartInCreateConfig() {
        var readOnlyRepo = false;
        if($("#prereq-tree-content").children().length > 0) {
            readOnlyRepo = true;
        }
        launchChartMuseum('addConfigChartLabel', readOnlyRepo);
    }

    function resetSimplifiedUCData() {
        simplifiedUCData = {};
    }

    function showConfigSetOpStatus(data) {
        if(repoClusterVal.selectedCluster.dzId === data.deploymentZoneId
            && repoClusterVal.selectedCluster.id === data.clusterId) { //Filters by cluster

            if (data.status.toLowerCase() === "success") {
                MSG$.showSuccessMsg({
                    'status': 'Success',
                    'content': (typeof data.content !== "undefined" && data.content !== "") ? data.content :
                        'Bulk installation of ' + data.name + ' is successful on cluster ' + data.clusterName
                });
                
                //reset max inactivity time to 30 minutes when bulk install completes
                OPM$.app.updateMaxInactivity(1800)
            } else if (data.status.toLowerCase() === "failure") {
                MSG$.showErrorMsg({
                    'status': 'Failed',
                    'content': (typeof data.content !== "undefined" && data.content !== "") ? data.content :
                        'Bulk installation of ' + data.name + ' has failed on cluster ' + data.clusterName
                });
            }
        }
    }

    function scrollToPosition(key) {
        if(key === "next") {
            var nextEl = findNext($(currDisplayedDifference), $("#values-output form label.an-differences:visible"));
            $("#values-output").animate({
                'scrollTop': ($(nextEl).get(0).offsetTop - $("#values-output").get(0).offsetTop)
            }, 'slow');
            currDisplayedDifference = $(nextEl);
        } else if(key === "prev") {
            var prevEl = findPrev($(currDisplayedDifference), $("#values-output form label.an-differences:visible"));
            $("#values-output").animate({
                'scrollTop': ($(prevEl).get(0).offsetTop  - $("#values-output").get(0).offsetTop)
            }, 'slow');
            currDisplayedDifference = $(prevEl);
        }
    }

    function findPrev(curritem, items) {
        var i =  items.length-1;
        while(i > 0) {
            if(curritem.is(items[i])){
                return items[i-1]
            }
            i--;
        }
        return items.last();
    }

    function findNext(curritem, items) {
        var i = 0;
        while(i < items.length-1) {
            if(curritem.is(items[i])){
                return items[i+1];
            }
            i++;
        }
        return items.first();
    }

    function hideTooltip(tooltipId){
        $('#'+tooltipId).css('display', 'none')
    }

    function showTooltip(e,tooltipId){
        $('#'+tooltipId).css('display', 'block')
    }

    function showStatusfromInstallStatusIcon(e, dzName){
        var dzId=selectedCluster.dzId, clusterId= selectedCluster.id, chartName=$(e.target).closest('li').data('chartname');
        var releaseName=chartName, clusterName= $("#selectClusterBtn span").first().text();
        OPM$.lcm.federations.federationsService.getHelmStatus(dzId, clusterId, chartName, releaseName, "showStatus")
        .done(function (data) {
            var config = {
                clusterName: clusterName,
                dzName: dzName,
                releaseName: typeof releaseName !== "undefined" ? releaseName : undefined,
                fedDeploymentStatus: data.data.fedDeploymentStatus,
                task: "show status",
                data: data.successMessage,
                consoleTables: data.data,
                helmResponses: data.helmResponses
            };
            var userSelected = true;
            OPM$.lcm.consoleTabs.tabsController.openConsoleTab(config, userSelected);

        });
    }

    function issuOptionSelect(e){
        if($('#issuOptions').val() !== 'none'){
            $('#stopBulkInstallBtn').prop('title', 'Abandon bulk installation');
            $('#dryRunBtn').prop('disabled', false);
        }
        else {
            $('#stopBulkInstallBtn').prop('title', 'Stop bulk installation');
            $('#dryRunBtn').prop('disabled', true);
        }
    }

    function updateConfigNF(e){
        var snapshotName = $("#headerName").text().trim();
        $("#museum-tree-content").activity();
        OPM$.lcm.federations.federationsService.updateConfigNF(selectedChart.name, selectedChart.repoName, selectedChart.version, snapshotName)
        .done(function (data) {
            GCM$.common_functions.closeDialog('chartMuseumDlg');
            MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
            var branchIcon = "update", integrateVue = true;
            refreshPrereqTree(branchIcon, integrateVue);
        }).always(function(){
            $("#museum-tree-content").activity(false);
        })
    }

    return {
        launchImportDialog: launchImportDialog,
        refreshImportStatus: refreshImportStatus,
        importChartsAndImages: importChartsAndImages,
        renderChartsTree: renderChartsTree,
        onTreeClick: onTreeClick,
        launchChartMuseum: launchChartMuseum,
        onClickChartsList: onClickChartsList,
        pickNewChartInMuseum: pickNewChartInMuseum,
        onSelectChart: onSelectChart,
        renderHelmChart: renderHelmChart,
        renderChartsInMuseum: renderChartsInMuseum,
        callRenderAllChartVersions: callRenderAllChartVersions,
        saveFed: saveFed,
        pickCluster: pickCluster,
        onClusterClick: onClusterClick,
        onSelectCluster: onSelectCluster,
        launchDryRun: launchDryRun,
        onDependencyListClick: onDependencyListClick,
        selectPaasDependency: onSelectPaasDependency,
        copyToClipboard: copyToClipboard,
        contextualClusterSelection: contextualClusterSelection,
        showStatusDetails: showStatusDetails,
        formPostProcessing: formPostProcessing,
        getAllChartVersions: getAllChartVersions,
        checkIfClusterIsSelected: checkIfClusterIsSelected,
        toggleUpgradeCampaignPane: toggleUpgradeCampaignPane,
        rollbackCnf: rollbackCnf,
        demoCanaryUpgrade: demoCanaryUpgrade,
        updateStatus: updateStatus,
        updateFedInLcm: updateFedInLcm,
        getPackageMarkdownFile: getPackageMarkdownFile,
        toggleExpertMode: toggleExpertMode,
        importValues: importValues,
        launchExportDialog: launchExportDialog,
        exportValues: exportValues,
        getChartDetails: getChartDetails,
        rollbackCanary: rollbackCanary,
        validateKeywordFilter: validateKeywordFilter,
        getLatestCharts: getLatestCharts,
        getClusterData: getClusterData,
        toggleHelmChartView: toggleHelmChartView,
        renderPrerequisitesList: renderPrerequisitesList,
        callPrerequisiteHandler: callPrerequisiteHandler,
        nextPrerequisite: nextPrerequisite,
        previousPrerequisite: previousPrerequisite,
        getRepoClusterVal: getRepoClusterVal,
        bulkInstallFeds: bulkInstallFeds,
        stopBulkInstallation: stopBulkInstallation,
        updateNFInstallStatus: updateNFInstallStatus,
        onSelectRepoName: onSelectRepoName,
        pinChart: pinChart,
        newSelectChart: newSelectChart, 
        onBulkInstallFedClick: onBulkInstallFedClick,
        onSaveChart: onSaveChart,
        onDiscardChart: onDiscardChart,
        renderAllChartVersions: renderAllChartVersions,
        pickNewChartVersion: pickNewChartVersion,
        refreshPrereqTree: refreshPrereqTree,
        launchSaveConfigSet: launchSaveConfigSet,
        selectConfigChart: selectConfigChart,
        getSharedValues: getSharedValues,
        deleteNfFromConfigSet: deleteNfFromConfigSet,
        saveConfigSet: saveConfigSet,
        onSelectSharedParamSet: onSelectSharedParamSet,
        addNewChartInCreateConfig: addNewChartInCreateConfig,
        resetSimplifiedUCData: resetSimplifiedUCData,
        updateFlavorForm: updateFlavorForm,
        showConfigSetOpStatus: showConfigSetOpStatus,
        scrollToPosition: scrollToPosition,
        showTooltip: showTooltip,
        hideTooltip: hideTooltip,
        showStatusfromInstallStatusIcon: showStatusfromInstallStatusIcon,
        issuOptionSelect: issuOptionSelect,
        updateConfigNF: updateConfigNF,
        showPerFedHelmOptions: showPerFedHelmOptions
    };

})();
