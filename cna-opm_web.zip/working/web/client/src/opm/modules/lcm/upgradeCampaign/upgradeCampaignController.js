OPM$.lcm = OPM$.lcm || {};
OPM$.lcm.upgradeCampaign = OPM$.lcm.upgradeCampaign || {};

OPM$.lcm.upgradeCampaign.upgradeCampaignController = (function() {

    var allCampaigns = [], campaignInstance,canaryInstance, upgradeCampaignInstance,
        canaryExecStepCount, observabilityUrl;

    function getData() {
        var details = OPM$.lcm.federations.federationsController.getChartDetails();
        $('#parentFormContainer').activity();
        OPM$.lcm.upgradeCampaign.upgradeCampaignService.renderCanaryDetails(details)
            .done(function (data) {
                observabilityUrl = data.observabilityUrl;
                createFormAndDatabind(data);
            }).always(function () {
                $('#parentFormContainer').activity(false);
        });
    }

    function createFormAndDatabind(data) {
        var html = Handlebars.templates['lcm_upgradeCampaign_upgradeCampaignForm'](data);
        $('#upgrade-campaign-content').empty().append(html);

        var config = {
            el: "#upgrade-campaign-content",
            data: data
        };
        upgradeCampaignInstance = VUE$.createInstance(config);
        if(typeof data.name != "undefined") {
            $("#selectCampaign").val(data.name);
            updateCampaignInfo(data);
        }
        GCM$.accessibility.tableAccessibility.makeTableKeyNav($('#canary-pod-table tbody'));
        //$(document).hoverIntent(onPodStatusHoverOver, onPodStatusHoverOut, ".canary-deployments tbody tr .an-icon-info");
        $('.canary-deployments tbody tr .an-icon-info').parent().on('click' , onPodStatusHoverOver).on('keyup', function(e){ if(e.keyCode ==13) onPodStatusHoverOver(e)});
        function onPodStatusHoverOver(e){
            e.stopPropagation();
            $("#podStatusBubble").detach();
            var containers = $(e.target).closest('tr').attr('data-containers');
            containers = JSON.parse(containers);
            var html = Handlebars.templates['lcm_upgradeCampaign_podStatus'](containers);
            $('body').append(html);
            $("#podStatusBubble").position({
                my: "left top",
                at: "right top",
                of: $(e.target),
                collision: "flipfit"
            })
        }

        function onPodStatusHoverOut(){
            $('#podStatusBubble').detach();
        }
    }
    
    function launchCampaignDialog() {
        var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementDlg']();
        $('#lcmDlg').append(html);
        $('#campaignDialog').hide().fadeIn().draggable({
           handle: 'header'
        }).position({
            my: "center",
            at: 'center',
            of: $('#lcmDlg')
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#campaignDialog'));
        renderCampaign();
    }

    function createForm(e) {
        var html = Handlebars.templates['lcm_upgradeCampaign_createCampaign']();
        $(html).appendTo('#campaignDialog').position({my: "left top", at: "right+50 bottom", of: $(e.target)});
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#createCampaign'));
        VALIDATION$.validateOnInputChange($('#createCampaign form'), $('#addCampaignBtn'));
    }

    function onAddCampaign() {
        var name = $('#createCampaign').find('input').val();
        if(campaignNameIsValid(name)){
            GCM$.common_functions.closeDialog('createCampaign');
            renderCampaign(name);
        } else {
            MSG$.showErrorMsg({status: 'Error', content: 'Invalid Campaign Name!! No spaces are allowed.'});
        }
    }

    function campaignNameIsValid(name) {
        if(name.indexOf(" ") > -1){
            return false;
        } else {
            return true;
        }
    }

    function getCampaign(e) {
        var el$ = $(e.target).closest('select'),
        name = $(el$).val();
        renderCampaign(name);
    }

    function renderCampaign(name) {
        var formData = {
                campaigns: [],
                name: "",
                description: "",
                steps: []
            },
            default_campaignForm = {
                name: "",
                description: "",
                steps: []
            };

        $('#createCampaignBtn, #deleteCampaignBtn').prop('disabled', true);
        if(typeof name !== "undefined"){
            OPM$.lcm.upgradeCampaign.upgradeCampaignService.renderCampaigns()
                .done(function (data1) {
                    allCampaigns= data1.campaigns;
                    _.assign(formData, data1);

                    if(data1.campaigns.includes(name)){
                        //Render existing campaign information

                        OPM$.lcm.upgradeCampaign.upgradeCampaignService.getCampaign(name)
                            .done(function (data) {
                                data = processDataForPreAndPostCanary(data);
                                _.assign(formData, data);
                                var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementForm'](formData);
                                $('#campaignDialog section').empty().append(html);
                                delete formData.campaigns;
                                campaignInstance = dataBindForm('#campaignForm', formData);
                                VALIDATION$.validateOnInputChange($('#campaignForm'), $('#campaignDialog footer button'));
                            });
                    } else {
                        //Add the new campaign name to the list

                        formData.campaigns.push(name);
                        formData.name = name;
                        formData = processDataForPreAndPostCanary(formData);
                        var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementForm'](formData);
                        $('#campaignDialog section').empty().append(html);
                        delete formData.campaigns;
                        campaignInstance = dataBindForm('#campaignForm', formData);
                        VALIDATION$.validateOnInputChange($('#campaignForm'), $('#createCampaignBtn'));
                    }
                });
        } else {
            OPM$.lcm.upgradeCampaign.upgradeCampaignService.renderCampaigns()
                .done(function (data) {
                    allCampaigns= data.campaigns;
                    data = processDataForPreAndPostCanary(data);
                    var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementForm'](data);
                    $('#campaignDialog section').empty().append(html);
                    campaignInstance = dataBindForm('#campaignForm', default_campaignForm);
                    VALIDATION$.validateOnInputChange($('#campaignForm'), $('#createCampaignBtn'));
                });
        }
    }

    function dataBindForm(id, data) {
        var config = {
            el: id,
            data: data,
            methods: [{
                name: 'addCanaryWeight',
                method: function () {
                    var app = this,
                        newData = _.cloneDeep(VUE$.getDataFromApp(app));
                    newData.campaigns = allCampaigns;
                    if(newData.steps.length === 0) {
                        newData.steps.push(0);
                    } else {
                        newData.steps.push(100);
                    }
                    newData.dialog = true;

                    var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementForm'](newData);
                    $('#campaignDialog section').empty().append(html);
                    delete newData.campaigns; delete newData.dialog;
                    campaignInstance = dataBindForm('#campaignForm', newData);
                    VALIDATION$.validateOnInputChange($('#campaignForm'), $('#createCampaignBtn'));
                    $('#addStep').focus();
                }
            },{
                name: 'removeCanaryWeight',
                method: function (index) {
                    var app = this,
                        newData = _.cloneDeep(VUE$.getDataFromApp(app));
                    newData.campaigns = allCampaigns;
                    newData.steps.splice(index, 1);
                    newData.dialog = true;

                    var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementForm'](newData);
                    $('#campaignDialog section').empty().append(html);
                    delete newData.campaigns; delete newData.dialog;
                    campaignInstance = dataBindForm('#campaignForm', newData);
                    VALIDATION$.validateOnInputChange($('#campaignForm'), $('#createCampaignBtn'));
                }
            }, {
                name: 'executeCanaryStep',
                method: function (dryRun) {
                    canaryExecStepCount = typeof canaryExecStepCount === "undefined" ? 0 : canaryExecStepCount;
                    if(canaryExecStepCount <= this.steps.length){
                        var clusterAndChartDetails = OPM$.lcm.federations.federationsController.getChartDetails();
                        var jsonData = {
                            'clusterId' : clusterAndChartDetails.id,
                            'dzId': clusterAndChartDetails.dzId,
                            'releaseName': clusterAndChartDetails.releaseName,
                            'namespace': clusterAndChartDetails.namespace,
                            'chartName': clusterAndChartDetails.name,
                            'chartVersion': clusterAndChartDetails.version,
                            'chartRepoName': clusterAndChartDetails.repoName,
                            'percentageTraffic' : this.steps[canaryExecStepCount],
                            'pods' : (VUE$.getDataFromApp(upgradeCampaignInstance)).pods,
                            'name': $('#selectCampaign').val()
                        };
                        var $nextCanaryStep = $($($($('#canarySteps tbody tr')[canaryExecStepCount]).find('th')[0])).find('.an-icon-for-row');

                        $($nextCanaryStep).activity({"width": 0.5});

                        $("#canarySteps button").prop('disabled', true);
                        var operation;
                        if(canaryExecStepCount === 0) {
                            operation = "PreCanary";
                        } else if(canaryExecStepCount === this.steps.length-1){
                            operation = "PostCanary";
                        }
                        OPM$.lcm.upgradeCampaign.upgradeCampaignService.executeStep(jsonData, dryRun, operation)
                            .done(function (data) {
                                if(dryRun) {
                                    _.assign(data, {
                                        title: "Dry Run",
                                        dryRun: true
                                    });
                                    var html = Handlebars.templates['lcm_federations_dryRun'](data);
                                    $('body').append(html);
                                    $($nextCanaryStep).activity(false);
                                    $("#dryRunDialog").hide().fadeIn().draggable({
                                        handle: "header"
                                    }).position({
                                        my: "center",
                                        at: "center",
                                        of: "body"
                                    });
                                } else if(operation === "PostCanary"){
                                    MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                                    $($nextCanaryStep).addClass('an-icon-success');
                                } else if(typeof operation === "undefined") {
                                    canaryExecStepCount++;
                                    $($nextCanaryStep).addClass('an-icon-success');
                                    MSG$.showInfoMsg({status: 'Success', content: 'Canary step executed successfully'});
                                }
                                if(operation !== "PreCanary" || dryRun) {
                                    $("#canarySteps button").prop('disabled', false);
                                    $($nextCanaryStep).activity(false);
                                }
                            }).fail(function (data) {
                                $("#canarySteps button").prop('disabled', false);
                                $($nextCanaryStep).activity(false);
                                $($nextCanaryStep).addClass('an-icon-close');
                        });
                    }
                }
            }, {
                name: 'rollbackCanary',
                method: function () {
                    OPM$.lcm.federations.federationsController.rollbackCanary(true);
                }
            } ,{
                name: 'validateStepValue',
                method: function (index) {
                    var app = VUE$.getDataFromApp(this);
                    if(app.steps[index] <= app.steps[index-1]){
                        MSG$.showErrorMsg({status: 'Error', content: 'Weight of each step must be greater than its previous step'});
                        app.steps[index] = app.steps[index-1] + 1;
                        app.dialog = true; app.campaigns = allCampaigns;

                        var html = Handlebars.templates['lcm_upgradeCampaign_campaignManagementForm'](app);
                        $('#campaignDialog section').empty().append(html);
                        delete app.campaigns;
                        campaignInstance = dataBindForm('#campaignForm', app);
                    }
                }
            }]
        };
        return VUE$.createInstance(config);
    }

    function renderExistingCampaign(e) {
        var name = $(e.target).closest('select').val();
        OPM$.lcm.upgradeCampaign.upgradeCampaignService.getCampaign(name)
            .done(function (data) {
                data.observabilityUrl = observabilityUrl;
                updateCampaignInfo(data);
            })
    }

    function updateCampaignInfo(data) {
        $('.desc-textarea').text(data.description);
        data = processDataForPreAndPostCanary(data);
        var html = Handlebars.templates['lcm_upgradeCampaign_canarySteps'](data);
        $('#canarySteps').empty().append(html);
        canaryInstance = dataBindForm('#canarySteps', data);
        canaryExecStepCount = typeof data.stepsExecuted !== "undefined" ? data.stepsExecuted+1 : data.stepsExecuted;
    }

    function processDataForPreAndPostCanary(data) {
        data.steps = (typeof data.steps === "undefined") ? [] : data.steps;
        if(!(data.steps[0] === 0 && data.steps[data.steps.length-1] === 100)) {
            data.steps.splice(0, 0, 0);
            data.steps.splice(data.steps.length, 0, 100);
        }

        return data;
    }

    function onSaveCampaign() {
        var formData = formatData(VUE$.getDataFromApp(campaignInstance));
        if(formData.steps[formData.steps.length-1] !== 100) {
            MSG$.showErrorMsg({status: 'Error', content: 'Last canary step weight must be 100%'});
        } else {
            $('#campaignForm').activity();
            OPM$.lcm.upgradeCampaign.upgradeCampaignService.saveCampaign(formData)
                .done(function () {
                    MSG$.showInfoMsg({status: 'Success', content: 'Campaign saved successfully'});
                    GCM$.common_functions.closeDialog('campaignDialog');
                    var vueData = VUE$.getDataFromApp(upgradeCampaignInstance);
                    vueData.campaigns.push(formData.name);
                    createFormAndDatabind(vueData);
                }).always(function () {
                    $('#campaignForm').activity(false);
            });
        }
    }

    function formatData(data) {
        data.steps.splice(data.steps.length-1,1);
        data.steps.splice(0,1);
        return data;
    }

    function onDeleteCampaign() {
        var formData = VUE$.getDataFromApp(campaignInstance);
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete '+formData.name+' campaign?',
            position: {my: 'left top', at: 'right bottom', of: $(event.target)},
            yes: function () {
                $('#campaignForm').activity();
                OPM$.lcm.upgradeCampaign.upgradeCampaignService.doDeleteCampaign(formData.name)
                    .done(function () {
                        MSG$.showInfoMsg({status: 'Success', content: 'Campaign deleted successfully'});
                        renderCampaign();
                        var vueData = VUE$.getDataFromApp(upgradeCampaignInstance);
                        vueData.campaigns.splice(vueData.campaigns.indexOf(formData.name), 1);
                        createFormAndDatabind(vueData);
                    }).always(function () {
                        $('#campaignForm').activity(false);
                })
            }
        });
    }

    function postRollback() {
        $("#canarySteps").find('tbody .an-icon-for-row').removeClass('an-icon-success an-icon-close');
        canaryExecStepCount = 0;
    }

    function preCanaryStatus(json) {
        var currDetails = OPM$.lcm.federations.federationsController.getChartDetails();
        if(json.deploymentZoneId == currDetails.dzId
            && json.clusterId == currDetails.id
            && json.releaseName == currDetails.releaseName
            && json.namespace == currDetails.namespace) {
            var $preCanaryStep = $($($($('#canarySteps tbody tr')[0]).find('th')[0])).find('.an-icon-for-row');
            $($preCanaryStep).activity(false);
            $("#canarySteps button").prop('disabled', false);
            if(json.canaryStatus === "SUCCESS"){
                canaryExecStepCount++;
                $($preCanaryStep).addClass('an-icon-success');
                MSG$.showInfoMsg({status: 'Success', content: 'Canary pre step executed successfully'});
            } else if(json.canaryStatus === "ERROR") {
                MSG$.showErrorMsg({status: 'Error', content: json.errorMessage});
                $($preCanaryStep).addClass('an-icon-close');
            }
        }
    }

    return {
        getData: getData,
        launchCampaignDialog: launchCampaignDialog,
        createForm: createForm,
        onAddCampaign: onAddCampaign,
        getCampaign: getCampaign,
        renderCampaign: renderCampaign,
        onSaveCampaign: onSaveCampaign,
        onDeleteCampaign: onDeleteCampaign,
        renderExistingCampaign: renderExistingCampaign,
        postRollback: postRollback,
        preCanaryStatus: preCanaryStatus
    };

})();
