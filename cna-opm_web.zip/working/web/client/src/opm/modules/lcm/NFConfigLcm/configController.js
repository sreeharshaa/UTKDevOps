OPM$.lcm = OPM$.lcm || {};
OPM$.lcm.NFConfigLcm = OPM$.lcm.NFConfigLcm || {};

OPM$.lcm.NFConfigLcm.configController = (function() {
    var configVueInstance,  changeNFVerIndex, cnfSelectedArr = [];
    var diffTop = 280;
    function renderCreatePane() {
        $("#lcmButtonDiv").find('button, select').prop('disabled', true);
        $("#backBtn").prop('disabled', true)
        $("#clearBtn").prop('disabled', true)
        $("#chartDetailToggle").css({'pointer-events':'none', 'opacity':'0.5'});

        OPM$.repoManagement.repoService.getNFList().done(function (data) {
            updateView(data)
        });
    }
    function changeNFVersion(e,index) {
        OPM$.repoManagement.repoService.getAllChartRepos()
            .done(function (data) {
                data.index = index
                changeNFVerIndex = index;
                var row = $(e.target).closest("tr");
                row.css({opacity:1})
                row.closest("tbody").find('tr.an-selected').removeClass('an-selected');
                row.addClass("an-selected")
                var fed_html = Handlebars.templates['lcm_NFConfigLcm_chooseVersion'](data);
                $("#NFVerList").css({top: (e.y - diffTop)})
                $("#NFVerList").show().empty().append(fed_html).fadeIn().draggable({
                    handle: "#headerDiv"
                });
                loadChartVersion(index)
            });
    }

    function loadChartVersion(index){
        var storedData = VUE$.getDataFromApp(configVueInstance)
        var sel = $("#repoVal").val()
        if(typeof sel !== "undefined" && sel !== "") {
            var chartType = "fed-"+configVueInstance.$data.cnfs[changeNFVerIndex].type.toLowerCase()
            $('#listCharts').activity();
            OPM$.lcm.federations.federationsService.renderAllChartVersions(sel,chartType)
                .done(function (data) {
                    data.createConfig = true
                    data.instantiateConfig = false
                    var html = Handlebars.templates['lcm_federations_chartMuseumTable'](data);
                    $('#listCharts').empty().append(html);
                    var filterText = storedData.cnfs[index].type.toString().toLowerCase();
                    OPM$.lcm.lcmController.filterData(undefined, 'tableData', filterText)
                    $('#listCharts ul').off('click').on('click', OPM$.lcm.NFConfigLcm.configController.onClickVerList);
                }).always(function () {
                $('#listCharts').activity(false);
            });
        } else if(sel == "") {
            $('#listCharts').empty();
        }
    }

    function dataBindForm(data) {
        var formData = JSON.parse(JSON.stringify(data));
        var vueSelectConfig = {
            el: '#selectNFPane',
            data: formData,
            watchers: [{
                key: "$data",
                handler: function (){
                    var updatedData = VUE$.getDataFromApp(configVueInstance);
                    _.forEach(updatedData.cnfs, function(cnf){
                        if(cnf.selected)
                            cnfSelectedArr.push(cnf);
                    })
                }
            }]
        }
        configVueInstance = VUE$.createInstance(vueSelectConfig);
    }

    function renderVersionInMuseum(e) {
        var sel;
        if(typeof e !== "undefined" && !_.isEmpty(e)){
            sel = $(e.target).val();
            loadChartVersion(changeNFVerIndex)
        }
    }
    function onClickVerList(e) {
        var el$ = $(e.target).closest('li');
        var newVer = $(el$).find('.cn-repo-chart-version').text();
        configVueInstance.$data.cnfs[changeNFVerIndex].helm_chart = newVer
        closeVerDlg()
    }

    function updateView(data){
        OPM$.repoManagement.repoService.getAllChartRepos()
            .done(function (repoData) {
                data.repoList = repoData.repoList;
                var fed_html = Handlebars.templates['lcm_NFConfigLcm_createNF'](data);
                $('#federationsLcmForm').empty().append(fed_html);
                dataBindForm(data)
            });
    }
    function onSelectNF(e, index) {
        var row = $(e.target).closest("tr")
        if($("#checkbox-"+index).prop("checked")){
            $('#version-triangle-'+index).css({'pointer-events':'unset'})
            row.css({opacity: 1})
        }
        else{
            if(!(row.hasClass("an-selected"))){
                $('#version-triangle-'+index).css({'pointer-events':'none'})
                row.css({opacity: 0.7})
            }
        }
    }

    function closeVerDlg(e) {
        var row = $("#selectNFTable").find('tr.an-selected');
        var index = row.prop('id').split('-')[1];
        row.removeClass('an-selected');
        if(!($("#checkbox-"+index).prop('checked')))
            row.css({opacity: 0.7});
        $('#NFVerList').hide();
    }

    return {
        renderCreatePane: renderCreatePane,
        changeNFVersion: changeNFVersion,
        renderVersionInMuseum: renderVersionInMuseum,
        onClickVerList: onClickVerList,
        onSelectNF: onSelectNF,
        closeVerDlg : closeVerDlg
    }
})();