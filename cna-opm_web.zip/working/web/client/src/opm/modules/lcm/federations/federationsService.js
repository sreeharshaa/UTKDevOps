OPM$.lcm = OPM$.lcm || {};
OPM$.lcm.federations = OPM$.lcm.federations || {};

OPM$.lcm.federations.federationsService = (function() {
    'use strict';

    function renderChartsTree(repoName,chartName, version) {
        return GET_JSON$('/opm/repos/retrieveChart/'+repoName+'/'+chartName+'/'+version);
    }

    function getChartsList(chartRepoName, refresh) {
        var refreshInfo = typeof refresh !== "undefined" ? '?refresh='+refresh : '';
        return GET_JSON$('/opm/repos/listCharts/'+chartRepoName+refreshInfo)
    }

    function renderAllChartVersions(repoName, chartKeyword, preReqChartName, prereqChartVersion, refresh) {
        var chartVersionVal = (prereqChartVersion !== undefined)  ? '&version=' + prereqChartVersion : "",
            preReqChartNameVal = (preReqChartName !== undefined) ? '?chartName=' + preReqChartName : "";
        var refreshInfo = typeof refresh !== "undefined" ? '&refresh='+refresh : '';

        return GET_JSON$('/opm/repos/listChartsAllVersions/'+repoName + preReqChartNameVal + chartVersionVal + '?chartName=' + chartKeyword+refreshInfo);
    }

    function renderForm(name, dirName, selectedChart, upgradeDetails, tagAttr, format, instantiateDetails, prevChart) {
        //return GET_JSON$('../json/yamlEditorTest.json');
        var tagAttr = typeof tagAttr === "undefined" ? "" : '&tagAttr=true',
            format = typeof format === "undefined" ? "" : '&format='+format,
            prevChart = (typeof prevChart !== "undefined") ? '&previousChart='+prevChart: "";
        if (typeof upgradeDetails !== "undefined") {
            var clusterDetails = (typeof upgradeDetails.clusterId !== "undefined" && typeof upgradeDetails.dzId !== "undefined") ?
                '&clusterId=' + upgradeDetails.clusterId + '&deploymentZoneId=' + upgradeDetails.dzId : '';

            return GET_JSON$('/opm/repos/retrieveFile?dirName=' + dirName + '&fileName=' + name + '&chartName=' + selectedChart.name +
            '&repoName=' + selectedChart.repoName + '&version=' + selectedChart.version + '&releaseName=' + upgradeDetails.relName + '&namespace=' + upgradeDetails.namespace + clusterDetails + tagAttr + format + prevChart);
        } else if(typeof instantiateDetails !== "undefined"){
            return GET_JSON$('/opm/nfconfig/retrieveFile?dirName='+dirName+'&fileName='+name+'&chartName='+selectedChart.name+'&repoName='+selectedChart.repoName+'&version='+selectedChart.version +
            '&releaseName='+instantiateDetails.releaseName+'&namespace='+instantiateDetails.namespace+'&clusterId='+instantiateDetails.clusterId+'&deploymentZoneId='+instantiateDetails.dzId+'&nfAndPaasInstanceId='+ instantiateDetails.nfAndPaasInstanceId+tagAttr+format + prevChart);
        }
        else{
            return GET_JSON$('/opm/repos/retrieveFile?dirName=' + dirName + '&fileName=' + name + '&chartName=' + selectedChart.name + '&repoName=' + selectedChart.repoName + '&version=' + selectedChart.version + format + prevChart);
        }
    }

    function renderDependencies(component) {
        return GET_JSON$('/opm/cnf/retrievePaasListByComponent/'+component);
        //return GET_JSON$('../json/retrievePaasListByComponent.json');
    }

    function retrievePaasValues(values, jsonData) {
        return POST_JSON$({
            url: '/opm/cnf/retrievePaasValues/'+values.deploymentZoneId+'/'+values.clusterId+'/'+values.releaseName+'/'+values.namespace,
            data:  JSON.stringify(jsonData)
        });
        //return GET_JSON$('../json/dependencies.json');
    }

    function renderExistingForm(selectedChart, relName, format) {
        var format = typeof format === "undefined" ? "" : '?format='+format;
        return GET_JSON$('/opm/cnf/retrieveSavedValues/'+selectedChart.repoName+'/'+selectedChart.name+'/'+selectedChart.version+'/'+relName+format);
    }

    function saveFed(jsonData, selectedCluster, selectedChart, chartDetails, upgrade, override, format) {

        var override = typeof override === "undefined" ? "" : override,
            format = typeof format === "undefined" ?  "" : (override === "" ? '?format='+format : '&format='+format);

        var url = upgrade ? '/opm/cnf/upgradeCnf/'+selectedCluster.dzId+'/'+selectedCluster.id+'/'+selectedChart.repoName+'/'+selectedChart.name+'/'+selectedChart.version+'/'+chartDetails.releaseName+'/'+chartDetails.namespace+override+format :
            '/opm/cnf/install/'+selectedCluster.dzId+'/'+selectedCluster.id+'/'+selectedChart.repoName+'/'+selectedChart.name+'/'+selectedChart.version+'/'+chartDetails.releaseName+'/'+chartDetails.namespace+override+format;

        return POST_JSON$({
            url: url,
            data:  JSON.stringify(jsonData)
        });
    }

    function getDryRunResult(jsonData, selectedCluster, selectedChart, chartDetails, isUpgrade, format) {
        //console.log(isUpgrade)
        var operation = isUpgrade ? "upgradeCnf" : "install",
            format = typeof format !== "undefined" ? '&format='+format: "";
        return POST_JSON$({
            url: '/opm/cnf/'+operation+'/'+selectedCluster.dzId+'/'+selectedCluster.id+'/'+selectedChart.repoName+'/'+selectedChart.name+'/'+selectedChart.version+'/'+chartDetails.releaseName+'/'+chartDetails.namespace+'?dryrun=true'+format,
            data:  JSON.stringify(jsonData)
        });
    }

    function getHelmStatus(dzId, id, chartName, releaseName, operation) {
        return GET_JSON$('/opm/cnf/status/'+dzId+'/'+id+'/'+releaseName+'/'+chartName+'/'+operation)
    }

    function getCnfReleaseInfo(dzId, id, releaseName, namespace, depChart, depRevision, repoName) {
        if (_.isEmpty(depRevision) || _.isEmpty(depChart)) {
            MSG$.showErrorMsg({status: "Error", content: releaseName + " does not exist; The operation cannot be performed!"});
        } else {
            return GET_JSON$('/opm/cnf/getCnfReleaseInfo/' + dzId + '/' + id + '/' + releaseName + '/' + namespace + '/' + depChart + '/' + depRevision+'?chartRepo='+repoName);
        }
    }

    function performRollback(chartDetails, selChart, selCluster, override) {
        if(override) {
            override = '?override=true';
        } else {
            override = '';
        }
        return PUT_JSON$({
            url: '/opm/cnf/rollbackCnf/'+selCluster.dzId+'/'+selCluster.id+'/'+selChart.repoName+'/'+selChart.name+'/'+selChart.version+'/'+chartDetails.releaseName+'/'+chartDetails.namespace+override,
        });
    }

    function getFedInfo(details) {
        return GET_JSON$('/opm/cnf/getFedInfo/'+details.dzId+'/'+details.clusterId+'/'+details.relName+'/'+details.namespace)
    }

    function getImportStatus() {
        return GET_JSON$('/opm/repos/retrieveImportStatus');
    }

    function convertValues(formData, selectedChart, relName, namespace, format, nfAndPaasInstanceId) {
        return POST_JSON$({
            url: '/opm/cnf/convertValues/'+selectedChart.repoName+'/'+selectedChart.name+'/'+selectedChart.version+'?releaseName='+relName+'&namespace='+namespace+'&format='+format+'&nfAndPaasInstanceId='+nfAndPaasInstanceId,
            data:  JSON.stringify(formData)
        });
    }

    function renderPrerequisites(repoName,chartName, chartVersion) {
            return GET_JSON$("/opm/repos/retrievePrerequistes/" + repoName + "/" + chartName + "/" + chartVersion)
    }

    function renderAllPrerequisites(repoClusterVal,groupName, boolVal) {
        return POST_JSON$({url: "/opm/nfconfig/instantiateNetworkFunctions/"+repoClusterVal.repoName+"/"+repoClusterVal.selectedCluster.dzId
        +"/"+repoClusterVal.selectedCluster.id+"/"+groupName+"?override="+boolVal})
    }

    function createNfConfigPrereq(){
        return GET_JSON$("../json/getPrerequisites.json")
    }

    function bulkInstallFeds(repoClusterVal,groupName, boolVal, jsonData, issu, rollbackPolicy, abandon, dryRun) {
        var issuData = '&issu='+issu;
        if(issu){
            issuData = issuData+'&rollbackPolicy='+rollbackPolicy;
        }
        if(abandon){
            issuData = issuData+'&abandon='+abandon;
        }
        if(dryRun){ 
            issuData = issuData+'&dryRun=true';
        }
        return POST_JSON$({
            url: "/opm/nfconfig/installNetworkFunctions/"+repoClusterVal.repoName+"/"+repoClusterVal.selectedCluster.dzId
            +"/"+repoClusterVal.selectedCluster.id+"/"+groupName+"?override="+boolVal+issuData,
            data:  JSON.stringify(jsonData)
        });
    }

    function stopBulkInstallation(repoClusterVal,groupName, jsonData, issuOptionSelected) {
        var stopBulkUrl = "/opm/nfconfig/stopNetworkFunctionsInstall/";
        if(issuOptionSelected)
            stopBulkUrl = "/opm/nfconfig/abandon/";
        return PUT_JSON$({
            url: stopBulkUrl+repoClusterVal.selectedCluster.dzId
            +"/"+repoClusterVal.selectedCluster.id+"/"+groupName,
            data:  JSON.stringify(jsonData)
        });
    }

    function stopIssuInstallation(repoClusterVal,groupName, jsonData) {
        var stopBulkUrl = "/opm/nfconfig/stopIssuInstallation/";
        return PUT_JSON$({
            url: stopBulkUrl+repoClusterVal.selectedCluster.dzId
            +"/"+repoClusterVal.selectedCluster.id+"/"+groupName,
            data:  JSON.stringify(jsonData)
        });
    }

    function saveUpdatedChart(repoName, chartName, version, releaseName, namespace, nfAndPaasInstanceId, jsonData, format, groupName, override){
        var format = typeof format === "undefined" ? "?groupName="+groupName + "&override="+override : '?format='+format + "&groupName="+groupName + "&override="+override;
        return POST_JSON$({
            url: "/opm/nfconfig/saveComponentValues/"+repoName+"/"+chartName+"/"+version+"/"+releaseName+"/"+namespace+"/"+nfAndPaasInstanceId+format,
            data: JSON.stringify(jsonData)
        });
    }

    function retrieveUpdatedPrereq(repoName,dzId, clusterId, groupName){
        return GET_JSON$('/opm/nfconfig/getNetworkFunctionsTree/'+repoName+'/'+dzId+'/'+clusterId+'/'+groupName);
        //return GET_JSON$('../json/getPrerequisites.json');
    }

    function setupChartForDeployment(repoName,dzId,clusterId,chartName,version,action,jsonData){
        return POST_JSON$({
            url: "/opm/nfconfig/setupChartForDeployment/"+dzId+"/"+clusterId+"/"+repoName+"/"+chartName+"/"+version+"?action="+action, //add|remove
            data: JSON.stringify(jsonData)
        });
    }

    function createConfigSet(repoName,dzId,clusterId,nfConfigSetName,overrideBoolVal,jsonData){
        return POST_JSON$({
            url: "/opm/nfconfig/createNFConfigSet/"+dzId+"/"+clusterId+"/"+repoName+"/"+nfConfigSetName+"?override="+overrideBoolVal, //add|remove
            data: JSON.stringify(jsonData)
        });
    }

    function renderSharedValues(nfConfigSetName, refresh, jsonData, type, sharedParamType, repoClusterVal) {
        if(sharedParamType === 'overlay') {
            return GET_JSON$('/opm/nfconfig/getOverlayConf/' + nfConfigSetName);
        } else if (sharedParamType === 'inherited'){
                var configType = '?'
                if(type === 'simplifiedConfig') 
                    configType = '?type=simplified'+'&';
                else if(type === 'snapshotConfig')
                    configType = '?type=snapshot'+'&';
                return GET_JSON$('/opm/nfconfig/getNFSharedParameters/' + nfConfigSetName + configType + 'chartRepoName='+repoClusterVal.repoName); 
        }
        else {
            if (refresh) {
                return POST_JSON$({
                    url: '/opm/nfconfig/refreshSharedParametersUsingSavedValues/' + nfConfigSetName,
                    data: JSON.stringify(jsonData)
                });
            }
        }
    }
    
    function getAllSharedParamSets() {
        return GET_JSON$('/opm/nfconfig/getNFSharedParametersSets');
    }
    
    function saveSharedValues(nfConfigSet, jsonData, type, sharedParamType, helmOptionsParam) {
        if(sharedParamType === "inherited") {
            return POST_JSON$({
                url: '/opm/nfconfig/saveNFSharedParameters/' + nfConfigSet + '?type='+ type,
                data: JSON.stringify(jsonData)
            })
        } else if(sharedParamType === "overlay") {
            return POST_JSON$({
                url: '/opm/nfconfig/saveOverlayConf/' + nfConfigSet,
                data: JSON.stringify(jsonData)
            })
        } else if(sharedParamType === "helmOptions") {
            return POST_JSON$({
                url: '/opm/nfconfig/saveNFHelmOptions/' + nfConfigSet+'?chartRepoName='+helmOptionsParam.repoName
                        +'&dzId='+helmOptionsParam.dzId+'&clusterId='+helmOptionsParam.clusterId,
                data: JSON.stringify(jsonData)
            })
        }
    }

    function showPerFedHelmOptions(nfConfigSetName, chartRepoName, dzId, clusterId){
        return GET_JSON$('/opm/nfconfig/getNFHelmOptions/'+nfConfigSetName+'?chartRepoName='+chartRepoName+'&dzId='+dzId+'&clusterId='+clusterId);
    }

    function updateConfigNF(chartName, repoName, version, snapshotName){
        return PUT_JSON$({
            url: '/opm/nfconfig/updateNFInSnapshot/'+repoName+'/'+chartName+'/'+version+'/'+snapshotName,
            data:  JSON.stringify({})
        });
    }

    return {
        renderChartsTree: renderChartsTree,
        getChartsList: getChartsList,
        renderForm: renderForm,
        saveFed: saveFed,
        getDryRunResult: getDryRunResult,
        getHelmStatus: getHelmStatus,
        renderExistingForm: renderExistingForm,
        renderDependencies: renderDependencies,
        retrievePaasValues: retrievePaasValues,
        renderAllChartVersions: renderAllChartVersions,
        getCnfReleaseInfo: getCnfReleaseInfo,
        performRollback: performRollback,
        getFedInfo: getFedInfo,
        getImportStatus: getImportStatus,
        convertValues: convertValues,
        renderPrerequisites: renderPrerequisites,
        renderAllPrerequisites: renderAllPrerequisites,
        createNfConfigPrereq: createNfConfigPrereq,
        bulkInstallFeds : bulkInstallFeds,
        stopBulkInstallation: stopBulkInstallation,
        stopIssuInstallation: stopIssuInstallation,
        saveUpdatedChart: saveUpdatedChart,
        retrieveUpdatedPrereq: retrieveUpdatedPrereq,
        setupChartForDeployment: setupChartForDeployment,
        createConfigSet: createConfigSet,
        renderSharedValues: renderSharedValues,
        getAllSharedParamSets: getAllSharedParamSets,
        saveSharedValues: saveSharedValues,
        updateConfigNF: updateConfigNF,
        showPerFedHelmOptions: showPerFedHelmOptions
    }

})();