## **SMF Service overview**

The SMF Network Function in the 5G Core Network interacts with other
components of the 5G core network to facilitate following key
functionalities

1.  Creation, modification, and deletion of PDU Sessions

2.  Management of UE IP address allocation and DHCP functions

3.  Termination of NAS signaling.

4.  UE authentication

5.  Network resource optimization and Network slice selection

6.  Charging and Qos flow maintenance

7.  Support for 4G PGW-C functionality to seamlessly hand session off
    between 4G and 5G network technology, allowing for a migration from
    today’s 3G/4G networks to 5G technology

### **SMF interfaces**

Table 1 shows the services supported by SMF. The service operations
exposed by the Nsmf\_PDUSession Service allow other NFs to establish,
modify and release PDU sessions. The Nsmf\_EventExposure Service allows
consumer NFs to subscribe and unsubscribe for events on a PDU session
and notifies consumer NFs about observed events on the PDU session.
Below figure shows the Network functions that SMF interfaces with and
provides services
to.

| Service Name        | Description                                                                                                                                                                                                                     | Example Consumer  |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- |
| Nsmf\_PDUSession    | This service manages the PDU sessions and uses the policy and charging rules received from the PCF. The service operations exposed by this NF service allows the consumer NFs to establish, modify and delete the PDU sessions. | V-SMF, H-SMF, AMF |
| Nsmf\_EventExposure | This service exposes the events happening on the PDU sessions to the consumer NFs.                                                                                                                                              | PCF, NEF, AMF     |

### **SMF Federation**

The SMF service will run in a cluster as part of a Federation and will
be implemented by multiple microservices interacting natively with each
other providing end to end 5G service to the end user.

Each microservice will be implemented in a pod that will contain one or
more containers. The pods and containers running in the SMF federation
are shown in Figure 4 below. Multiple instances of the same pod will be
instantiated for high availability, load balancing and scalability.

Every pod will run an “infra” container that will contain side-cars to
facilitate configuration, Flex Block management, service ID
registration, inter-pod messaging etc.

The next sections describe details of each microservice/pod that is part
of the SMF service.

##### **smf\_ call\_control pod**

The smf\_call\_control pod implements the SMF control plane signaling
procedures.

smfcc container runs in this pod along with the infra container.
