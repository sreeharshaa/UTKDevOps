OPM$.websocket = (function () {
    var isWebSocketConnected = false,
        webSocket = null,
        //secure websocket establishment
        wsUri =  "wss://" + location.host + "/opm/wsNotification" +"?authentication=" + Cookies.get('authorization'),
        //unsecure websocket establishment
        //wsUri =  "ws://" + location.host + "/opm/wsNotification",
        //t1 = null, t2 = null, tx = null,
        reconnectInterval = null;

    function webSocketConnect(){
        if(!isWebSocketConnected){
            webSocket = new WebSocket(wsUri);
            webSocket.onopen = function(evt){
                isWebSocketConnected = true;
                console.log("Opened connection");
                sendHeartbeat();
            };
            webSocket.onmessage = function(evt){ onMessage(evt)};
            webSocket.onerror = function(evt){ onError(evt)};
            webSocket.onclose = function(evt){
                console.log('Closed Connection');
                if(isWebSocketConnected){
                    reconnect();
                }
                isWebSocketConnected = false;
            };
        }
    }

    /**
     * config - uri, openFn, messageFn, errorFn, closeFn
     */
    function customWebSocketConnect(config) {
        if(!_.isEmpty(config) && !_.isEmpty(config.uri)){
            var ws = new WebSocket(config.uri);
            ws.onopen = config.openFn || console.log('open fn not defined');
            ws.onmessage = config.messageFn || console.log('message fn not defined');
            ws.onerror = config.errorFn || console.log('error fn not defined');
            ws.onclose = config.closeFn || console.log('close fn not defined');
            return ws;
        }
    }

    function webSocketDisConnect(){
        if(isWebSocketConnected){
            webSocket.close();
        }
    }

    function onMessage(evt){
        if(isJson(evt.data)){
            var jsonData = JSON.parse(evt.data);
            if(jsonData.type){
                PUBSUB$.publish(jsonData.type, jsonData.data);
            }
        }else{
            //returns just string indication a heartbeat message
            //console.log('heartbeat message: ' + evt.data);
        }
    }

    function isJson(str){
        try{
            JSON.parse(str);
        }catch(e){
            return false;
        }
        return true;
    }

    function onError(evt){
        //console.log(evt);
        //console.log("Error: " + evt.data);
        console.log('Error Connection');
    }

    function sendText(txt){
        //console.log("sending text: " + txt); // Object.prototype.toString.cal(bytes)
        if(isWebSocketConnected){
            webSocket.send(txt);
        }
    }

    /*
     *   300076ms(~5min) is connection default timeout
     *   Sending heartbeats for 270000ms(4min 30sec)
     */
    function sendHeartbeat(){
        //var tmp = new Date().getTime();
        //console.log('interval time: ' + (tmp -tx));
        //tx = tmp;
        if(isWebSocketConnected){
            sendText('heartbeat');
            setTimeout(sendHeartbeat, 270000); // heart-beat for every 4:30 min
        }
    }

    // Re-connect WS connection
    function reconnect() {
        reconnectInterval = setInterval(function () {
            if(isWebSocketConnected){
                clearInterval(reconnectInterval)
            }else{
                webSocket.close();
                webSocketConnect();
            }
        }, 3000);
    }

    function isWSConnected(){
        return isWebSocketConnected;
    }

    return {
        webSocketConnect: webSocketConnect,
        customWebSocketConnect: customWebSocketConnect,
        isWSConnected: isWSConnected
    }

})();