OPM$.repoManagement = OPM$.repoManagement || {};

OPM$.repoManagement.repoService = (function() {

    function getAllChartRepos() {
        //return GET_JSON$('../json/getAllCharts.json');
        return GET_JSON$('/opm/repos/getAllChartRepos');
    }

    function getAllImageRepos() {
        //return GET_JSON$('../json/getAllCharts.json');
        return GET_JSON$('/opm/repos/getAllImageRepos');
    }

    function getChartRepo(name) {
        //return GET_JSON$('../json/getChart.json');
        return GET_JSON$('/opm/repos/getChartRepo/'+name);
    }

    function getImageRepo(name) {
        //return GET_JSON$('../json/getChart.json');
        return GET_JSON$('/opm/repos/getImageRepo/'+name);
    }

    function doDeleteChartRepo(name) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/repos/deleteChartRepo/'+name});
    }

    function doDeleteImageRepo(name) {
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/repos/deleteImageRepo/'+name});
    }

    function saveChartRepo(jsonData) {
        return POST_JSON$({
            url: '/opm/repos/saveChartRepo',
            data: JSON.stringify(jsonData)
        });
    }

    function saveImageRepo(jsonData) {
        return POST_JSON$({
            url: '/opm/repos/saveImageRepo',
            data: JSON.stringify(jsonData)
        });
    }

    function getNFList() {
        return GET_JSON$('../json/createNFConfig1.json');
    }

    return {
        getAllChartRepos : getAllChartRepos,
        getAllImageRepos: getAllImageRepos,
        getImageRepo: getImageRepo,
        getChartRepo: getChartRepo,
        saveChartRepo: saveChartRepo,
        saveImageRepo: saveImageRepo,
        doDeleteChartRepo: doDeleteChartRepo,
        doDeleteImageRepo: doDeleteImageRepo,
        getNFList: getNFList
    };

})();