OPM$.repoManagement = OPM$.repoManagement || {};

OPM$.repoManagement.repoController = (function() {
    var chartInstance=[], dockerInstance = [], selectedTab="",
        selectedRepo = "";

    function launchRepoManagerDialog() {
        if($('#repoManager').length == 0) {
            var html = Handlebars.templates['repoManagement_repoManager']();
            $('body').append(html);

            renderChartForm();

            $("#repoManager").hide().fadeIn().draggable({
                handle: "header"
            }).position({
                my: "center",
                at: "center",
                of: "body"
            });
            setTimeout( function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                $('#repoManager :tabbable')[0].focus();
            }, 0)
            
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#repoManager'));
            
            /*
            //CN-43500: Commenting out tabs feature and docker registry in repo management
            selectedTab = $("#chartsTab");
            var $tabs = $("#repoManager").find("header").find(".an-inline-tabs");
            $tabs.find('li').on('click', function (e) {
                selectedTab = $(this);
		        var currTab = $tabs.find('.an-selected');
		        if ($('#createRepoDlg').is(':visible')) {
		            GCM$.common_functions.closeDialog('createRepoDlg');
                }

                if ($('#saveRepoBtn').attr('disabled') !== "disabled" && $('#saveRepoBtn').attr('disabled') !== true) {
                    $('#saveRepoBtn').attr('disabled', 'disabled');
                }

                currTab.removeClass("an-selected");
		        currTab.attr({'tabindex': -1, 'aria-selected': 'false'});
                selectedTab.addClass("an-selected");
		        selectedTab.attr({'tabindex': 0, 'aria-selected': 'true'});


                $("#repoManager").find(".an-tabbed-form").hide();
                selectedTab.css({"display": "flex"});

                if (this.id === 'chartsTab') {
                    $('#charts-content').show();
                    renderChartForm();
                    GCM$.accessibility.accessibilityCommon.setFocus($("#gridView"));
                } else if (this.id === 'dockImgsTab') {
                    $('#docker-content').show();
                    renderImageForm();
                }
            });
            GCM$.accessibility.tabAccessibility.tabKeyNav($tabs);
            */
        }
    }

    function createForm(e) {
        var html = Handlebars.templates['repoManagement_createRepoDialog']();
        if ($('#createRepoDlg').length === 0) {
            $(html).appendTo('#repoManager').position({
                my: "left top",
                at: "right+50 bottom",
                of: $(e.target)
            });
            VALIDATION$.validateOnInputChange($('#createRepoDlg'), $('#addRepoBtn'));
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#createRepoDlg'));
            //Adding setTimeout before calling focus() to allow for DOM attachment of the repo dialog.
            setTimeout( function () { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                $('#createRepoDlg :tabbable')[0].focus();
            }, 0)
            $('#createRepoDlg').on('dialogClose', function (e) {
                $("#createRepoButton")[0].focus();
                /*
                //CN-43500: Commenting out tabs feature and docker registry in repo management
                //identifying the correct '+' button wrt seected tab since both forms have the same '+' button id.
                if(selectedTab[0].id === "chartsTab")
                    $("#createRepoButton")[0].focus();
                else if(selectedTab[0].id === "dockImgsTab")
                    $("#createDockerImgBtn")[0].focus();
                    */
            });
        }
    }

    function onAddRepoName() {
        var name = $('#createRepoDlg').find('input').val();
        GCM$.common_functions.closeDialog('createRepoDlg');
        renderChartForm(name);
        /*
        //CN-43500: Commenting out tabs feature and docker registry in repo management
        if(selectedTab[0].id === "chartsTab"){
            renderChartForm(name);
        } else {
            renderImageForm(name);
        }
        */
    }

    function onSelectChart(e) {
        var selected = $(e.target).closest('select').val();
        selectedRepo = selected;
        renderChartForm(selected);
    }

    function onSelectImage(e) {
        var selected = $(e.target).closest('select').val();
        selectedRepo = selected;
        renderImageForm(selected);
    }

    function renderChartForm(name) {
        var formData = {
                repoList: [],
                name: "",
                host: "",
                port: "",
                protocol: "http",
                type: "",
                path: "",
                username: "",
                password: "",
                singleRepo: false
            },
           default_chartForm = {
            name: "",
            host: "",
            port: "",
            protocol: "http",
            type: "",
            path: "",
            username: "",
            password: "",
            singleRepo: false
        };
        if(typeof name !== "undefined"){
            OPM$.repoManagement.repoService.getAllChartRepos()
                .done(function (data1) {
                   _.assign(formData, data1);

                   if(data1.repoList.includes(name)){
                       //Render existing repo information

                       OPM$.repoManagement.repoService.getChartRepo(name)
                           .done(function (data) {
                               _.assign(formData, data);
                                if(formData.repoList.length === 1){
                                    formData.singleRepo = true;
                                }
                                else {
                                    formData.singleRepo = false;
                                }
                               var html = Handlebars.templates['repoManagement_chartForm'](formData);
                               $('#chartFormContainer').empty().append(html);
                               delete formData.repoList;
                               chartInstance = dataBindForm('#chartForm', formData);
                               VALIDATION$.validateOnInputChange($('#chartForm'), $('#saveRepoBtn'));
                               GCM$.accessibility.accessibilityCommon.setFocus($("#charts-content"));
                           });
                   } else {
                       //Add the new repo name to the list

                       formData.repoList.push(name);
                       formData.name = name;
                        if(formData.repoList.length === 1){
                            formData.singleRepo = true;
                        }
                        else {
                            formData.singleRepo = false;
                        }
                       var html = Handlebars.templates['repoManagement_chartForm'](formData);
                       $('#chartFormContainer').empty().append(html);
                       delete formData.repoList;
                       chartInstance = dataBindForm('#chartForm', formData);
                       VALIDATION$.validateOnInputChange($('#chartForm'), $('#saveRepoBtn'));
                       GCM$.accessibility.accessibilityCommon.setFocus($("#charts-content"));
                    }
            });
        } else {
            OPM$.repoManagement.repoService.getAllChartRepos()
                .done(function (data) {
                    formData= data;
                    if(data.repoList.length === 1){
                        default_chartForm.singleRepo = true;
                    }
                    var html = Handlebars.templates['repoManagement_chartForm'](data);
                    $('#chartFormContainer').empty().append(html);
                    chartInstance = dataBindForm('#chartForm', default_chartForm);
                    VALIDATION$.validateOnInputChange($('#chartForm'), $('#saveRepoBtn'));
                    var singleSelectBool = singleRepoAutoSelect(data.repoList,$('#chartform-name').parent().find('select').first())
                    setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                        if(singleSelectBool){
                            renderChartForm(data.repoList[0])
                            selectedRepo = data.repoList[0];
                        }
                    },100)
                });
        }
    }

    function dataBindForm(id, data) {
        var config = {
            el: id,
            data: data
        };
        return VUE$.createInstance(config);
    }

    function renderImageForm(name) {
        var formData = {
                repoList: [],
                name: "",
                host: "",
                port: "",
                path: "",
                protocol: "http",
                username: "",
                password: "",
                singleRepo: false
            },
            default_dockerForm = {
                name: "",
                host: "",
                port: "",
                path: "",
                protocol: "http",
                username: "",
                password: "",
                singleRepo: false
            };

        if(typeof name !== "undefined"){
            OPM$.repoManagement.repoService.getAllImageRepos()
                .done(function (data1) {
                    _.assign(formData, data1);

                    if(data1.repoList.includes(name)){
                        //Render existing repo information

                        OPM$.repoManagement.repoService.getImageRepo(name)
                            .done(function (data) {
                                _.assign(formData, data);
                                if(formData.repoList.length === 1){
                                    formData.singleRepo = true;
                                }
                                else {
                                    formData.singleRepo = false;
                                }
                                var html = Handlebars.templates['repoManagement_dockerForm'](formData);
                                $('#dockerFormContainer').empty().append(html);
                                delete formData.repoList;
                                dockerInstance = dataBindForm('#dockerForm', formData);
                                VALIDATION$.validateOnInputChange($('#dockerForm'), $('#saveRepoBtn'));
                                GCM$.accessibility.accessibilityCommon.setFocus($("#docker-content"));
                            });
                    } else {
                        //Add the new repo name to the list

                        formData.repoList.push(name);
                        formData.name = name;
                        if(formData.repoList.length === 1){
                            formData.singleRepo = true;
                        }
                        else {
                            formData.singleRepo = false;
                        }
                        var html = Handlebars.templates['repoManagement_dockerForm'](formData);
                        $('#dockerFormContainer').empty().append(html);
                        delete formData.repoList;
                        dockerInstance = dataBindForm('#dockerForm', formData);
                        VALIDATION$.validateOnInputChange($('#dockerForm'), $('#saveRepoBtn'));
                        GCM$.accessibility.accessibilityCommon.setFocus($("#docker-content"));
                    }
                });
        } else {
            OPM$.repoManagement.repoService.getAllImageRepos()
                .done(function (data) {
                    formData= data;
                    if(data.repoList.length === 1){
                        default_dockerForm.singleRepo = true;
                    }
                    var html = Handlebars.templates['repoManagement_dockerForm'](data);
                    $('#dockerFormContainer').empty().append(html);
                    dockerInstance = dataBindForm('#dockerForm', default_dockerForm)
                    VALIDATION$.validateOnInputChange($('#dockerForm'), $('#saveRepoBtn'));
                    var singleSelectBool = singleRepoAutoSelect(data.repoList,$('#dockerform-name').parent().find('select').first())
                    setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                        if(singleSelectBool){
                            renderImageForm(data.repoList[0]);
                            selectedRepo = data.repoList[0];
                        }
                    },100)
                });
        }
    }

    function deleteRepo() {
        onDeleteChart(selectedRepo);
        /*
        //CN-43500: Commenting out tabs feature and docker registry in repo management
        if(selectedTab[0].id == "chartsTab"){
            onDeleteChart(selectedRepo);
        } else {
            onDeleteDockerImage(selectedRepo);
        }
        */
    }

    function onDeleteChart(name) {
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete '+name+' chart repository?',
            position: {my: 'left top', at: 'right bottom', of: $(event.target)},
            yes: function () {
                $('#chartForm').activity();
                OPM$.repoManagement.repoService.doDeleteChartRepo(name)
                    .done(function (data) {
                        //Remove selected repo cookie if that repo has been deleted
                        if(typeof Cookies.get('selectedRepo') !== "undefined"){
                            if(!(data.repoList.includes(Cookies.get('selectedRepo')))){
                                Cookies.remove('selectedRepo');
                            }
                        }
                        renderChartForm();
                        MSG$.showInfoMsg({status: 'Success', content: 'Chart deleted successfully',
                        close: function() {
                            $('#chartForm :tabbable')[0].focus();
                        }});
                    }).always(function () {
                    $('#chartForm').activity(false);
                });
            },
            no: function() {
                $('#deleteRepoBtn')[0].focus();
                renderChartForm();
            },
            close: function() {
                $('#deleteRepoBtn')[0].focus();
            }
        });
    }

    function onDeleteDockerImage(name) {
        MSG$.confirm({
            statement: 'Delete Confirmation',
            question: 'Are you sure you want to delete '+name+' docker image repository?',
            position: {my: 'left top', at: 'right bottom', of: $(event.target)},
            yes: function () {
                $('#dockerForm').activity();
                OPM$.repoManagement.repoService.doDeleteImageRepo(name)
                    .done(function (data) {
                        renderImageForm();
                        MSG$.showInfoMsg({status: 'Success', content: 'Docker Image deleted successfully',
                            close: function() {
                                $('#dockerForm :tabbable')[0].focus();
                            }});
                    }).always(function () {
                    $('#dockerForm').activity(false);
                });
            },
            close: function() {
                $('#deleteRepoBtn')[0].focus();
                renderImageForm();
            }
        });
    }

    function saveData() {
        //if(selectedTab[0].id === "chartsTab"){
            var chartData = VUE$.getDataFromApp(chartInstance);
            $('#chartForm').activity();
            delete chartData.singleRepo;
            OPM$.repoManagement.repoService.saveChartRepo(chartData)
                .done(function (data) {
                    MSG$.showInfoMsg({status: 'Success', content: 'Chart repo saved successfully'});
                }).always(function () {
                $('#chartForm').activity(false);
            });
            /*
        } else {
            var dockerImageData = VUE$.getDataFromApp(dockerInstance);
            $('#dockerForm').activity();
            OPM$.repoManagement.repoService.saveImageRepo(dockerImageData)
                .done(function (data) {
                    MSG$.showInfoMsg({status: 'Success', content: 'Docker image saved successfully'});
                }).always(function () {
                $('#dockerForm').activity(false);
            });
        }
        */
    }

    // To check if repo list has single repo; If true then auto select
    function singleRepoAutoSelect(repoList, selectId$){
        if(repoList.length === 1){
            var option = selectId$.find('option[value="'+repoList[0]+'"]');
            $(option).attr('selected', true);
            selectId$.val(repoList[0]);
            selectId$.attr('readonly', 'readonly');
            return true;
        }
        return false;
    }

    return {
        launchRepoManagerDialog: launchRepoManagerDialog,
        onSelectImage: onSelectImage,
        onSelectChart: onSelectChart,
        createForm: createForm,
        saveData: saveData,
        deleteRepo: deleteRepo,
        onAddRepoName: onAddRepoName,
        singleRepoAutoSelect: singleRepoAutoSelect
    };

})();
