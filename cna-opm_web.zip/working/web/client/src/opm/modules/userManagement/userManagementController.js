OPM$.userManagement = OPM$.userManagement || {};

OPM$.userManagement.userManagementController = (function(){

    function launchUserManagementDlg(){
        if ($('#userManagementDlg').length < 1){
            var html = Handlebars.templates['userManagement_userManagement']();
            $('main > .an-layout-center-center').append(html);
            $("#userManagementDlg").hide().fadeIn().resizable().draggable({
                handle: "header"
            }).position({
                my: "center",
                at: "center",
                of: ".an-layout-center-center"
            });
        }
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#userManagementDlg'), false);
        renderAllUsers();
        renderCreateUserForm();
    }

    function renderCreateUserForm() {
        var userForm = Handlebars.templates['userManagement_userManagementForm']();
        $('#userForm').empty().append(userForm);
        $('#userManagementForm :tabbable')[0].focus();
        VALIDATION$.validateOnInputChange($("#userManagementForm"), $("#submitUser"), undefined, undefined, undefined, undefined, true);
    }

    function renderAllUsers() {
        OPM$.userManagement.userManagementService.getAllUsers().done(function (data) {
            OPM$.DzAndCluster.DzAndClusterController.loadTree(data.users, 'user-tree-content', renderUserForm, 'delete');
        })
    }
    
    function renderUserForm(e) {
        var $target = $(e.target);
        if($target.hasClass('delete')){
            deleteUser(e);
        }else{
            var name = $target.closest('li').attr('data-name');
            if(name !== undefined && name !== null && name!=="")
                getUserDetails(name);
        }
    }

    function getUserDetails(name){
        $('#userForm').activity()
        OPM$.userManagement.userManagementService.getUser(name).done(function (data){
            var userForm = Handlebars.templates['userManagement_userManagementForm'](data);
            $('#userForm').empty().append(userForm);
            VALIDATION$.validateOnInputChange($("#userManagementForm"), $("#submitUser"), undefined , undefined, undefined, undefined, true);
            $('#userManagementForm :tabbable')[0].focus();
        }).always(function (){
            $('#userForm').activity(false);
        })
    }

    function addUser(){
        var jsonData = $('#userManagementForm').serializeFormToJSON();
        delete jsonData.reenterPassword;
        OPM$.userManagement.userManagementService.createUser(jsonData).done( function (data){
            MSG$.showInfoMsg({status: 'Success', content: 'New user added successfully'});
            OPM$.DzAndCluster.DzAndClusterController.loadTree(data.users, 'user-tree-content', renderUserForm, 'delete');
            getUserDetails(jsonData.name);
        })
    }
    function updateUser(){
        MSG$.confirm({
            statement: "Confirm",
            question: "Are you sure you want to update user details?",
            yes: function () {
                var jsonData = $('#userManagementForm').serializeFormToJSON();
                delete jsonData.reenterPassword;
                OPM$.userManagement.userManagementService.updateUser(jsonData).done( function (data){
                    MSG$.showInfoMsg({status: 'Success', content: 'User updated successfully'});
                    OPM$.DzAndCluster.DzAndClusterController.loadTree(data.users, 'user-tree-content', renderUserForm, 'delete');
                    getUserDetails(jsonData.name);
                })
            },

            close: function () {
                $('#userManagementForm :tabbable')[0].focus();
            }
        })
    }
    function deleteUser(e, username){
        MSG$.confirm({
            statement: "Confirm",
            question: "Are you sure you want to delete user?",
            yes: function () {
                var name;
                if(typeof username === 'undefined'){
                    var $target = $(e.target);
                    name = $target.closest('li').attr('data-name');
                }
                else 
                    name = username;
                deleteAndUpdateList(name);
        },
            close: function () {
                $('#userManagementForm :tabbable')[0].focus();
            }
        });
    }

    function deleteAndUpdateList(name){
        $('#userList').activity()
            OPM$.userManagement.userManagementService.deleteUser(name).done(function (data){
                MSG$.showInfoMsg({status: 'Success', content: 'User deleted successfully'});
                renderCreateUserForm();
                OPM$.DzAndCluster.DzAndClusterController.loadTree(data.users, 'user-tree-content', renderUserForm, 'delete');
            }).always(function (){
                $('#userList').activity(false)
            })
    }

    
    return {
        launchUserManagementDlg: launchUserManagementDlg,
        addUser: addUser,
        updateUser: updateUser,
        deleteUser: deleteUser,
        renderCreateUserForm: renderCreateUserForm,
        renderAllUsers: renderAllUsers
    }
})();