OPM$.userManagement = OPM$.userManagement || {};

OPM$.userManagement.userManagementService = (function(){

    'use strict';

    function getUserGroups() {
        return GET_JSON$('/opm/userManagement/userAndGroup');
    }

    function createUser(jsonData) {
        return POST_JSON$({
            url: '/opm/userManagement/userAndGroup/createUser',
            data: JSON.stringify(jsonData)
        });
    }

    function getUser(guid) {
        return GET_JSON$('/opm/userManagement/userAndGroup/user/' + guid);
    }

    function getAllUsers() {
        return GET_JSON$('/opm/userManagement/userAndGroup/users');
    }

    function updateUser(jsonData) {
        return PUT_JSON$({
            url: '/opm/userManagement/userAndGroup/updateUser',
            data: JSON.stringify(jsonData)
        });
    }

    function deleteUser(guid) {
        return DELETE_JSON$({
            url: '/opm/userManagement/userAndGroup/deleteUser/' + guid
        });
    }

    function getUserFromToken(){
        return GET_JSON$('/opm/userManagement/userAndGroup/userInfo');
    }
    
    return {
        getUserGroups : getUserGroups,
        createUser: createUser,
        getUser : getUser,
        getAllUsers: getAllUsers,
        updateUser: updateUser,
        deleteUser: deleteUser,
        getUserFromToken: getUserFromToken
    }
})();
