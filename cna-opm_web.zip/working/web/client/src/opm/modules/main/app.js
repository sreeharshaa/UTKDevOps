OPM$.app = (function(){
    'use strict';
    var lastActivity = 0,
    maxInactivity = 1800 , //30 mins
    interval = 1000,
    logoutTime = Date.now() + maxInactivity * 1000,
    username = "",
    userPrefs = {
        userPreferences: "{}"
    };
    
    function init(){
    if((Cookies.get("externalAuth") === undefined || Cookies.get("externalAuth") === null || Cookies.get("externalAuth") !== "true") && (Cookies.get('authorization') === null || Cookies.get('authorization') === undefined)){
            window.location = '/';
    }else {
        // calling this to Get username and externaAuth from API GW
        OPM$.userManagement.userManagementService.getUserFromToken().done(function (data,status,xhr){
                Cookies.set("externalAuth", data.externalAuth); //xhr.getResponseHeader('externalAuth'));
                Cookies.set("username", data.username); //xhr.getResponseHeader('username'))


                if((Cookies.get("externalAuth") === undefined || Cookies.get("externalAuth") === null || Cookies.get("externalAuth") !== "true") && (Cookies.get('authorization') === null || Cookies.get('authorization') === undefined)){
                    window.location = '/';
                }else {
                

                    Handlebars.partials = Handlebars.templates;
                    GCM$.common_functions.dataMemberHelpers();
                    handlebarsHelpers();

                    GCM$.common_functions.setLoginUrl('/client/output/index.html');
                    OPM$.layout.init();
        
                    //$(document).on("click", function() {
                    //    $("#toolsMenu").slideUp();
                    //});

                    GCM$.common_functions.registerDialogsToPolyfill();

                    $(document).ready(function () {
                        OPM$.app.userActivityTracker();
                        GCM$.common_functions.initialize();
                        GCM$.common_functions.initializeTheme();
        
                        // Add Notification module. Inject array of notifications object as 3rd argument when list of notifications are readily available
                        GCM$.notification.init("header>div.an-toolbar", "main", undefined, true);

                        // Event-Subscription
                        subscribeToEvents();

                        //Can be moved to GCM initializeTheme()
                        var theme = Cookies.get("an-theme");
                        if (theme === "undefined" || theme === undefined || theme === "light") {
                            $("#lightTheme").addClass('focus');
                        } else {
                            $("#" + theme + "Theme").addClass('focus');
                        }

                        OPM$.cloudMap.cloudMapController.renderGeoMap();
                    });	

                    var username = Cookies.get("username");
                
                    $("#loggedInUser").append(username);

                    // WebSocket
                    OPM$.websocket.webSocketConnect();

                    document.getElementById("toolsIcon").focus();
                }	

                OPM$.cloudMap.cloudMapService.getUserPreferences()
                    .done(function (data) {
                        if (typeof data !== "undefined" & !_.isEmpty(data.userPreferences)) {
                            OPM$.app.userPrefs = data;
                        }
                });
                OPM$.certManagement.certController.checkCertificateExpiry();
        })
        .fail(function (error) {
                    console.log("In logout err block:")
                    console.log(error)
                    MSG$.showServiceErrorMsg(error);
            })
        .catch(function (error){
            // When the JWT token is expired/corrupted the userInfo call gets into catch block since response is coming as 200
            // Make sure the condition is proper?
            if(error.responseText == "") {
                Cookies.remove('authorization');
                Cookies.remove("username");
                window.location = '/';
            }
        })
    }

    }

    function handlebarsHelpers() {

        Handlebars.registerHelper('stripSpaces', function (str) {
            if(str && typeof str === "string") {
                var stringArray = [];
                stringArray = str.split(" ");
                return stringArray.join("");
            }
            return '';
        });

        Handlebars.registerHelper('convertJsonToString', function (observability) {
            var temp = { "observability": observability };
            return JSON.stringify(temp);
        });

        Handlebars.registerHelper('if_selected_deploymentZones', function(deploymentZones, options) {

            _.forEach(deploymentZones, function(val) {
                if (val.selected === true) {
                    return true;
                }
            });
        });

        Handlebars.registerHelper('cn_status', function(status) {
            return new Handlebars.SafeString("cn-status-" + status);
        });

        Handlebars.registerHelper('lowerPosition', function(posy) {
            return +posy + 8;
        });

        Handlebars.registerHelper('smallPaasCookie', function(checkbox) {
            if(typeof Cookies.get('an-paas-style') === "undefined"
                || Cookies.get('an-paas-style') === "true"){
                if(checkbox === "checkbox"){
                    return 'checked';
                } else {
                    return 'cn-small-paas';
                }
            }
        });

        Handlebars.registerHelper('determineStepNumber', function(index) {
            return index+1;
        });

        Handlebars.registerHelper('checkIfPostStep', function(index, stepsLength) {
            if(index == stepsLength-1){
                return true;
            } else {
                return false;
            }
        });

        Handlebars.registerHelper('checkAzIcon', function(index, type) {
            if(index == "azure"){
                return true;
            } else {
                return false;
            }
        });

        Handlebars.registerHelper('convertArrayToJson', function(context) {
            var data = {
                "containers" : context
            };
            return JSON.stringify(data);
        });

        Handlebars.registerHelper('getStateByCookie', function(id) {
            var cookie = Cookies.get(id);
            if(cookie === "expanded") {
                return 'an-expanded';
            } else if(cookie === "collapsed") {
                return 'an-collapsed';
            } else {
                return 'an-expanded';
            }
        });

        Handlebars.registerHelper('getIconByCookie', function(id) {
            var cookie = Cookies.get(id);
            if(cookie === "expanded") {
                return 'scroll_triangle_down_dark';
            } else if(cookie === "collapsed") {
                return 'scroll_triangle_right_dark';
            } else {
                return 'scroll_triangle_down_dark';
            }
        });

        Handlebars.registerHelper('getIcon', function(type) {
            if($.isArray(type)){
                var icons = "";
                _.forEach(type, function (eachType) {
                    if(eachType === "AWS"){
                        icons = icons + ' cn-dz-aws';
                    } else {
                        icons = icons + ' cn-dz-'+eachType;
                    }
                });
                return icons;
            } else {
                if (type === "openstack") {
                    return 'an-icon-openstack2';
                } else if (type === "AWS") {
                    return 'an-icon-aws';
                } else if (type === "azure" || type === "Azure"){
                    return 'azure';
                }else {
                    return type;
                }
            }
        });

        Handlebars.registerHelper('azIconCheck', function(type) {
            if (type === "azure" || type === "Azure"){
                return options.inverse(this);
            } else {
                return options.fn(this);
            }
        });

        Handlebars.registerHelper('hide_if', function (v1, v2, options) {
            if(v1 || v2)
                return options.inverse(this);
            else
                return options.fn(this);
        });
    }

    function changeTheme() {
        if (Cookies.get("an-theme")) {
            Cookies.remove("an-theme");
            $("#an-dark-theme").insertBefore("#an-light-theme");
            $(".an-change-theme").find('a').text("Dark Mode").end().find(".an-icon-sun").removeClass("an-icon-sun").addClass("an-icon-night");
        } else {
            Cookies.set("an-theme","dark", {expires: 365});
            $("#an-light-theme").insertBefore("#an-dark-theme");
            $(".an-change-theme").find('a').text("Light Mode").end().find(".an-icon-night").removeClass("an-icon-night").addClass("an-icon-sun");
        }
    }

    function onThemeChange(e){
        var li = $(e.target).closest('li.leaf');
        _.forEach(li.parent().children(), function (el){
            $(el).removeClass('focus');
           });
        li.addClass('focus');
        li.prop('aria-selected', true);
    }

    /**
     * Subscribe to events using PUBSUB module.
     */
    function subscribeToEvents() {
        PUBSUB$.subscribe(OPM_EVENTS$.SHOW_CONSOLE, OPM$.lcm.federations.federationsController.updateStatus);
        PUBSUB$.subscribe(GCM_EVENTS$.NOTIFICATION, handleNotification);
        //launch import dialog to show the status on event IMPORT_STATUS
        PUBSUB$.subscribe(OPM_EVENTS$.IMPORT_STATUS, OPM$.lcm.federations.federationsController.launchImportDialog);
        PUBSUB$.subscribe(OPM_EVENTS$.FED_INFO, OPM$.lcm.federations.federationsController.updateFedInLcm);
        PUBSUB$.subscribe(OPM_EVENTS$.CLOUD_PLATFORM, OPM$.cloudMap.cloudMapController.updateCloudMap);
        PUBSUB$.subscribe(OPM_EVENTS$.PRE_CANARY, OPM$.lcm.upgradeCampaign.upgradeCampaignController.preCanaryStatus);
        PUBSUB$.subscribe(OPM_EVENTS$.NF_INSTALL_STATUS, OPM$.lcm.federations.federationsController.updateNFInstallStatus);
        PUBSUB$.subscribe(OPM_EVENTS$.NF_OPERATION_STATUS, OPM$.lcm.federations.federationsController.showConfigSetOpStatus);
        PUBSUB$.subscribe(OPM_EVENTS$.MANAGED_TREE_UPDATES, OPM$.DzAndCluster.DzAndClusterController.renderManagedTree);
        PUBSUB$.subscribe(OPM_EVENTS$.USER_MANAGEMENT_STATUS, OPM$.userManagement.userManagementController.renderAllUsers);
    }

    function onLogout(userBool) { 
        var header = new Headers();
        if(Cookies.get('authorization') !== undefined && Cookies.get('authorization') !== null ){
            header.append('authorization', 'Bearer ' + Cookies.get('authorization'));
            fetch('/opm/logout?userLogout='+userBool, {
                method: 'GET',
                headers: header,
                keepalive: true
            })
            .then(function (data) {
                    Cookies.remove('authorization');
                    Cookies.remove("username");
                    window.location = '/';
                    Cookies.set('logout', true);
            })
            .catch(function (error) {
                    MSG$.showServiceErrorMsg(error);
                    MSG$.showMsg({status: "Alert", content: "Logging out ..."});
                    setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                        Cookies.remove('authorization');
                        Cookies.remove("username");
                        window.location = '/';
                        Cookies.set('logout', true);
                    }, 1000)
            })
        }
    else if(Cookies.get('appId') !== undefined && Cookies.get('appId') !== null){
        fetch('/oauth2/sign_out', {
            method: 'GET',
            keepalive: true,
            mode: 'no-cors'
        })
        .then(function (data) {
            window.location = 'https://login.microsoftonline.com/'+Cookies.get('appId')+'/oauth2/v2.0/logout'
        });
    }
    else{
        fetch('/oauth2/sign_out', {
            method: 'GET',
            keepalive: true,
            mode: 'no-cors'
        })
        .then(function (data) {
            window.location = 'https://login.microsoftonline.com/common/oauth2/v2.0/logout'
        });
    }
    }

    function userActivityTracker(){
        setInterval(function(){
            var inactivityCount = Math.floor((logoutTime - Date.now())/ 1000);
            // if(lastActivity == (maxInactivity - 120)){
            //     MSG$.showErrorMsg({status: "Alert", content: "Session will end in two minutes"});
            // }
            if(inactivityCount < 0){
                OPM$.app.onLogout(false)
            }
        },interval)

        var activityEvents = ['mousedown', 'mousemove', 'keyup', 'scroll', 'touchstart']

        _.forEach(activityEvents, function(event, i){
            document.addEventListener(event, function(){ logoutTime = Date.now() + maxInactivity * 1000 }, true);
        })
    }

    /*
    * Reset the logout time when user is active during API operations like bulk installs, upgrades etc.
    */
    function resetLogoutTime(){
        logoutTime = Date.now() + maxInactivity * 1000;
    }

    function updateMaxInactivity(inactivity){
        maxInactivity = inactivity;
    }

    function handleNotification(notification){
        notification.groupId = notification.deploymentZoneId +'|'+notification.clusterId;
        notification.groupName = [ notification.dzName, notification.clusterName];
        if(typeof notification.operation !== "undefined" && notification.operation !== null) {
            notification.subgroupId = notification.operation + '|' +notification.snapshotName;
            notification.subgroupName = [ notification.operation, notification.snapshotName];
        }
        GCM$.notification.handleNotification(notification, true);
        OPM$.app.resetLogoutTime();
    }

    return {
        init: init,
        changeTheme: changeTheme,
        onThemeChange: onThemeChange,
        onLogout: onLogout,
        userActivityTracker: userActivityTracker,
        handleNotification: handleNotification,
        resetLogoutTime: resetLogoutTime,
        updateMaxInactivity: updateMaxInactivity,
        userPrefs: userPrefs
    }
})();


$(document).ready(OPM$.app.init);
