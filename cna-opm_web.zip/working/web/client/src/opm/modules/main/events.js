OPM$ = OPM$ || {};

/**
 * Publisher/Subscriber events related to OPM are enumerated here.
 * Event -> Action
 * SHOW_CONSOLE -> Show (or open) console
 */
OPM$.events = {
    SHOW_CONSOLE: "CONSOLE",
    FED_INFO: "fedInfo",
    IMPORT_STATUS: "showImportStatus",
    CLOUD_PLATFORM: "CLOUD_PLATFORM",
    PRE_CANARY: "PreCanary",
    NF_INSTALL_STATUS: "NFInstallStatus",
    NF_OPERATION_STATUS: "NFConfigSetOperation",
    MANAGED_TREE_UPDATES: "MANAGED_TREE",
    USER_MANAGEMENT_STATUS: "UserManagementStatus"
};

const OPM_EVENTS$ = OPM$.events;