OPM$.layout = (function(){
    'use strict';
    var cniLayout, southLayout;

    function init(){
        var html = Handlebars.templates['main_layout']();
        $(document.body).append(html).fadeIn("slow");

        cniLayout = $('body').layout({
            applyDefaultStyles:         false,
            center__paneSelector:       ".ui-layout-center",
            center__initClosed:         false,
            north__paneSelector:        ".ui-layout-north",
            north__initClosed:          false,
            north__size:                44,
            north__maxSize:             44,
            north__minSize:             44,
            togglerLength_open:         0,
            togglerLength_closed:       0,
            spacing_open:               0,
            spacing_closed:             0,
            stateManagement__enabled:   true,
            useStateCookie:             true
        });

        southLayout = $('.ui-layout-center').layout({
            applyDefaultStyles:         false,
            togglerTip_open:            'Hide Console',
            togglerTip_closed:          'Show Console',
            center__paneSelector:       '.an-layout-center-center',
            center__size:               100,
            south__paneSelector:        '.an-layout-center-south',
            south__size:                typeof Cookies.get('consoleHeight') !== 'undefined' ? Cookies.get('consoleHeight') : '25%',
            south__initClosed:          true,
            south__onresize: function () {
                Cookies.set('consoleHeight',$('.an-layout-center-south').height(), {expires : 365} );
            }
        });

        //$("#logoContainer").append(Handlebars.templates["logo"]);
        $(".ui-layout-center").prepend(Handlebars.templates["tools_toolsMenu"]());  
        //Updating console status pane position to avoid main view being pushed under toolbar
        $(".an-layout-center-south").css('position', 'fixed');    
        document.body.addEventListener('touchmove', function(e) {
            e.preventDefault();
        });

        $('div.ui-layout-toggler.ui-layout-toggler-south').on('click', function (e){
            setTimeout(function (){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                if($('div.ui-layout-toggler.ui-layout-toggler-south').hasClass('ui-layout-toggler-open'))
                    openSouth();
                else
                    closeSouth();
            },500)
        })

        $('#toolsIcon').on('click', toggleMainMenu);
        $('nav.an-quick-links ul li').on('keydown', function(e){
            if(e.keyCode === GCM_KEY$.ENTER){
                e.stopPropagation();
                e.preventDefault();
                $(this).trigger('click');
            }
        })
        GCM$.accessibility.menuAccessibility.makeMenuKeyNav($('#toolsMenu'), $('#toolsIcon'));
        GCM$.accessibility.menuAccessibility.makeMenuKeyNav($("#changeThemeMenu"),$("#change-theme"));
        OPM$.sysConfig.sysConfigService.getSysConfig().done(function (data) {
            if(data.mode == "multiNode" && data.azure == false){
                $("#opmModeToggleParent").css("display","block");
                if(data.systemConfig.globalStandbyMode != null || data.systemConfig.globalStandbyMode != undefined){
                    $('#globalStandbyModeToggle input').prop('checked', !data.systemConfig.globalStandbyMode);
                    if(data.systemConfig.globalStandbyMode)
                        $('#globalStandbyModeToggle').attr('title', "Standby mode");
                    else 
                        $('#globalStandbyModeToggle').attr('title', "Active mode");
                }
            }
        });
    }

    function openSouth(){
        southLayout.open('south');
        $('#consolePaneIcon').addClass('focus-icon');
        $("#consoleSection").find(":focusable").first().focus();
        $('#consolePaneIcon').attr('aria-expanded', 'true');
    }
    function closeSouth(){
        southLayout.close('south');
        $('#consolePaneIcon').removeClass('focus-icon')
        $('#consolePaneIcon').focus();
        $('#consolePaneIcon').attr('aria-expanded', 'false');
    }

    function toggleMainMenu(e) {
        closeMainMenu(e);
        openMainMenu(e);
    }

    
    function openMainMenu(e) {
	    e.stopPropagation();
	    if (!($('#toolsMenu').is(':visible'))) {
            GCM$.common_functions.slideUpAllMenus();
            $('#toolsMenu').slideDown();
            $('#toolsMenu').css('right', 0);
            $('#toolsIcon').attr('aria-expanded', 'true');
        }
    }

    function closeMainMenu(e) {
        if ($('#toolsMenu').is(':visible')) {
            e.stopPropagation();
            $('#toolsMenu').slideUp();
            $('#toolsIcon').attr('aria-expanded', 'false');
            $('#toolsIcon').focus();
        }
    }

    function toggleThemeMenu(e) {
        closeThemeMenu(e);
        openThemeMenu(e);
    }

    
    function openThemeMenu(e) {
        e.stopPropagation();
	    if (!($('#changeThemeMenu').is(':visible'))) {
            $('#changeThemeMenu').slideDown();
            $('#change-theme').attr('aria-expanded', 'true');
            setTimeout(function() {$('#lightTheme').focus()}, 700); // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
        }
    }

    function closeThemeMenu(e) {
        if ($('#changeThemeMenu').is(':visible')) {
            e.stopPropagation();
            $('#changeThemeMenu').slideUp();
            $('#change-theme').attr('aria-expanded', 'false');
            $('#change-theme').focus();
        }
    }

    return {
        init: init,
        openSouth: openSouth,
        closeSouth: closeSouth,
        toggleMainMenu: toggleMainMenu,
        toggleThemeMenu: toggleThemeMenu
    }
})();
