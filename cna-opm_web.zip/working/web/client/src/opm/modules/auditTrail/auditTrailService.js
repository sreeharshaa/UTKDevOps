OPM$.auditTrail = OPM$.auditTrail || {};

OPM$.auditTrail.auditTrailService = (function() {

    function getAuditTrailData(jsonData) {
        //return GET_JSON$('../json/auditTrail.json');
        return POST_JSON$({
            url: '/opm/auditTrail',
            data: JSON.stringify(jsonData)
        });
    }

    return {
        getAuditTrailData: getAuditTrailData
    };

})();