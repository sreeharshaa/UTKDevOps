OPM$.auditTrail = OPM$.auditTrail || {};

OPM$.auditTrail.auditTrailController = (function() {
    var auditTrailInstance,
        auditTrailData = {
            filter: {},
            pagination: {
                startRecord: 1,
                recordsPerPage: 25
            }
        };

    function launchAuditTrailDialog() {
        if($('#auditTrailDlg').length === 0) {

            OPM$.auditTrail.auditTrailService.getAuditTrailData(auditTrailData)
                .done(function (data) {
                    if(data.pagination.totalRecords == 0){
                        data.pagination.startRecord = 0;
                    }
                    if(_.isEmpty(data.entries)){ //Required for screen readers to detect the table on pressing T
                        data.entries.push({});
                    }
                    var html = Handlebars.templates['auditTrail_auditTrailDialog'](data);
                    $('main > .an-layout-center-center').append(html);

                    var vueConfig = {
                        el: "#auditTrailDlg",
                        data: data,
                        methods: [{
                            name: 'filterRecords',
                            method: function(filterStr){
                                auditTrailData.pagination.totalRecords = parseInt($("#totalRecords").val());

                                switch (filterStr) {
                                    case 'prev':
                                        auditTrailData.pagination.startRecord = auditTrailData.pagination.startRecord - auditTrailData.pagination.recordsPerPage;
                                        break;
                                    case 'next':
                                        auditTrailData.pagination.startRecord = auditTrailData.pagination.startRecord + auditTrailData.pagination.recordsPerPage;
                                        break;
                                    case 'recordsPerPage':
                                        auditTrailData.pagination.recordsPerPage = parseInt($("#recordsPerPage").val());
                                        break;
                                    case 'filter':
                                        var filterInput = $("#filterInput").val();
                                        auditTrailData.filter.keyword = filterInput;
                                        if(filterInput !== "" && filterInput !== null) {
                                            auditTrailData.pagination.startRecord = 1;
                                            auditTrailData.pagination.recordsPerPage = parseInt($("#recordsPerPage").val());
                                        }
                                        break;
                                }

                                var app = this;
                                $("#auditTrailDlg").addClass('an-selector-loading').activity();
                                OPM$.auditTrail.auditTrailService.getAuditTrailData(auditTrailData)
                                    .done(function(res) {

                                        if(res.pagination.totalRecords == 0){
                                            res.pagination.startRecord = 0;
                                        }

                                        app.$root.$data.entries = res.entries;
                                        app.$root.$data.pagination = res.pagination;
                                    }).always(function(){
                                        $("#auditTrailDlg").removeClass('an-selector-loading').activity(false);
                                })
                            }
                        }, {
                            name: 'calculateEndRecord',
                            method: function(pagination) {
                                if((pagination.startRecord + pagination.recordsPerPage -1) > pagination.totalRecords){
                                    pagination.endRecord = pagination.totalRecords;
                                } else {
                                    pagination.endRecord = pagination.startRecord + pagination.recordsPerPage - 1;
                                }
                                return pagination.endRecord;
                            }
                        }]
                    }
                    auditTrailInstance = VUE$.createInstance(vueConfig);

                    GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#auditTrailDlg'), false);
                })
        }
    }

    function launchExportDialog(e) {
        if( $("#exportDlg").length > 0){
            $("#exportDlg").detach();
        }
        var html = Handlebars.templates["auditTrail_export"]();
        $("body").append(html);

        $("#exportDlg").draggable({
            handle: "header"
        }).position({
            my: "right top",
            at: "right bottom",
            of: $(e.target)
        });
        $('#exportButton').off().on('click', function(){
            doExport();
        });
        GCM$.accessibility.dialogAccessibility.addDialogKeyNav($('#exportDlg'));
    }

    function doExport() {
        var formData = VUE$.getDataFromApp(auditTrailInstance),
            fileName = $('#exportFilename').val();

        $("#exportDlg").activity();
        AJAX$({
            type: "POST",
            contentType: "application/json",
            url: '/opm/auditTrail/exportAuditTrail',
            data: JSON.stringify(formData)
        }).done(function (data) {
            GCM$.common_functions.downloadTextAsFile(fileName, data);
            GCM$.common_functions.closeDialog("exportDlg");
        }).always(function () {
            $("#exportDlg").activity(false);
        }).fail(function () {
            MSG$.showErrorMsg({status: 'Error', content: 'Export Failed', close: function() {
                    $('#exportButton')[0].focus();
                }
            });
        })
    }

    return {
        launchAuditTrailDialog: launchAuditTrailDialog,
        launchExportDialog: launchExportDialog
    };

})();