OPM$.chartUpgrade = OPM$.chartUpgrade || {};

OPM$.chartUpgrade.chartUpgradeController = (function() {

    var vueInstance;

    function launchChartUpgardeDialog() {
        if($('#chartUpgrade').length === 0) {
            var formData = {};
            OPM$.chartUpgrade.chartUpgradeService.getPodUpgradePackages()
                .done(function (packages) {
                    _.assign(formData, packages);

                    OPM$.repoManagement.repoService.getAllChartRepos()
                        .done(function (repos) {
                            _.assign(formData, repos);

                            var html = Handlebars.templates['chartUpgrade_chartUpgrade'](formData);
                            $('main > .an-layout-center-center').append(html);

                            $("#chartUpgradeDialog").hide().fadeIn().draggable({
                                handle: "header"
                            });

                            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($("#chartUpgradeDialog"));
                            var singleSelectBool = OPM$.repoManagement.repoController.singleRepoAutoSelect(formData.repoList, 
                                $("#chartUpgradeDialog select[name='repos']"));
                                setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                                    if(singleSelectBool)
                                        renderPkgDetail()
                                },100)
                        });
                });
        }
    }

    function updatePackageList() {
        $("#packagePickerDlg").activity();
        OPM$.chartUpgrade.chartUpgradeService.getPodUpgradePackages()
            .done(function (res) {
                var html = Handlebars.templates['chartUpgrade_packages'](res);
                $('#packagePickerDlg tbody').empty().append(html);
            }).always(function(){
                $("#packagePickerDlg").activity(false);
        });
    }

    function launchImportDialog(e) {
        if($("#importInventoryDlg").length < 1) {

            var html = Handlebars.templates['chartUpgrade_import']();
            $(html).appendTo('body').slideDown();
            $("#importInventoryDlg").draggable({
                handle: "header"
            }).position({
                my: "left top",
                at: "left bottom",
                of: $(e.target)
            });
            GCM$.common_functions.inputFile();
            $('body').activity(false);
            VALIDATION$.validateOnInputChange($('#importForm'), $('#uploadButton'), undefined, undefined, undefined, true);

            $('#uploadButton').off().on('click', doImportFile);
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($("#importInventoryDlg"));
        } else {
            $("#importInventoryDlg").slideUp('slow').detach();
        }
    }

    function doImportFile(event) {
        event.stopPropagation();event.preventDefault();
        var fileData = new FormData($('#importForm')[0]);

        $('#importInventoryDlg').activity();
        $.ajax({
            url: '/opm/chartmgmt/import',
            data: fileData,
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data) {
                MSG$.showInfoMsg({status: 'Success', content: 'Import started successfully'});
                $('#importInventoryDlg').activity(false);
                GCM$.common_functions.closeDialog('importInventoryDlg');
                updatePackageList(data);
            },
            error: function (res) {
                MSG$.showErrorMsg({status: 'Error', content: res.responseJSON.errorMessage});
                $('#importInventoryDlg').activity(false);
            }
        });
    }
    
    function upgradeChart() {
        var chartRepo = getSelectedRepoAndPackage().chartRepo;
        $("#podUpgradePane").activity();
        OPM$.chartUpgrade.chartUpgradeService.upgradeChart(VUE$.getDataFromApp(vueInstance), chartRepo)
            .done(function (data) {
               MSG$.showInfoMsg({"status": "Success", "content": data.successMessage});
               renderPkgDetail();
            }).always(function () {
                $("#podUpgradePane").activity(false);
        })
    }

    function getSelectedRepoAndPackage() {
        var package = $("#selectPackageBtn span").text() === "Select Package..." ? "" : $("#selectPackageBtn span").text(),
            chartRepo = $("#chartUpgradeDialog select[name='repos']").val(),
            pkgName = package.split(":")[0],
            pkgVersion = package.split(":")[1];
        var details = {
            pkgName : pkgName,
            pkgVersion: pkgVersion,
            chartRepo: chartRepo
        };

        return details;
    }

    function renderPkgDetail() {

        var details = getSelectedRepoAndPackage();

        if( details.chartRepo !== "" && details.pkgName !== "") {

            $("#chartUpgradeDialog").activity();
            OPM$.chartUpgrade.chartUpgradeService.getPodUpgradePackageDetail(details)
                .done(function (data) {

                    var formData = data.pkgDetail;
                    var html = Handlebars.templates['chartUpgrade_upgradeTable'](formData);
                    $("#podUpgradePane").empty().append(html);
                    dataBindForm(formData);

                    $("#podUpgradePane li").first().focus();
                    GCM$.accessibility.listAccessibility.makeListKeyNav($("#podUpgradePane >ul"));
                    _.forEach($("#podUpgradePane").find('tbody'), function (table$) {
                        GCM$.accessibility.tableAccessibility.makeTableKeyNav(table$);
                    });

                }).always(function (data) {
                    $("#chartUpgradeDialog").activity(false);
            });
        }
    }

    function dataBindForm(data) {
        var vueConfig = {
            el : '#podUpgradePane',
            data: data,
            methods: []
        };

        vueInstance = VUE$.createInstance(vueConfig);
    }

    function toggleTableForRow(index) {
        var table$ =  $('#table-'+index);
        if($(table$).css('display') === "none") {
            $("#podUpgradePane .chartupgrade-table-container").hide();
            $("#podUpgradePane li div").removeClass("an-scroll-triangle-expanded").addClass("an-scroll-triangle-collapsed");
            $(table$).slideDown();
            $("#listItem-"+index+" .an-scroll-triangle").removeClass("an-scroll-triangle-collapsed").addClass("an-scroll-triangle-expanded");
            $("#listItem-"+index).attr('aria-expanded', true);
        } else {
            $(table$).hide();
            $("#listItem-"+index+" .an-scroll-triangle").removeClass("an-scroll-triangle-expanded").addClass("an-scroll-triangle-collapsed");
            $("#listItem-"+index).attr('aria-expanded', false);
        }
    }

    function filterTable(e, index) {
        var input, inputVal, $filterList, $rows;
        input = e.target;
        inputVal = input.value.toUpperCase();
        $filterList = $('#table-'+index+ ' table tbody tr td')[2];
        $rows = $($filterList).find('.cn-candidate');

        var val = '^(?=.*' + inputVal.trim().split(/\s+/).join(')(?=.*') + ').*$',
            reg = RegExp(val, 'i'),
            text;
        $rows.show().filter(function () {
            text = ($(this).text()).replace(/\s+/g, ' ');
            return !reg.test(text);
        }).hide();
    }

    function togglePackageList(e) {
        if($('#packagePickerDlg').css('display') === "none"){
            $('#packagePickerDlg').show()
                .position({
                    my: "right top",
                    at: "right bottom",
                    of: $('#selectPackageBtn')
                });
            GCM$.accessibility.dialogAccessibility.addDialogKeyNav($("#packagePickerDlg"));
            GCM$.accessibility.tableAccessibility.makeTableKeyNav($("#packagePickerDlg tbody"));

        } else {
            $('#packagePickerDlg').slideUp();
        }
    }

    function onSelectPackage(e) {
        var el$ = $(e.target).closest('td');
        e.stopPropagation();
        var selectedPackageName = el$.attr('data-value');
        $('#selectPackageBtn span').text(selectedPackageName);
        $('#selectPackageBtn').prop('title', selectedPackageName);
        $('#packagePickerDlg').slideUp();
        OPM$.chartUpgrade.chartUpgradeController.renderPkgDetail();
    }

    function onDeletePackage(e) {
        e.stopPropagation();
        var el$ = $(e.target).closest('tr');
        var package = $(el$.find('td')[0]).attr('data-value');
        var pkgName = package.split(":")[0],
            pkgVersion = package.split(":")[1];

        MSG$.confirm({
            statement: 'Confirm',
            question: 'Are you sure you want to delete the package?',
            position: {my: 'left top', at: 'right top', of: $(e.target)},
            yes: function () {
                OPM$.chartUpgrade.chartUpgradeService.deletePackage(pkgName, pkgVersion)
                    .done(function (data) {
                        MSG$.showInfoMsg({status: 'Success', content: data.successMessage});
                        updatePackageList();
                    }).fail(function (data) {
                    MSG$.showErrorMsg({status: 'Error', content: data.responseJSON.errorMessage});
                });
            },
            close: function () {
                $(e.target).closest('td').focus();
            }
        });

    }

    return {
        launchChartUpgardeDialog: launchChartUpgardeDialog,
        upgradeChart: upgradeChart,
        launchImportDialog: launchImportDialog,
        renderPkgDetail: renderPkgDetail,
        toggleTableForRow: toggleTableForRow,
        filterTable: filterTable,
        togglePackageList: togglePackageList,
        onSelectPackage: onSelectPackage,
        onDeletePackage: onDeletePackage
    };

})();
