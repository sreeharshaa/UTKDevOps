OPM$.chartUpgrade = OPM$.chartUpgrade || {};

OPM$.chartUpgrade.chartUpgradeService = (function() {

    function getPodUpgradePackages() {
        return GET_JSON$('/opm/chartmgmt/getAllPodUpgradePkgs')
    }

    function getPodUpgradePackageDetail(details) {
        //return GET_JSON$('../json/podUpgrade.json');
        return GET_JSON$('/opm/chartmgmt/getPodUpgradePkgDetail/'+details.chartRepo+'/'+details.pkgName+'/'+details.pkgVersion);
    }

    function upgradeChart(jsonData, chartRepo) {
        return POST_JSON$({
            url: '/opm/chartmgmt/upgradeCharts/'+chartRepo,
            data: JSON.stringify(jsonData)
        });
    }

    function deletePackage(name, version){
        return  $.ajax({type: "DELETE", dataType: 'json', contentType: 'application/json', url: '/opm/chartmgmt/deletePodUpgradePkg/'+name+'/'+version});
    }

    return {
        getPodUpgradePackages: getPodUpgradePackages,
        getPodUpgradePackageDetail: getPodUpgradePackageDetail,
        upgradeChart: upgradeChart,
        deletePackage: deletePackage
    };

})();