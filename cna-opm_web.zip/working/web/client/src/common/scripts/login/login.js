var COMMON$ = COMMON$ || {};

if(Cookies.get('authorization') !== null && Cookies.get('authorization') !== undefined 
&& Cookies.get('username') !== null && Cookies.get('username') !== undefined){
    window.location = window.location + 'html/opm.html';
}else {
COMMON$.login = (function(){
    'use strict';
    var username;
    var isFormSubmitted = false;
    
    // Disable animations/transitions until the page has loaded.
    $("body").addClass('is-loading');
    function getParameterByName(name) {
        //codeQL issue flagged for incomplete encoding or escaping. Changed replace() to replaceAll()
        name = name.replaceAll(/[\[]/g, "\\[").replaceAll(/[\]]/g, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }


    /************
     * exports *
     ***********/

    function onPasswordKeyUp(event, target) {
        if(event && event.keyCode === 13) {
            submitForm(event);
        }
    }

    function checkForParameters() {
        if(getParameterByName('error') === '1') {
            MSG$.showMsg({
                    status: 'Error',
                    content: 'Log in failed due to invalid username or password',
                    type: 'warning',
                    persistent: true,
                    svgRoot: './svg'
                },
                {
                    my: 'center top',
                    at: 'center top+80',
                    of: window
                }
            );
        }

        if(getParameterByName('logout') === '1') {
            MSG$.showMsg({
                status: 'Success',
                content: 'Logged out successfully.',
                type: 'success',
                persistent: true,
                svgRoot: './svg'
                },
                {
                    my: 'center top',
                    at: 'center top+80',
                    of: window
                }
            );
        }

        if(getParameterByName('timedout') === '1') {
            MSG$.showMsg({
                    status: 'Timeout',
                    content: 'Session timed out.',
                    type: 'info',
                    persistent: true,
                    svgRoot: './svg'
                },
                {
                    my: 'center top',
                    at: 'center top+80',
                    of: window
                }
            );
        }
    }

    // submitForm() to fetch JWT token and store in the Cookie.
    //JWT tokens are send across every AJAX request as a part of custom header 'authorization'
    function submitForm(e){
        e.preventDefault();
        if(!isFormSubmitted){
            isFormSubmitted = true;
            var formData = $('#loginForm').serialize()
            username = $('#username').val();
            $.ajax({
                type: 'POST',
                url: '/opm/login',
                data: formData
                }).done(function (data,status,xhr){
                    Cookies.set("authorization", xhr.getResponseHeader('authorization').split(' ')[1]);
                    if(Cookies.get('ao5gc') == 'true')
                        window.location = window.location.origin + '/html/opm-ao5gc.html';
                    else 
                        window.location = window.location.origin + '/html/opm.html';
                    Cookies.remove('logout')
                    Cookies.set("username", username)
                    if(!(Cookies.get('autoCloseBubble'))){
                        Cookies.set('autoCloseBubble', 'false');
                    }
                }).fail( function (response){
                    isFormSubmitted = false;
                    if(response.status === 403 || response.status === 401){
                        MSG$.showMsg({
                                status: 'Error',
                                content: 'Invalid username or password. Please try again.',
                                type: 'warning',
                                persistent: true,
                                svgRoot: './svg'
                            },
                            {
                                my: 'center top',
                                at: 'center top+80',
                                of: window
                            });
                           
                    }else {
                        MSG$.showMsg({
                                status: 'Error',
                                content: response.responseText,
                                type: 'warning',
                                persistent: true,
                                svgRoot: './svg'
                            },
                            {
                                my: 'center top',
                                at: 'center top+80',
                                of: window
                            });
                    }
                    setTimeout(function(){ // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                        $('.an-message-box').focus();
                        $('.an-message-box').attr('aria-live', 'assertive');
                    }, 500)
                });
            }
     }

    function showMessage(msgName){
        if(msgName === 'requirements'){
            $('#legal-msg').fadeOut('slow');
            $('#requirements-msg').fadeIn('slow');
        }
        else if(msgName === 'legal'){
            $('#requirements-msg').fadeOut('slow');
            $('#legal-msg').fadeIn('slow');
        }
    }

     function launchOnlineHelp(){
         window.open(window.location.origin +'/helpFile.html', "helpWindow", "menubar=0,resizeable=1,width=850,height=600");
     }

     function checkLogoutInstance(){
        if(Cookies.get('logout') !== '' && typeof Cookies.get('logout') !== 'undefined'){
            MSG$.showMsg({
                status: 'Success',
                content: 'Logged out successfully.',
                type: 'success',
                persistent: true,
                svgRoot: './svg'
                },
                {
                    my: 'center top',
                    at: 'center top+80',
                    of: window
                }
            );
            setTimeout(function() { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
                Cookies.remove('logout')
            }, 1500);
        }
     }

    return {
        onPasswordKeyUp: onPasswordKeyUp,
        checkForParameters: checkForParameters,
        submitForm: submitForm,
        showMessage: showMessage,
        launchOnlineHelp: launchOnlineHelp,
        checkLogoutInstance: checkLogoutInstance
    }
})();

$(document).ready(function() {
    $("body").addClass("an-high-contrast-theme");
    window.setTimeout(function() { // DevSkim: Ignore DS172411 as per previous fixes for setTimeout usages; reviewed and added ignore
        $("body").removeClass("is-loading");
    }, 100);
    COMMON$.login.checkForParameters();
    COMMON$.login.checkLogoutInstance();
    //To capture return key press in the form and call submit form instead of default form submit
    $("#loginForm").on('keypress', function (e){

        if(e.keyCode == 13 || e.which == 13){
            e.preventDefault();
            e.stopImmediatePropagation();
            COMMON$.login.submitForm(e)
        }
    })
    var	$body = document.getElementsByTagName("body")[0],
        standalone = window.navigator.standalone,
        userAgent = window.navigator.userAgent.toLowerCase(),
        safari = /safari/.test( userAgent ),
        ios = /iphone|ipod|ipad/.test( userAgent );

    if( ios ) {

        // if ( !standalone && safari ) {
        $("body").removeClass("an-keyboard-landscape");

        $("input").on("blur", function() {
            //if (window.matchMedia("(orientation: landscape)").matches) {
                $("#logonWrapper").css({"height": 280});
            //}
        });

        $("input").on("click", function() {
            //if (window.matchMedia("(orientation: landscape)").matches) {
                $("#logonWrapper").css({"height": 500});
            //}
        });
    }

    $('#requirements-link').on('keyup', function(e){
        if(e.keyCode === GCM_KEY$.ENTER){
            COMMON$.login.showMessage('requirements')
        }
    });
    $('#legal-link').on('keyup', function(e){
        if(e.keyCode === GCM_KEY$.ENTER){
            COMMON$.login.showMessage('legal')
        }
    });
    $('#legal-link').on('blur', function(){
        $('#legal-msg').fadeOut('slow');
    })
    $('#requirements-link').on('blur', function(){
        $('#requirements-msg').fadeOut('slow');
    });

    $("#highresHero").on('load', function() {
        $("#Background").css({
            "background-image" : "url(images/international.jpg)"
        });
    }).each(function() {
        if(this.complete) $(this).load();
    });
    
});
}